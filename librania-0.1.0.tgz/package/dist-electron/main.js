const require_schema$1 = require("./schema-Cofpqhhy.js");
const require_utils$1 = require("./utils-CB1hSgen.js");
const require_drizzle_orm = require("./drizzle-orm-D27XQ0Pd.js");
let electron = require("electron");
let path = require("path");
path = require_schema$1.__toESM(path);
let fs_promises = require("fs/promises");
fs_promises = require_schema$1.__toESM(fs_promises);
let express = require("express");
express = require_schema$1.__toESM(express);
let fs = require("fs");
fs = require_schema$1.__toESM(fs);
let better_sqlite3 = require("better-sqlite3");
let better_sqlite3$1 = require_schema$1.__toESM(better_sqlite3, 1);
better_sqlite3 = require_schema$1.__toESM(better_sqlite3);
let crypto$1 = require("crypto");
let os = require("os");
os = require_schema$1.__toESM(os);
//#region electron/crashHandler.ts
/**
* Crash handler for Electron main process
* Handles uncaught exceptions, unhandled rejections, and process crashes
*/
var logger$2 = {
	error: (msg, err) => console.error("[ERROR]", msg, err),
	warn: (msg, err) => console.warn("[WARN]", msg, err),
	info: (msg) => console.log("[INFO]", msg),
	debug: (msg) => console.log("[DEBUG]", msg)
};
/**
* Set up global error handlers for the main process
* Must be called before app.whenReady()
*/
function setupCrashHandlers() {
	process.on("uncaughtException", (error) => {
		logger$2.error("Uncaught exception in main process", error);
		electron.dialog.showErrorBox("Unexpected Error", `An unexpected error occurred. The application will restart.

Error: ${error.message}`);
		electron.app.relaunch();
		electron.app.exit(1);
	});
	process.on("unhandledRejection", (reason) => {
		const error = reason instanceof Error ? reason : new Error(String(reason));
		logger$2.error("Unhandled promise rejection in main process", error);
	});
	electron.app.on("render-process-gone", (event, webContents, details) => {
		logger$2.error("Renderer process gone", /* @__PURE__ */ new Error(`Reason: ${details.reason}, Exit code: ${details.exitCode}`));
		if (details.reason === "crashed") electron.dialog.showMessageBox({
			type: "error",
			title: "Renderer Process Crashed",
			message: "The application window has crashed.",
			buttons: ["Reload", "Quit"],
			defaultId: 0
		}).then((result) => {
			if (result.response === 0) webContents.reload();
			else electron.app.quit();
		});
		else if (details.reason === "killed") logger$2.info("Renderer process was killed (normal shutdown)");
	});
	electron.app.on("child-process-gone", (event, details) => {
		logger$2.warn("Child process gone", /* @__PURE__ */ new Error(`Type: ${details.type}, Reason: ${details.reason}, Exit code: ${details.exitCode}`));
	});
}
//#endregion
//#region src/types/config.ts
var DEFAULT_CONFIG = {
	mode: "desktop",
	theme: "system",
	windowBounds: null,
	serverPort: 3e3
};
//#endregion
//#region src/config/appConfig.ts
function getConfigPath() {
	return path.default.join(process.cwd(), "config.json");
}
async function loadConfig() {
	try {
		const configPath = getConfigPath();
		const data = await fs_promises.default.readFile(configPath, "utf-8");
		const parsed = JSON.parse(data);
		return {
			...DEFAULT_CONFIG,
			...parsed
		};
	} catch (error) {
		return DEFAULT_CONFIG;
	}
}
async function saveConfig(updates) {
	const newConfig = {
		...await loadConfig(),
		...updates
	};
	const configPath = getConfigPath();
	const configDir = path.default.dirname(configPath);
	await fs_promises.default.mkdir(configDir, { recursive: true });
	const tempPath = `${configPath}.tmp`;
	await fs_promises.default.writeFile(tempPath, JSON.stringify(newConfig, null, 2), "utf-8");
	await fs_promises.default.rename(tempPath, configPath);
}
async function updateConfig(updates) {
	const newConfig = {
		...await loadConfig(),
		...updates
	};
	await saveConfig(updates);
	return newConfig;
}
//#endregion
//#region electron/store/env.store.ts
/**
* Environment file config storage
* Stores provider configs in .env file
*/
function getEnvPath$1() {
	const userDataPath = electron.app?.getPath("userData") || process.cwd();
	return path.join(userDataPath, ".env");
}
function parseEnv(content) {
	const env = {};
	const lines = content.split("\n");
	for (const line of lines) {
		const trimmed = line.trim();
		if (!trimmed || trimmed.startsWith("#")) continue;
		const match = trimmed.match(/^([^=]+)=(.*)$/);
		if (match) {
			const key = match[1].trim();
			let value = match[2].trim();
			if (value.startsWith("\"") && value.endsWith("\"") || value.startsWith("'") && value.endsWith("'")) value = value.slice(1, -1);
			env[key] = value;
		}
	}
	return env;
}
function serializeEnv(env) {
	return Object.entries(env).map(([key, value]) => `${key}="${value}"`).join("\n") + "\n";
}
function readEnv() {
	const envPath = getEnvPath$1();
	console.log("[ENV] Reading from:", envPath);
	if (!fs.existsSync(envPath)) {
		console.log("[ENV] File does not exist");
		return {};
	}
	const content = fs.readFileSync(envPath, "utf-8");
	console.log("[ENV] File content:", content);
	const parsed = parseEnv(content);
	console.log("[ENV] Parsed env:", parsed);
	return parsed;
}
function writeEnv(env) {
	const envPath = getEnvPath$1();
	const content = serializeEnv(env);
	fs.writeFileSync(envPath, content, "utf-8");
	console.log("[ENV] Config saved to:", envPath);
}
function saveProviderToEnv(config) {
	const env = readEnv();
	const prefix = config.id.toUpperCase();
	env[`${prefix}_API_KEY`] = config.apiKey;
	env[`${prefix}_MODEL`] = config.model;
	if (config.baseURL) env[`${prefix}_BASE_URL`] = config.baseURL;
	writeEnv(env);
}
function loadProviderFromEnv(providerId) {
	const env = readEnv();
	const prefix = providerId.toUpperCase();
	console.log("[ENV] loadProviderFromEnv:", providerId);
	console.log("[ENV] Prefix:", prefix);
	console.log("[ENV] All env keys:", Object.keys(env));
	const apiKey = env[`${prefix}_API_KEY`];
	const model = env[`${prefix}_MODEL`];
	console.log("[ENV] Found apiKey:", !!apiKey);
	console.log("[ENV] Found model:", !!model);
	if (!apiKey || !model) return null;
	return {
		id: providerId,
		apiKey,
		model,
		baseURL: env[`${prefix}_BASE_URL`]
	};
}
function loadAllProvidersFromEnv() {
	const providers = [];
	for (const id of [
		"claude",
		"openai",
		"deepseek"
	]) {
		const config = loadProviderFromEnv(id);
		if (config) providers.push(config);
	}
	return providers;
}
function deleteProviderFromEnv(providerId) {
	const env = readEnv();
	const prefix = providerId.toUpperCase();
	delete env[`${prefix}_API_KEY`];
	delete env[`${prefix}_MODEL`];
	delete env[`${prefix}_BASE_URL`];
	writeEnv(env);
}
//#endregion
//#region node_modules/drizzle-orm/selection-proxy.js
var SelectionProxyHandler = class SelectionProxyHandler {
	static [require_utils$1.entityKind] = "SelectionProxyHandler";
	config;
	constructor(config) {
		this.config = { ...config };
	}
	get(subquery, prop) {
		if (prop === "_") return {
			...subquery["_"],
			selectedFields: new Proxy(subquery._.selectedFields, this)
		};
		if (prop === require_utils$1.ViewBaseConfig) return {
			...subquery[require_utils$1.ViewBaseConfig],
			selectedFields: new Proxy(subquery[require_utils$1.ViewBaseConfig].selectedFields, this)
		};
		if (typeof prop === "symbol") return subquery[prop];
		const value = (require_utils$1.is(subquery, require_utils$1.Subquery) ? subquery._.selectedFields : require_utils$1.is(subquery, require_utils$1.View) ? subquery[require_utils$1.ViewBaseConfig].selectedFields : subquery)[prop];
		if (require_utils$1.is(value, require_utils$1.SQL.Aliased)) {
			if (this.config.sqlAliasedBehavior === "sql" && !value.isSelectionField) return value.sql;
			const newValue = value.clone();
			newValue.isSelectionField = true;
			return newValue;
		}
		if (require_utils$1.is(value, require_utils$1.SQL)) {
			if (this.config.sqlBehavior === "sql") return value;
			throw new Error(`You tried to reference "${prop}" field from a subquery, which is a raw SQL field, but it doesn't have an alias declared. Please add an alias to the field using ".as('alias')" method.`);
		}
		if (require_utils$1.is(value, require_utils$1.Column)) {
			if (this.config.alias) return new Proxy(value, new require_drizzle_orm.ColumnAliasProxyHandler(new Proxy(value.table, new require_drizzle_orm.TableAliasProxyHandler(this.config.alias, this.config.replaceOriginalName ?? false))));
			return value;
		}
		if (typeof value !== "object" || value === null) return value;
		return new Proxy(value, new SelectionProxyHandler(this.config));
	}
};
//#endregion
//#region node_modules/drizzle-orm/sqlite-core/utils.js
function extractUsedTable(table) {
	if (require_utils$1.is(table, require_schema$1.SQLiteTable)) return [`${table[require_utils$1.Table.Symbol.BaseName]}`];
	if (require_utils$1.is(table, require_utils$1.Subquery)) return table._.usedTables ?? [];
	if (require_utils$1.is(table, require_utils$1.SQL)) return table.usedTables ?? [];
	return [];
}
//#endregion
//#region node_modules/drizzle-orm/sqlite-core/query-builders/delete.js
var SQLiteDeleteBase = class extends require_drizzle_orm.QueryPromise {
	constructor(table, session, dialect, withList) {
		super();
		this.table = table;
		this.session = session;
		this.dialect = dialect;
		this.config = {
			table,
			withList
		};
	}
	static [require_utils$1.entityKind] = "SQLiteDelete";
	/** @internal */
	config;
	/**
	* Adds a `where` clause to the query.
	*
	* Calling this method will delete only those rows that fulfill a specified condition.
	*
	* See docs: {@link https://orm.drizzle.team/docs/delete}
	*
	* @param where the `where` clause.
	*
	* @example
	* You can use conditional operators and `sql function` to filter the rows to be deleted.
	*
	* ```ts
	* // Delete all cars with green color
	* db.delete(cars).where(eq(cars.color, 'green'));
	* // or
	* db.delete(cars).where(sql`${cars.color} = 'green'`)
	* ```
	*
	* You can logically combine conditional operators with `and()` and `or()` operators:
	*
	* ```ts
	* // Delete all BMW cars with a green color
	* db.delete(cars).where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
	*
	* // Delete all cars with the green or blue color
	* db.delete(cars).where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
	* ```
	*/
	where(where) {
		this.config.where = where;
		return this;
	}
	orderBy(...columns) {
		if (typeof columns[0] === "function") {
			const orderBy = columns[0](new Proxy(this.config.table[require_utils$1.Table.Symbol.Columns], new SelectionProxyHandler({
				sqlAliasedBehavior: "alias",
				sqlBehavior: "sql"
			})));
			const orderByArray = Array.isArray(orderBy) ? orderBy : [orderBy];
			this.config.orderBy = orderByArray;
		} else {
			const orderByArray = columns;
			this.config.orderBy = orderByArray;
		}
		return this;
	}
	limit(limit) {
		this.config.limit = limit;
		return this;
	}
	returning(fields = this.table[require_schema$1.SQLiteTable.Symbol.Columns]) {
		this.config.returning = require_utils$1.orderSelectedFields(fields);
		return this;
	}
	/** @internal */
	getSQL() {
		return this.dialect.buildDeleteQuery(this.config);
	}
	toSQL() {
		const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
		return rest;
	}
	/** @internal */
	_prepare(isOneTimeQuery = true) {
		return this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](this.dialect.sqlToQuery(this.getSQL()), this.config.returning, this.config.returning ? "all" : "run", true, void 0, {
			type: "delete",
			tables: extractUsedTable(this.config.table)
		});
	}
	prepare() {
		return this._prepare(false);
	}
	run = (placeholderValues) => {
		return this._prepare().run(placeholderValues);
	};
	all = (placeholderValues) => {
		return this._prepare().all(placeholderValues);
	};
	get = (placeholderValues) => {
		return this._prepare().get(placeholderValues);
	};
	values = (placeholderValues) => {
		return this._prepare().values(placeholderValues);
	};
	async execute(placeholderValues) {
		return this._prepare().execute(placeholderValues);
	}
	$dynamic() {
		return this;
	}
};
//#endregion
//#region node_modules/drizzle-orm/casing.js
function toSnakeCase(input) {
	return (input.replace(/['\u2019]/g, "").match(/[\da-z]+|[A-Z]+(?![a-z])|[A-Z][\da-z]+/g) ?? []).map((word) => word.toLowerCase()).join("_");
}
function toCamelCase(input) {
	return (input.replace(/['\u2019]/g, "").match(/[\da-z]+|[A-Z]+(?![a-z])|[A-Z][\da-z]+/g) ?? []).reduce((acc, word, i) => {
		return acc + (i === 0 ? word.toLowerCase() : `${word[0].toUpperCase()}${word.slice(1)}`);
	}, "");
}
function noopCase(input) {
	return input;
}
var CasingCache = class {
	static [require_utils$1.entityKind] = "CasingCache";
	/** @internal */
	cache = {};
	cachedTables = {};
	convert;
	constructor(casing) {
		this.convert = casing === "snake_case" ? toSnakeCase : casing === "camelCase" ? toCamelCase : noopCase;
	}
	getColumnCasing(column) {
		if (!column.keyAsName) return column.name;
		const key = `${column.table[require_utils$1.Table.Symbol.Schema] ?? "public"}.${column.table[require_utils$1.Table.Symbol.OriginalName]}.${column.name}`;
		if (!this.cache[key]) this.cacheTable(column.table);
		return this.cache[key];
	}
	cacheTable(table) {
		const tableKey = `${table[require_utils$1.Table.Symbol.Schema] ?? "public"}.${table[require_utils$1.Table.Symbol.OriginalName]}`;
		if (!this.cachedTables[tableKey]) {
			for (const column of Object.values(table[require_utils$1.Table.Symbol.Columns])) {
				const columnKey = `${tableKey}.${column.name}`;
				this.cache[columnKey] = this.convert(column.name);
			}
			this.cachedTables[tableKey] = true;
		}
	}
	clearCache() {
		this.cache = {};
		this.cachedTables = {};
	}
};
//#endregion
//#region node_modules/drizzle-orm/sqlite-core/view-base.js
var SQLiteViewBase = class extends require_utils$1.View {
	static [require_utils$1.entityKind] = "SQLiteViewBase";
};
//#endregion
//#region node_modules/drizzle-orm/sqlite-core/dialect.js
var SQLiteDialect = class {
	static [require_utils$1.entityKind] = "SQLiteDialect";
	/** @internal */
	casing;
	constructor(config) {
		this.casing = new CasingCache(config?.casing);
	}
	escapeName(name) {
		return `"${name.replace(/"/g, "\"\"")}"`;
	}
	escapeParam(_num) {
		return "?";
	}
	escapeString(str) {
		return `'${str.replace(/'/g, "''")}'`;
	}
	buildWithCTE(queries) {
		if (!queries?.length) return void 0;
		const withSqlChunks = [require_utils$1.sql`with `];
		for (const [i, w] of queries.entries()) {
			withSqlChunks.push(require_utils$1.sql`${require_utils$1.sql.identifier(w._.alias)} as (${w._.sql})`);
			if (i < queries.length - 1) withSqlChunks.push(require_utils$1.sql`, `);
		}
		withSqlChunks.push(require_utils$1.sql` `);
		return require_utils$1.sql.join(withSqlChunks);
	}
	buildDeleteQuery({ table, where, returning, withList, limit, orderBy }) {
		const withSql = this.buildWithCTE(withList);
		const returningSql = returning ? require_utils$1.sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : void 0;
		return require_utils$1.sql`${withSql}delete from ${table}${where ? require_utils$1.sql` where ${where}` : void 0}${returningSql}${this.buildOrderBy(orderBy)}${this.buildLimit(limit)}`;
	}
	buildUpdateSet(table, set) {
		const tableColumns = table[require_utils$1.Table.Symbol.Columns];
		const columnNames = Object.keys(tableColumns).filter((colName) => set[colName] !== void 0 || tableColumns[colName]?.onUpdateFn !== void 0);
		const setSize = columnNames.length;
		return require_utils$1.sql.join(columnNames.flatMap((colName, i) => {
			const col = tableColumns[colName];
			const onUpdateFnResult = col.onUpdateFn?.();
			const value = set[colName] ?? (require_utils$1.is(onUpdateFnResult, require_utils$1.SQL) ? onUpdateFnResult : require_utils$1.sql.param(onUpdateFnResult, col));
			const res = require_utils$1.sql`${require_utils$1.sql.identifier(this.casing.getColumnCasing(col))} = ${value}`;
			if (i < setSize - 1) return [res, require_utils$1.sql.raw(", ")];
			return [res];
		}));
	}
	buildUpdateQuery({ table, set, where, returning, withList, joins, from, limit, orderBy }) {
		const withSql = this.buildWithCTE(withList);
		const setSql = this.buildUpdateSet(table, set);
		const fromSql = from && require_utils$1.sql.join([require_utils$1.sql.raw(" from "), this.buildFromTable(from)]);
		const joinsSql = this.buildJoins(joins);
		const returningSql = returning ? require_utils$1.sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : void 0;
		return require_utils$1.sql`${withSql}update ${table} set ${setSql}${fromSql}${joinsSql}${where ? require_utils$1.sql` where ${where}` : void 0}${returningSql}${this.buildOrderBy(orderBy)}${this.buildLimit(limit)}`;
	}
	/**
	* Builds selection SQL with provided fields/expressions
	*
	* Examples:
	*
	* `select <selection> from`
	*
	* `insert ... returning <selection>`
	*
	* If `isSingleTable` is true, then columns won't be prefixed with table name
	*/
	buildSelection(fields, { isSingleTable = false } = {}) {
		const columnsLen = fields.length;
		const chunks = fields.flatMap(({ field }, i) => {
			const chunk = [];
			if (require_utils$1.is(field, require_utils$1.SQL.Aliased) && field.isSelectionField) chunk.push(require_utils$1.sql.identifier(field.fieldAlias));
			else if (require_utils$1.is(field, require_utils$1.SQL.Aliased) || require_utils$1.is(field, require_utils$1.SQL)) {
				const query = require_utils$1.is(field, require_utils$1.SQL.Aliased) ? field.sql : field;
				if (isSingleTable) chunk.push(new require_utils$1.SQL(query.queryChunks.map((c) => {
					if (require_utils$1.is(c, require_utils$1.Column)) return require_utils$1.sql.identifier(this.casing.getColumnCasing(c));
					return c;
				})));
				else chunk.push(query);
				if (require_utils$1.is(field, require_utils$1.SQL.Aliased)) chunk.push(require_utils$1.sql` as ${require_utils$1.sql.identifier(field.fieldAlias)}`);
			} else if (require_utils$1.is(field, require_utils$1.Column)) {
				const tableName = field.table[require_utils$1.Table.Symbol.Name];
				if (field.columnType === "SQLiteNumericBigInt") if (isSingleTable) chunk.push(require_utils$1.sql`cast(${require_utils$1.sql.identifier(this.casing.getColumnCasing(field))} as text)`);
				else chunk.push(require_utils$1.sql`cast(${require_utils$1.sql.identifier(tableName)}.${require_utils$1.sql.identifier(this.casing.getColumnCasing(field))} as text)`);
				else if (isSingleTable) chunk.push(require_utils$1.sql.identifier(this.casing.getColumnCasing(field)));
				else chunk.push(require_utils$1.sql`${require_utils$1.sql.identifier(tableName)}.${require_utils$1.sql.identifier(this.casing.getColumnCasing(field))}`);
			} else if (require_utils$1.is(field, require_utils$1.Subquery)) {
				const entries = Object.entries(field._.selectedFields);
				if (entries.length === 1) {
					const entry = entries[0][1];
					const fieldDecoder = require_utils$1.is(entry, require_utils$1.SQL) ? entry.decoder : require_utils$1.is(entry, require_utils$1.Column) ? { mapFromDriverValue: (v) => entry.mapFromDriverValue(v) } : entry.sql.decoder;
					if (fieldDecoder) field._.sql.decoder = fieldDecoder;
				}
				chunk.push(field);
			}
			if (i < columnsLen - 1) chunk.push(require_utils$1.sql`, `);
			return chunk;
		});
		return require_utils$1.sql.join(chunks);
	}
	buildJoins(joins) {
		if (!joins || joins.length === 0) return;
		const joinsArray = [];
		if (joins) for (const [index, joinMeta] of joins.entries()) {
			if (index === 0) joinsArray.push(require_utils$1.sql` `);
			const table = joinMeta.table;
			const onSql = joinMeta.on ? require_utils$1.sql` on ${joinMeta.on}` : void 0;
			if (require_utils$1.is(table, require_schema$1.SQLiteTable)) {
				const tableName = table[require_schema$1.SQLiteTable.Symbol.Name];
				const tableSchema = table[require_schema$1.SQLiteTable.Symbol.Schema];
				const origTableName = table[require_schema$1.SQLiteTable.Symbol.OriginalName];
				const alias = tableName === origTableName ? void 0 : joinMeta.alias;
				joinsArray.push(require_utils$1.sql`${require_utils$1.sql.raw(joinMeta.joinType)} join ${tableSchema ? require_utils$1.sql`${require_utils$1.sql.identifier(tableSchema)}.` : void 0}${require_utils$1.sql.identifier(origTableName)}${alias && require_utils$1.sql` ${require_utils$1.sql.identifier(alias)}`}${onSql}`);
			} else joinsArray.push(require_utils$1.sql`${require_utils$1.sql.raw(joinMeta.joinType)} join ${table}${onSql}`);
			if (index < joins.length - 1) joinsArray.push(require_utils$1.sql` `);
		}
		return require_utils$1.sql.join(joinsArray);
	}
	buildLimit(limit) {
		return typeof limit === "object" || typeof limit === "number" && limit >= 0 ? require_utils$1.sql` limit ${limit}` : void 0;
	}
	buildOrderBy(orderBy) {
		const orderByList = [];
		if (orderBy) for (const [index, orderByValue] of orderBy.entries()) {
			orderByList.push(orderByValue);
			if (index < orderBy.length - 1) orderByList.push(require_utils$1.sql`, `);
		}
		return orderByList.length > 0 ? require_utils$1.sql` order by ${require_utils$1.sql.join(orderByList)}` : void 0;
	}
	buildFromTable(table) {
		if (require_utils$1.is(table, require_utils$1.Table) && table[require_utils$1.Table.Symbol.IsAlias]) return require_utils$1.sql`${require_utils$1.sql`${require_utils$1.sql.identifier(table[require_utils$1.Table.Symbol.Schema] ?? "")}.`.if(table[require_utils$1.Table.Symbol.Schema])}${require_utils$1.sql.identifier(table[require_utils$1.Table.Symbol.OriginalName])} ${require_utils$1.sql.identifier(table[require_utils$1.Table.Symbol.Name])}`;
		return table;
	}
	buildSelectQuery({ withList, fields, fieldsFlat, where, having, table, joins, orderBy, groupBy, limit, offset, distinct, setOperators }) {
		const fieldsList = fieldsFlat ?? require_utils$1.orderSelectedFields(fields);
		for (const f of fieldsList) if (require_utils$1.is(f.field, require_utils$1.Column) && require_utils$1.getTableName(f.field.table) !== (require_utils$1.is(table, require_utils$1.Subquery) ? table._.alias : require_utils$1.is(table, SQLiteViewBase) ? table[require_utils$1.ViewBaseConfig].name : require_utils$1.is(table, require_utils$1.SQL) ? void 0 : require_utils$1.getTableName(table)) && !((table2) => joins?.some(({ alias }) => alias === (table2[require_utils$1.Table.Symbol.IsAlias] ? require_utils$1.getTableName(table2) : table2[require_utils$1.Table.Symbol.BaseName])))(f.field.table)) {
			const tableName = require_utils$1.getTableName(f.field.table);
			throw new Error(`Your "${f.path.join("->")}" field references a column "${tableName}"."${f.field.name}", but the table "${tableName}" is not part of the query! Did you forget to join it?`);
		}
		const isSingleTable = !joins || joins.length === 0;
		const withSql = this.buildWithCTE(withList);
		const distinctSql = distinct ? require_utils$1.sql` distinct` : void 0;
		const selection = this.buildSelection(fieldsList, { isSingleTable });
		const tableSql = this.buildFromTable(table);
		const joinsSql = this.buildJoins(joins);
		const whereSql = where ? require_utils$1.sql` where ${where}` : void 0;
		const havingSql = having ? require_utils$1.sql` having ${having}` : void 0;
		const groupByList = [];
		if (groupBy) for (const [index, groupByValue] of groupBy.entries()) {
			groupByList.push(groupByValue);
			if (index < groupBy.length - 1) groupByList.push(require_utils$1.sql`, `);
		}
		const finalQuery = require_utils$1.sql`${withSql}select${distinctSql} ${selection} from ${tableSql}${joinsSql}${whereSql}${groupByList.length > 0 ? require_utils$1.sql` group by ${require_utils$1.sql.join(groupByList)}` : void 0}${havingSql}${this.buildOrderBy(orderBy)}${this.buildLimit(limit)}${offset ? require_utils$1.sql` offset ${offset}` : void 0}`;
		if (setOperators.length > 0) return this.buildSetOperations(finalQuery, setOperators);
		return finalQuery;
	}
	buildSetOperations(leftSelect, setOperators) {
		const [setOperator, ...rest] = setOperators;
		if (!setOperator) throw new Error("Cannot pass undefined values to any set operator");
		if (rest.length === 0) return this.buildSetOperationQuery({
			leftSelect,
			setOperator
		});
		return this.buildSetOperations(this.buildSetOperationQuery({
			leftSelect,
			setOperator
		}), rest);
	}
	buildSetOperationQuery({ leftSelect, setOperator: { type, isAll, rightSelect, limit, orderBy, offset } }) {
		const leftChunk = require_utils$1.sql`${leftSelect.getSQL()} `;
		const rightChunk = require_utils$1.sql`${rightSelect.getSQL()}`;
		let orderBySql;
		if (orderBy && orderBy.length > 0) {
			const orderByValues = [];
			for (const singleOrderBy of orderBy) if (require_utils$1.is(singleOrderBy, require_schema$1.SQLiteColumn)) orderByValues.push(require_utils$1.sql.identifier(singleOrderBy.name));
			else if (require_utils$1.is(singleOrderBy, require_utils$1.SQL)) {
				for (let i = 0; i < singleOrderBy.queryChunks.length; i++) {
					const chunk = singleOrderBy.queryChunks[i];
					if (require_utils$1.is(chunk, require_schema$1.SQLiteColumn)) singleOrderBy.queryChunks[i] = require_utils$1.sql.identifier(this.casing.getColumnCasing(chunk));
				}
				orderByValues.push(require_utils$1.sql`${singleOrderBy}`);
			} else orderByValues.push(require_utils$1.sql`${singleOrderBy}`);
			orderBySql = require_utils$1.sql` order by ${require_utils$1.sql.join(orderByValues, require_utils$1.sql`, `)}`;
		}
		const limitSql = typeof limit === "object" || typeof limit === "number" && limit >= 0 ? require_utils$1.sql` limit ${limit}` : void 0;
		const operatorChunk = require_utils$1.sql.raw(`${type} ${isAll ? "all " : ""}`);
		const offsetSql = offset ? require_utils$1.sql` offset ${offset}` : void 0;
		return require_utils$1.sql`${leftChunk}${operatorChunk}${rightChunk}${orderBySql}${limitSql}${offsetSql}`;
	}
	buildInsertQuery({ table, values: valuesOrSelect, onConflict, returning, withList, select }) {
		const valuesSqlList = [];
		const columns = table[require_utils$1.Table.Symbol.Columns];
		const colEntries = Object.entries(columns).filter(([_, col]) => !col.shouldDisableInsert());
		const insertOrder = colEntries.map(([, column]) => require_utils$1.sql.identifier(this.casing.getColumnCasing(column)));
		if (select) {
			const select2 = valuesOrSelect;
			if (require_utils$1.is(select2, require_utils$1.SQL)) valuesSqlList.push(select2);
			else valuesSqlList.push(select2.getSQL());
		} else {
			const values = valuesOrSelect;
			valuesSqlList.push(require_utils$1.sql.raw("values "));
			for (const [valueIndex, value] of values.entries()) {
				const valueList = [];
				for (const [fieldName, col] of colEntries) {
					const colValue = value[fieldName];
					if (colValue === void 0 || require_utils$1.is(colValue, require_utils$1.Param) && colValue.value === void 0) {
						let defaultValue;
						if (col.default !== null && col.default !== void 0) defaultValue = require_utils$1.is(col.default, require_utils$1.SQL) ? col.default : require_utils$1.sql.param(col.default, col);
						else if (col.defaultFn !== void 0) {
							const defaultFnResult = col.defaultFn();
							defaultValue = require_utils$1.is(defaultFnResult, require_utils$1.SQL) ? defaultFnResult : require_utils$1.sql.param(defaultFnResult, col);
						} else if (!col.default && col.onUpdateFn !== void 0) {
							const onUpdateFnResult = col.onUpdateFn();
							defaultValue = require_utils$1.is(onUpdateFnResult, require_utils$1.SQL) ? onUpdateFnResult : require_utils$1.sql.param(onUpdateFnResult, col);
						} else defaultValue = require_utils$1.sql`null`;
						valueList.push(defaultValue);
					} else valueList.push(colValue);
				}
				valuesSqlList.push(valueList);
				if (valueIndex < values.length - 1) valuesSqlList.push(require_utils$1.sql`, `);
			}
		}
		const withSql = this.buildWithCTE(withList);
		const valuesSql = require_utils$1.sql.join(valuesSqlList);
		const returningSql = returning ? require_utils$1.sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : void 0;
		return require_utils$1.sql`${withSql}insert into ${table} ${insertOrder} ${valuesSql}${onConflict?.length ? require_utils$1.sql.join(onConflict) : void 0}${returningSql}`;
	}
	sqlToQuery(sql2, invokeSource) {
		return sql2.toQuery({
			casing: this.casing,
			escapeName: this.escapeName,
			escapeParam: this.escapeParam,
			escapeString: this.escapeString,
			invokeSource
		});
	}
	buildRelationalQuery({ fullSchema, schema, tableNamesMap, table, tableConfig, queryConfig: config, tableAlias, nestedQueryRelation, joinOn }) {
		let selection = [];
		let limit, offset, orderBy = [], where;
		const joins = [];
		if (config === true) selection = Object.entries(tableConfig.columns).map(([key, value]) => ({
			dbKey: value.name,
			tsKey: key,
			field: require_drizzle_orm.aliasedTableColumn(value, tableAlias),
			relationTableTsKey: void 0,
			isJson: false,
			selection: []
		}));
		else {
			const aliasedColumns = Object.fromEntries(Object.entries(tableConfig.columns).map(([key, value]) => [key, require_drizzle_orm.aliasedTableColumn(value, tableAlias)]));
			if (config.where) {
				const whereSql = typeof config.where === "function" ? config.where(aliasedColumns, require_drizzle_orm.getOperators()) : config.where;
				where = whereSql && require_drizzle_orm.mapColumnsInSQLToAlias(whereSql, tableAlias);
			}
			const fieldsSelection = [];
			let selectedColumns = [];
			if (config.columns) {
				let isIncludeMode = false;
				for (const [field, value] of Object.entries(config.columns)) {
					if (value === void 0) continue;
					if (field in tableConfig.columns) {
						if (!isIncludeMode && value === true) isIncludeMode = true;
						selectedColumns.push(field);
					}
				}
				if (selectedColumns.length > 0) selectedColumns = isIncludeMode ? selectedColumns.filter((c) => config.columns?.[c] === true) : Object.keys(tableConfig.columns).filter((key) => !selectedColumns.includes(key));
			} else selectedColumns = Object.keys(tableConfig.columns);
			for (const field of selectedColumns) {
				const column = tableConfig.columns[field];
				fieldsSelection.push({
					tsKey: field,
					value: column
				});
			}
			let selectedRelations = [];
			if (config.with) selectedRelations = Object.entries(config.with).filter((entry) => !!entry[1]).map(([tsKey, queryConfig]) => ({
				tsKey,
				queryConfig,
				relation: tableConfig.relations[tsKey]
			}));
			let extras;
			if (config.extras) {
				extras = typeof config.extras === "function" ? config.extras(aliasedColumns, { sql: require_utils$1.sql }) : config.extras;
				for (const [tsKey, value] of Object.entries(extras)) fieldsSelection.push({
					tsKey,
					value: require_drizzle_orm.mapColumnsInAliasedSQLToAlias(value, tableAlias)
				});
			}
			for (const { tsKey, value } of fieldsSelection) selection.push({
				dbKey: require_utils$1.is(value, require_utils$1.SQL.Aliased) ? value.fieldAlias : tableConfig.columns[tsKey].name,
				tsKey,
				field: require_utils$1.is(value, require_utils$1.Column) ? require_drizzle_orm.aliasedTableColumn(value, tableAlias) : value,
				relationTableTsKey: void 0,
				isJson: false,
				selection: []
			});
			let orderByOrig = typeof config.orderBy === "function" ? config.orderBy(aliasedColumns, require_drizzle_orm.getOrderByOperators()) : config.orderBy ?? [];
			if (!Array.isArray(orderByOrig)) orderByOrig = [orderByOrig];
			orderBy = orderByOrig.map((orderByValue) => {
				if (require_utils$1.is(orderByValue, require_utils$1.Column)) return require_drizzle_orm.aliasedTableColumn(orderByValue, tableAlias);
				return require_drizzle_orm.mapColumnsInSQLToAlias(orderByValue, tableAlias);
			});
			limit = config.limit;
			offset = config.offset;
			for (const { tsKey: selectedRelationTsKey, queryConfig: selectedRelationConfigValue, relation } of selectedRelations) {
				const normalizedRelation = require_drizzle_orm.normalizeRelation(schema, tableNamesMap, relation);
				const relationTableTsName = tableNamesMap[require_utils$1.getTableUniqueName(relation.referencedTable)];
				const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
				const joinOn2 = require_drizzle_orm.and(...normalizedRelation.fields.map((field2, i) => require_drizzle_orm.eq(require_drizzle_orm.aliasedTableColumn(normalizedRelation.references[i], relationTableAlias), require_drizzle_orm.aliasedTableColumn(field2, tableAlias))));
				const builtRelation = this.buildRelationalQuery({
					fullSchema,
					schema,
					tableNamesMap,
					table: fullSchema[relationTableTsName],
					tableConfig: schema[relationTableTsName],
					queryConfig: require_utils$1.is(relation, require_drizzle_orm.One) ? selectedRelationConfigValue === true ? { limit: 1 } : {
						...selectedRelationConfigValue,
						limit: 1
					} : selectedRelationConfigValue,
					tableAlias: relationTableAlias,
					joinOn: joinOn2,
					nestedQueryRelation: relation
				});
				const field = require_utils$1.sql`(${builtRelation.sql})`.as(selectedRelationTsKey);
				selection.push({
					dbKey: selectedRelationTsKey,
					tsKey: selectedRelationTsKey,
					field,
					relationTableTsKey: relationTableTsName,
					isJson: true,
					selection: builtRelation.selection
				});
			}
		}
		if (selection.length === 0) throw new require_drizzle_orm.DrizzleError({ message: `No fields selected for table "${tableConfig.tsName}" ("${tableAlias}"). You need to have at least one item in "columns", "with" or "extras". If you need to select all columns, omit the "columns" key or set it to undefined.` });
		let result;
		where = require_drizzle_orm.and(joinOn, where);
		if (nestedQueryRelation) {
			let field = require_utils$1.sql`json_array(${require_utils$1.sql.join(selection.map(({ field: field2 }) => require_utils$1.is(field2, require_schema$1.SQLiteColumn) ? require_utils$1.sql.identifier(this.casing.getColumnCasing(field2)) : require_utils$1.is(field2, require_utils$1.SQL.Aliased) ? field2.sql : field2), require_utils$1.sql`, `)})`;
			if (require_utils$1.is(nestedQueryRelation, require_drizzle_orm.Many)) field = require_utils$1.sql`coalesce(json_group_array(${field}), json_array())`;
			const nestedSelection = [{
				dbKey: "data",
				tsKey: "data",
				field: field.as("data"),
				isJson: true,
				relationTableTsKey: tableConfig.tsName,
				selection
			}];
			if (limit !== void 0 || offset !== void 0 || orderBy.length > 0) {
				result = this.buildSelectQuery({
					table: require_drizzle_orm.aliasedTable(table, tableAlias),
					fields: {},
					fieldsFlat: [{
						path: [],
						field: require_utils$1.sql.raw("*")
					}],
					where,
					limit,
					offset,
					orderBy,
					setOperators: []
				});
				where = void 0;
				limit = void 0;
				offset = void 0;
				orderBy = void 0;
			} else result = require_drizzle_orm.aliasedTable(table, tableAlias);
			result = this.buildSelectQuery({
				table: require_utils$1.is(result, require_schema$1.SQLiteTable) ? result : new require_utils$1.Subquery(result, {}, tableAlias),
				fields: {},
				fieldsFlat: nestedSelection.map(({ field: field2 }) => ({
					path: [],
					field: require_utils$1.is(field2, require_utils$1.Column) ? require_drizzle_orm.aliasedTableColumn(field2, tableAlias) : field2
				})),
				joins,
				where,
				limit,
				offset,
				orderBy,
				setOperators: []
			});
		} else result = this.buildSelectQuery({
			table: require_drizzle_orm.aliasedTable(table, tableAlias),
			fields: {},
			fieldsFlat: selection.map(({ field }) => ({
				path: [],
				field: require_utils$1.is(field, require_utils$1.Column) ? require_drizzle_orm.aliasedTableColumn(field, tableAlias) : field
			})),
			joins,
			where,
			limit,
			offset,
			orderBy,
			setOperators: []
		});
		return {
			tableTsKey: tableConfig.tsName,
			sql: result,
			selection
		};
	}
};
var SQLiteSyncDialect = class extends SQLiteDialect {
	static [require_utils$1.entityKind] = "SQLiteSyncDialect";
	migrate(migrations, session, config) {
		const migrationsTable = config === void 0 ? "__drizzle_migrations" : typeof config === "string" ? "__drizzle_migrations" : config.migrationsTable ?? "__drizzle_migrations";
		const migrationTableCreate = require_utils$1.sql`
			CREATE TABLE IF NOT EXISTS ${require_utils$1.sql.identifier(migrationsTable)} (
				id SERIAL PRIMARY KEY,
				hash text NOT NULL,
				created_at numeric
			)
		`;
		session.run(migrationTableCreate);
		const lastDbMigration = session.values(require_utils$1.sql`SELECT id, hash, created_at FROM ${require_utils$1.sql.identifier(migrationsTable)} ORDER BY created_at DESC LIMIT 1`)[0] ?? void 0;
		session.run(require_utils$1.sql`BEGIN`);
		try {
			for (const migration of migrations) if (!lastDbMigration || Number(lastDbMigration[2]) < migration.folderMillis) {
				for (const stmt of migration.sql) session.run(require_utils$1.sql.raw(stmt));
				session.run(require_utils$1.sql`INSERT INTO ${require_utils$1.sql.identifier(migrationsTable)} ("hash", "created_at") VALUES(${migration.hash}, ${migration.folderMillis})`);
			}
			session.run(require_utils$1.sql`COMMIT`);
		} catch (e) {
			session.run(require_utils$1.sql`ROLLBACK`);
			throw e;
		}
	}
};
//#endregion
//#region node_modules/drizzle-orm/query-builders/query-builder.js
var TypedQueryBuilder = class {
	static [require_utils$1.entityKind] = "TypedQueryBuilder";
	/** @internal */
	getSelectedFields() {
		return this._.selectedFields;
	}
};
//#endregion
//#region node_modules/drizzle-orm/sqlite-core/query-builders/select.js
var SQLiteSelectBuilder = class {
	static [require_utils$1.entityKind] = "SQLiteSelectBuilder";
	fields;
	session;
	dialect;
	withList;
	distinct;
	constructor(config) {
		this.fields = config.fields;
		this.session = config.session;
		this.dialect = config.dialect;
		this.withList = config.withList;
		this.distinct = config.distinct;
	}
	from(source) {
		const isPartialSelect = !!this.fields;
		let fields;
		if (this.fields) fields = this.fields;
		else if (require_utils$1.is(source, require_utils$1.Subquery)) fields = Object.fromEntries(Object.keys(source._.selectedFields).map((key) => [key, source[key]]));
		else if (require_utils$1.is(source, SQLiteViewBase)) fields = source[require_utils$1.ViewBaseConfig].selectedFields;
		else if (require_utils$1.is(source, require_utils$1.SQL)) fields = {};
		else fields = require_utils$1.getTableColumns(source);
		return new SQLiteSelectBase({
			table: source,
			fields,
			isPartialSelect,
			session: this.session,
			dialect: this.dialect,
			withList: this.withList,
			distinct: this.distinct
		});
	}
};
var SQLiteSelectQueryBuilderBase = class extends TypedQueryBuilder {
	static [require_utils$1.entityKind] = "SQLiteSelectQueryBuilder";
	_;
	/** @internal */
	config;
	joinsNotNullableMap;
	tableName;
	isPartialSelect;
	session;
	dialect;
	cacheConfig = void 0;
	usedTables = /* @__PURE__ */ new Set();
	constructor({ table, fields, isPartialSelect, session, dialect, withList, distinct }) {
		super();
		this.config = {
			withList,
			table,
			fields: { ...fields },
			distinct,
			setOperators: []
		};
		this.isPartialSelect = isPartialSelect;
		this.session = session;
		this.dialect = dialect;
		this._ = {
			selectedFields: fields,
			config: this.config
		};
		this.tableName = require_utils$1.getTableLikeName(table);
		this.joinsNotNullableMap = typeof this.tableName === "string" ? { [this.tableName]: true } : {};
		for (const item of extractUsedTable(table)) this.usedTables.add(item);
	}
	/** @internal */
	getUsedTables() {
		return [...this.usedTables];
	}
	createJoin(joinType) {
		return (table, on) => {
			const baseTableName = this.tableName;
			const tableName = require_utils$1.getTableLikeName(table);
			for (const item of extractUsedTable(table)) this.usedTables.add(item);
			if (typeof tableName === "string" && this.config.joins?.some((join) => join.alias === tableName)) throw new Error(`Alias "${tableName}" is already used in this query`);
			if (!this.isPartialSelect) {
				if (Object.keys(this.joinsNotNullableMap).length === 1 && typeof baseTableName === "string") this.config.fields = { [baseTableName]: this.config.fields };
				if (typeof tableName === "string" && !require_utils$1.is(table, require_utils$1.SQL)) {
					const selection = require_utils$1.is(table, require_utils$1.Subquery) ? table._.selectedFields : require_utils$1.is(table, require_utils$1.View) ? table[require_utils$1.ViewBaseConfig].selectedFields : table[require_utils$1.Table.Symbol.Columns];
					this.config.fields[tableName] = selection;
				}
			}
			if (typeof on === "function") on = on(new Proxy(this.config.fields, new SelectionProxyHandler({
				sqlAliasedBehavior: "sql",
				sqlBehavior: "sql"
			})));
			if (!this.config.joins) this.config.joins = [];
			this.config.joins.push({
				on,
				table,
				joinType,
				alias: tableName
			});
			if (typeof tableName === "string") switch (joinType) {
				case "left":
					this.joinsNotNullableMap[tableName] = false;
					break;
				case "right":
					this.joinsNotNullableMap = Object.fromEntries(Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false]));
					this.joinsNotNullableMap[tableName] = true;
					break;
				case "cross":
				case "inner":
					this.joinsNotNullableMap[tableName] = true;
					break;
				case "full":
					this.joinsNotNullableMap = Object.fromEntries(Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false]));
					this.joinsNotNullableMap[tableName] = false;
					break;
			}
			return this;
		};
	}
	/**
	* Executes a `left join` operation by adding another table to the current query.
	*
	* Calling this method associates each row of the table with the corresponding row from the joined table, if a match is found. If no matching row exists, it sets all columns of the joined table to null.
	*
	* See docs: {@link https://orm.drizzle.team/docs/joins#left-join}
	*
	* @param table the table to join.
	* @param on the `on` clause.
	*
	* @example
	*
	* ```ts
	* // Select all users and their pets
	* const usersWithPets: { user: User; pets: Pet | null; }[] = await db.select()
	*   .from(users)
	*   .leftJoin(pets, eq(users.id, pets.ownerId))
	*
	* // Select userId and petId
	* const usersIdsAndPetIds: { userId: number; petId: number | null; }[] = await db.select({
	*   userId: users.id,
	*   petId: pets.id,
	* })
	*   .from(users)
	*   .leftJoin(pets, eq(users.id, pets.ownerId))
	* ```
	*/
	leftJoin = this.createJoin("left");
	/**
	* Executes a `right join` operation by adding another table to the current query.
	*
	* Calling this method associates each row of the joined table with the corresponding row from the main table, if a match is found. If no matching row exists, it sets all columns of the main table to null.
	*
	* See docs: {@link https://orm.drizzle.team/docs/joins#right-join}
	*
	* @param table the table to join.
	* @param on the `on` clause.
	*
	* @example
	*
	* ```ts
	* // Select all users and their pets
	* const usersWithPets: { user: User | null; pets: Pet; }[] = await db.select()
	*   .from(users)
	*   .rightJoin(pets, eq(users.id, pets.ownerId))
	*
	* // Select userId and petId
	* const usersIdsAndPetIds: { userId: number | null; petId: number; }[] = await db.select({
	*   userId: users.id,
	*   petId: pets.id,
	* })
	*   .from(users)
	*   .rightJoin(pets, eq(users.id, pets.ownerId))
	* ```
	*/
	rightJoin = this.createJoin("right");
	/**
	* Executes an `inner join` operation, creating a new table by combining rows from two tables that have matching values.
	*
	* Calling this method retrieves rows that have corresponding entries in both joined tables. Rows without matching entries in either table are excluded, resulting in a table that includes only matching pairs.
	*
	* See docs: {@link https://orm.drizzle.team/docs/joins#inner-join}
	*
	* @param table the table to join.
	* @param on the `on` clause.
	*
	* @example
	*
	* ```ts
	* // Select all users and their pets
	* const usersWithPets: { user: User; pets: Pet; }[] = await db.select()
	*   .from(users)
	*   .innerJoin(pets, eq(users.id, pets.ownerId))
	*
	* // Select userId and petId
	* const usersIdsAndPetIds: { userId: number; petId: number; }[] = await db.select({
	*   userId: users.id,
	*   petId: pets.id,
	* })
	*   .from(users)
	*   .innerJoin(pets, eq(users.id, pets.ownerId))
	* ```
	*/
	innerJoin = this.createJoin("inner");
	/**
	* Executes a `full join` operation by combining rows from two tables into a new table.
	*
	* Calling this method retrieves all rows from both main and joined tables, merging rows with matching values and filling in `null` for non-matching columns.
	*
	* See docs: {@link https://orm.drizzle.team/docs/joins#full-join}
	*
	* @param table the table to join.
	* @param on the `on` clause.
	*
	* @example
	*
	* ```ts
	* // Select all users and their pets
	* const usersWithPets: { user: User | null; pets: Pet | null; }[] = await db.select()
	*   .from(users)
	*   .fullJoin(pets, eq(users.id, pets.ownerId))
	*
	* // Select userId and petId
	* const usersIdsAndPetIds: { userId: number | null; petId: number | null; }[] = await db.select({
	*   userId: users.id,
	*   petId: pets.id,
	* })
	*   .from(users)
	*   .fullJoin(pets, eq(users.id, pets.ownerId))
	* ```
	*/
	fullJoin = this.createJoin("full");
	/**
	* Executes a `cross join` operation by combining rows from two tables into a new table.
	*
	* Calling this method retrieves all rows from both main and joined tables, merging all rows from each table.
	*
	* See docs: {@link https://orm.drizzle.team/docs/joins#cross-join}
	*
	* @param table the table to join.
	*
	* @example
	*
	* ```ts
	* // Select all users, each user with every pet
	* const usersWithPets: { user: User; pets: Pet; }[] = await db.select()
	*   .from(users)
	*   .crossJoin(pets)
	*
	* // Select userId and petId
	* const usersIdsAndPetIds: { userId: number; petId: number; }[] = await db.select({
	*   userId: users.id,
	*   petId: pets.id,
	* })
	*   .from(users)
	*   .crossJoin(pets)
	* ```
	*/
	crossJoin = this.createJoin("cross");
	createSetOperator(type, isAll) {
		return (rightSelection) => {
			const rightSelect = typeof rightSelection === "function" ? rightSelection(getSQLiteSetOperators()) : rightSelection;
			if (!require_utils$1.haveSameKeys(this.getSelectedFields(), rightSelect.getSelectedFields())) throw new Error("Set operator error (union / intersect / except): selected fields are not the same or are in a different order");
			this.config.setOperators.push({
				type,
				isAll,
				rightSelect
			});
			return this;
		};
	}
	/**
	* Adds `union` set operator to the query.
	*
	* Calling this method will combine the result sets of the `select` statements and remove any duplicate rows that appear across them.
	*
	* See docs: {@link https://orm.drizzle.team/docs/set-operations#union}
	*
	* @example
	*
	* ```ts
	* // Select all unique names from customers and users tables
	* await db.select({ name: users.name })
	*   .from(users)
	*   .union(
	*     db.select({ name: customers.name }).from(customers)
	*   );
	* // or
	* import { union } from 'drizzle-orm/sqlite-core'
	*
	* await union(
	*   db.select({ name: users.name }).from(users),
	*   db.select({ name: customers.name }).from(customers)
	* );
	* ```
	*/
	union = this.createSetOperator("union", false);
	/**
	* Adds `union all` set operator to the query.
	*
	* Calling this method will combine the result-set of the `select` statements and keep all duplicate rows that appear across them.
	*
	* See docs: {@link https://orm.drizzle.team/docs/set-operations#union-all}
	*
	* @example
	*
	* ```ts
	* // Select all transaction ids from both online and in-store sales
	* await db.select({ transaction: onlineSales.transactionId })
	*   .from(onlineSales)
	*   .unionAll(
	*     db.select({ transaction: inStoreSales.transactionId }).from(inStoreSales)
	*   );
	* // or
	* import { unionAll } from 'drizzle-orm/sqlite-core'
	*
	* await unionAll(
	*   db.select({ transaction: onlineSales.transactionId }).from(onlineSales),
	*   db.select({ transaction: inStoreSales.transactionId }).from(inStoreSales)
	* );
	* ```
	*/
	unionAll = this.createSetOperator("union", true);
	/**
	* Adds `intersect` set operator to the query.
	*
	* Calling this method will retain only the rows that are present in both result sets and eliminate duplicates.
	*
	* See docs: {@link https://orm.drizzle.team/docs/set-operations#intersect}
	*
	* @example
	*
	* ```ts
	* // Select course names that are offered in both departments A and B
	* await db.select({ courseName: depA.courseName })
	*   .from(depA)
	*   .intersect(
	*     db.select({ courseName: depB.courseName }).from(depB)
	*   );
	* // or
	* import { intersect } from 'drizzle-orm/sqlite-core'
	*
	* await intersect(
	*   db.select({ courseName: depA.courseName }).from(depA),
	*   db.select({ courseName: depB.courseName }).from(depB)
	* );
	* ```
	*/
	intersect = this.createSetOperator("intersect", false);
	/**
	* Adds `except` set operator to the query.
	*
	* Calling this method will retrieve all unique rows from the left query, except for the rows that are present in the result set of the right query.
	*
	* See docs: {@link https://orm.drizzle.team/docs/set-operations#except}
	*
	* @example
	*
	* ```ts
	* // Select all courses offered in department A but not in department B
	* await db.select({ courseName: depA.courseName })
	*   .from(depA)
	*   .except(
	*     db.select({ courseName: depB.courseName }).from(depB)
	*   );
	* // or
	* import { except } from 'drizzle-orm/sqlite-core'
	*
	* await except(
	*   db.select({ courseName: depA.courseName }).from(depA),
	*   db.select({ courseName: depB.courseName }).from(depB)
	* );
	* ```
	*/
	except = this.createSetOperator("except", false);
	/** @internal */
	addSetOperators(setOperators) {
		this.config.setOperators.push(...setOperators);
		return this;
	}
	/**
	* Adds a `where` clause to the query.
	*
	* Calling this method will select only those rows that fulfill a specified condition.
	*
	* See docs: {@link https://orm.drizzle.team/docs/select#filtering}
	*
	* @param where the `where` clause.
	*
	* @example
	* You can use conditional operators and `sql function` to filter the rows to be selected.
	*
	* ```ts
	* // Select all cars with green color
	* await db.select().from(cars).where(eq(cars.color, 'green'));
	* // or
	* await db.select().from(cars).where(sql`${cars.color} = 'green'`)
	* ```
	*
	* You can logically combine conditional operators with `and()` and `or()` operators:
	*
	* ```ts
	* // Select all BMW cars with a green color
	* await db.select().from(cars).where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
	*
	* // Select all cars with the green or blue color
	* await db.select().from(cars).where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
	* ```
	*/
	where(where) {
		if (typeof where === "function") where = where(new Proxy(this.config.fields, new SelectionProxyHandler({
			sqlAliasedBehavior: "sql",
			sqlBehavior: "sql"
		})));
		this.config.where = where;
		return this;
	}
	/**
	* Adds a `having` clause to the query.
	*
	* Calling this method will select only those rows that fulfill a specified condition. It is typically used with aggregate functions to filter the aggregated data based on a specified condition.
	*
	* See docs: {@link https://orm.drizzle.team/docs/select#aggregations}
	*
	* @param having the `having` clause.
	*
	* @example
	*
	* ```ts
	* // Select all brands with more than one car
	* await db.select({
	* 	brand: cars.brand,
	* 	count: sql<number>`cast(count(${cars.id}) as int)`,
	* })
	*   .from(cars)
	*   .groupBy(cars.brand)
	*   .having(({ count }) => gt(count, 1));
	* ```
	*/
	having(having) {
		if (typeof having === "function") having = having(new Proxy(this.config.fields, new SelectionProxyHandler({
			sqlAliasedBehavior: "sql",
			sqlBehavior: "sql"
		})));
		this.config.having = having;
		return this;
	}
	groupBy(...columns) {
		if (typeof columns[0] === "function") {
			const groupBy = columns[0](new Proxy(this.config.fields, new SelectionProxyHandler({
				sqlAliasedBehavior: "alias",
				sqlBehavior: "sql"
			})));
			this.config.groupBy = Array.isArray(groupBy) ? groupBy : [groupBy];
		} else this.config.groupBy = columns;
		return this;
	}
	orderBy(...columns) {
		if (typeof columns[0] === "function") {
			const orderBy = columns[0](new Proxy(this.config.fields, new SelectionProxyHandler({
				sqlAliasedBehavior: "alias",
				sqlBehavior: "sql"
			})));
			const orderByArray = Array.isArray(orderBy) ? orderBy : [orderBy];
			if (this.config.setOperators.length > 0) this.config.setOperators.at(-1).orderBy = orderByArray;
			else this.config.orderBy = orderByArray;
		} else {
			const orderByArray = columns;
			if (this.config.setOperators.length > 0) this.config.setOperators.at(-1).orderBy = orderByArray;
			else this.config.orderBy = orderByArray;
		}
		return this;
	}
	/**
	* Adds a `limit` clause to the query.
	*
	* Calling this method will set the maximum number of rows that will be returned by this query.
	*
	* See docs: {@link https://orm.drizzle.team/docs/select#limit--offset}
	*
	* @param limit the `limit` clause.
	*
	* @example
	*
	* ```ts
	* // Get the first 10 people from this query.
	* await db.select().from(people).limit(10);
	* ```
	*/
	limit(limit) {
		if (this.config.setOperators.length > 0) this.config.setOperators.at(-1).limit = limit;
		else this.config.limit = limit;
		return this;
	}
	/**
	* Adds an `offset` clause to the query.
	*
	* Calling this method will skip a number of rows when returning results from this query.
	*
	* See docs: {@link https://orm.drizzle.team/docs/select#limit--offset}
	*
	* @param offset the `offset` clause.
	*
	* @example
	*
	* ```ts
	* // Get the 10th-20th people from this query.
	* await db.select().from(people).offset(10).limit(10);
	* ```
	*/
	offset(offset) {
		if (this.config.setOperators.length > 0) this.config.setOperators.at(-1).offset = offset;
		else this.config.offset = offset;
		return this;
	}
	/** @internal */
	getSQL() {
		return this.dialect.buildSelectQuery(this.config);
	}
	toSQL() {
		const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
		return rest;
	}
	as(alias) {
		const usedTables = [];
		usedTables.push(...extractUsedTable(this.config.table));
		if (this.config.joins) for (const it of this.config.joins) usedTables.push(...extractUsedTable(it.table));
		return new Proxy(new require_utils$1.Subquery(this.getSQL(), this.config.fields, alias, false, [...new Set(usedTables)]), new SelectionProxyHandler({
			alias,
			sqlAliasedBehavior: "alias",
			sqlBehavior: "error"
		}));
	}
	/** @internal */
	getSelectedFields() {
		return new Proxy(this.config.fields, new SelectionProxyHandler({
			alias: this.tableName,
			sqlAliasedBehavior: "alias",
			sqlBehavior: "error"
		}));
	}
	$dynamic() {
		return this;
	}
};
var SQLiteSelectBase = class extends SQLiteSelectQueryBuilderBase {
	static [require_utils$1.entityKind] = "SQLiteSelect";
	/** @internal */
	_prepare(isOneTimeQuery = true) {
		if (!this.session) throw new Error("Cannot execute a query on a query builder. Please use a database instance instead.");
		const fieldsList = require_utils$1.orderSelectedFields(this.config.fields);
		const query = this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](this.dialect.sqlToQuery(this.getSQL()), fieldsList, "all", true, void 0, {
			type: "select",
			tables: [...this.usedTables]
		}, this.cacheConfig);
		query.joinsNotNullableMap = this.joinsNotNullableMap;
		return query;
	}
	$withCache(config) {
		this.cacheConfig = config === void 0 ? {
			config: {},
			enable: true,
			autoInvalidate: true
		} : config === false ? { enable: false } : {
			enable: true,
			autoInvalidate: true,
			...config
		};
		return this;
	}
	prepare() {
		return this._prepare(false);
	}
	run = (placeholderValues) => {
		return this._prepare().run(placeholderValues);
	};
	all = (placeholderValues) => {
		return this._prepare().all(placeholderValues);
	};
	get = (placeholderValues) => {
		return this._prepare().get(placeholderValues);
	};
	values = (placeholderValues) => {
		return this._prepare().values(placeholderValues);
	};
	async execute() {
		return this.all();
	}
};
require_utils$1.applyMixins(SQLiteSelectBase, [require_drizzle_orm.QueryPromise]);
function createSetOperator(type, isAll) {
	return (leftSelect, rightSelect, ...restSelects) => {
		const setOperators = [rightSelect, ...restSelects].map((select) => ({
			type,
			isAll,
			rightSelect: select
		}));
		for (const setOperator of setOperators) if (!require_utils$1.haveSameKeys(leftSelect.getSelectedFields(), setOperator.rightSelect.getSelectedFields())) throw new Error("Set operator error (union / intersect / except): selected fields are not the same or are in a different order");
		return leftSelect.addSetOperators(setOperators);
	};
}
var getSQLiteSetOperators = () => ({
	union,
	unionAll,
	intersect,
	except
});
var union = createSetOperator("union", false);
var unionAll = createSetOperator("union", true);
var intersect = createSetOperator("intersect", false);
var except = createSetOperator("except", false);
//#endregion
//#region node_modules/drizzle-orm/sqlite-core/query-builders/query-builder.js
var QueryBuilder = class {
	static [require_utils$1.entityKind] = "SQLiteQueryBuilder";
	dialect;
	dialectConfig;
	constructor(dialect) {
		this.dialect = require_utils$1.is(dialect, SQLiteDialect) ? dialect : void 0;
		this.dialectConfig = require_utils$1.is(dialect, SQLiteDialect) ? void 0 : dialect;
	}
	$with = (alias, selection) => {
		const queryBuilder = this;
		const as = (qb) => {
			if (typeof qb === "function") qb = qb(queryBuilder);
			return new Proxy(new require_utils$1.WithSubquery(qb.getSQL(), selection ?? ("getSelectedFields" in qb ? qb.getSelectedFields() ?? {} : {}), alias, true), new SelectionProxyHandler({
				alias,
				sqlAliasedBehavior: "alias",
				sqlBehavior: "error"
			}));
		};
		return { as };
	};
	with(...queries) {
		const self = this;
		function select(fields) {
			return new SQLiteSelectBuilder({
				fields: fields ?? void 0,
				session: void 0,
				dialect: self.getDialect(),
				withList: queries
			});
		}
		function selectDistinct(fields) {
			return new SQLiteSelectBuilder({
				fields: fields ?? void 0,
				session: void 0,
				dialect: self.getDialect(),
				withList: queries,
				distinct: true
			});
		}
		return {
			select,
			selectDistinct
		};
	}
	select(fields) {
		return new SQLiteSelectBuilder({
			fields: fields ?? void 0,
			session: void 0,
			dialect: this.getDialect()
		});
	}
	selectDistinct(fields) {
		return new SQLiteSelectBuilder({
			fields: fields ?? void 0,
			session: void 0,
			dialect: this.getDialect(),
			distinct: true
		});
	}
	getDialect() {
		if (!this.dialect) this.dialect = new SQLiteSyncDialect(this.dialectConfig);
		return this.dialect;
	}
};
//#endregion
//#region node_modules/drizzle-orm/sqlite-core/query-builders/insert.js
var SQLiteInsertBuilder = class {
	constructor(table, session, dialect, withList) {
		this.table = table;
		this.session = session;
		this.dialect = dialect;
		this.withList = withList;
	}
	static [require_utils$1.entityKind] = "SQLiteInsertBuilder";
	values(values) {
		values = Array.isArray(values) ? values : [values];
		if (values.length === 0) throw new Error("values() must be called with at least one value");
		const mappedValues = values.map((entry) => {
			const result = {};
			const cols = this.table[require_utils$1.Table.Symbol.Columns];
			for (const colKey of Object.keys(entry)) {
				const colValue = entry[colKey];
				result[colKey] = require_utils$1.is(colValue, require_utils$1.SQL) ? colValue : new require_utils$1.Param(colValue, cols[colKey]);
			}
			return result;
		});
		return new SQLiteInsertBase(this.table, mappedValues, this.session, this.dialect, this.withList);
	}
	select(selectQuery) {
		const select = typeof selectQuery === "function" ? selectQuery(new QueryBuilder()) : selectQuery;
		if (!require_utils$1.is(select, require_utils$1.SQL) && !require_utils$1.haveSameKeys(this.table[require_utils$1.Columns], select._.selectedFields)) throw new Error("Insert select error: selected fields are not the same or are in a different order compared to the table definition");
		return new SQLiteInsertBase(this.table, select, this.session, this.dialect, this.withList, true);
	}
};
var SQLiteInsertBase = class extends require_drizzle_orm.QueryPromise {
	constructor(table, values, session, dialect, withList, select) {
		super();
		this.session = session;
		this.dialect = dialect;
		this.config = {
			table,
			values,
			withList,
			select
		};
	}
	static [require_utils$1.entityKind] = "SQLiteInsert";
	/** @internal */
	config;
	returning(fields = this.config.table[require_schema$1.SQLiteTable.Symbol.Columns]) {
		this.config.returning = require_utils$1.orderSelectedFields(fields);
		return this;
	}
	/**
	* Adds an `on conflict do nothing` clause to the query.
	*
	* Calling this method simply avoids inserting a row as its alternative action.
	*
	* See docs: {@link https://orm.drizzle.team/docs/insert#on-conflict-do-nothing}
	*
	* @param config The `target` and `where` clauses.
	*
	* @example
	* ```ts
	* // Insert one row and cancel the insert if there's a conflict
	* await db.insert(cars)
	*   .values({ id: 1, brand: 'BMW' })
	*   .onConflictDoNothing();
	*
	* // Explicitly specify conflict target
	* await db.insert(cars)
	*   .values({ id: 1, brand: 'BMW' })
	*   .onConflictDoNothing({ target: cars.id });
	* ```
	*/
	onConflictDoNothing(config = {}) {
		if (!this.config.onConflict) this.config.onConflict = [];
		if (config.target === void 0) this.config.onConflict.push(require_utils$1.sql` on conflict do nothing`);
		else {
			const targetSql = Array.isArray(config.target) ? require_utils$1.sql`${config.target}` : require_utils$1.sql`${[config.target]}`;
			const whereSql = config.where ? require_utils$1.sql` where ${config.where}` : require_utils$1.sql``;
			this.config.onConflict.push(require_utils$1.sql` on conflict ${targetSql} do nothing${whereSql}`);
		}
		return this;
	}
	/**
	* Adds an `on conflict do update` clause to the query.
	*
	* Calling this method will update the existing row that conflicts with the row proposed for insertion as its alternative action.
	*
	* See docs: {@link https://orm.drizzle.team/docs/insert#upserts-and-conflicts}
	*
	* @param config The `target`, `set` and `where` clauses.
	*
	* @example
	* ```ts
	* // Update the row if there's a conflict
	* await db.insert(cars)
	*   .values({ id: 1, brand: 'BMW' })
	*   .onConflictDoUpdate({
	*     target: cars.id,
	*     set: { brand: 'Porsche' }
	*   });
	*
	* // Upsert with 'where' clause
	* await db.insert(cars)
	*   .values({ id: 1, brand: 'BMW' })
	*   .onConflictDoUpdate({
	*     target: cars.id,
	*     set: { brand: 'newBMW' },
	*     where: sql`${cars.createdAt} > '2023-01-01'::date`,
	*   });
	* ```
	*/
	onConflictDoUpdate(config) {
		if (config.where && (config.targetWhere || config.setWhere)) throw new Error("You cannot use both \"where\" and \"targetWhere\"/\"setWhere\" at the same time - \"where\" is deprecated, use \"targetWhere\" or \"setWhere\" instead.");
		if (!this.config.onConflict) this.config.onConflict = [];
		const whereSql = config.where ? require_utils$1.sql` where ${config.where}` : void 0;
		const targetWhereSql = config.targetWhere ? require_utils$1.sql` where ${config.targetWhere}` : void 0;
		const setWhereSql = config.setWhere ? require_utils$1.sql` where ${config.setWhere}` : void 0;
		const targetSql = Array.isArray(config.target) ? require_utils$1.sql`${config.target}` : require_utils$1.sql`${[config.target]}`;
		const setSql = this.dialect.buildUpdateSet(this.config.table, require_utils$1.mapUpdateSet(this.config.table, config.set));
		this.config.onConflict.push(require_utils$1.sql` on conflict ${targetSql}${targetWhereSql} do update set ${setSql}${whereSql}${setWhereSql}`);
		return this;
	}
	/** @internal */
	getSQL() {
		return this.dialect.buildInsertQuery(this.config);
	}
	toSQL() {
		const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
		return rest;
	}
	/** @internal */
	_prepare(isOneTimeQuery = true) {
		return this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](this.dialect.sqlToQuery(this.getSQL()), this.config.returning, this.config.returning ? "all" : "run", true, void 0, {
			type: "insert",
			tables: extractUsedTable(this.config.table)
		});
	}
	prepare() {
		return this._prepare(false);
	}
	run = (placeholderValues) => {
		return this._prepare().run(placeholderValues);
	};
	all = (placeholderValues) => {
		return this._prepare().all(placeholderValues);
	};
	get = (placeholderValues) => {
		return this._prepare().get(placeholderValues);
	};
	values = (placeholderValues) => {
		return this._prepare().values(placeholderValues);
	};
	async execute() {
		return this.config.returning ? this.all() : this.run();
	}
	$dynamic() {
		return this;
	}
};
//#endregion
//#region node_modules/drizzle-orm/sqlite-core/query-builders/update.js
var SQLiteUpdateBuilder = class {
	constructor(table, session, dialect, withList) {
		this.table = table;
		this.session = session;
		this.dialect = dialect;
		this.withList = withList;
	}
	static [require_utils$1.entityKind] = "SQLiteUpdateBuilder";
	set(values) {
		return new SQLiteUpdateBase(this.table, require_utils$1.mapUpdateSet(this.table, values), this.session, this.dialect, this.withList);
	}
};
var SQLiteUpdateBase = class extends require_drizzle_orm.QueryPromise {
	constructor(table, set, session, dialect, withList) {
		super();
		this.session = session;
		this.dialect = dialect;
		this.config = {
			set,
			table,
			withList,
			joins: []
		};
	}
	static [require_utils$1.entityKind] = "SQLiteUpdate";
	/** @internal */
	config;
	from(source) {
		this.config.from = source;
		return this;
	}
	createJoin(joinType) {
		return (table, on) => {
			const tableName = require_utils$1.getTableLikeName(table);
			if (typeof tableName === "string" && this.config.joins.some((join) => join.alias === tableName)) throw new Error(`Alias "${tableName}" is already used in this query`);
			if (typeof on === "function") {
				const from = this.config.from ? require_utils$1.is(table, require_schema$1.SQLiteTable) ? table[require_utils$1.Table.Symbol.Columns] : require_utils$1.is(table, require_utils$1.Subquery) ? table._.selectedFields : require_utils$1.is(table, SQLiteViewBase) ? table[require_utils$1.ViewBaseConfig].selectedFields : void 0 : void 0;
				on = on(new Proxy(this.config.table[require_utils$1.Table.Symbol.Columns], new SelectionProxyHandler({
					sqlAliasedBehavior: "sql",
					sqlBehavior: "sql"
				})), from && new Proxy(from, new SelectionProxyHandler({
					sqlAliasedBehavior: "sql",
					sqlBehavior: "sql"
				})));
			}
			this.config.joins.push({
				on,
				table,
				joinType,
				alias: tableName
			});
			return this;
		};
	}
	leftJoin = this.createJoin("left");
	rightJoin = this.createJoin("right");
	innerJoin = this.createJoin("inner");
	fullJoin = this.createJoin("full");
	/**
	* Adds a 'where' clause to the query.
	*
	* Calling this method will update only those rows that fulfill a specified condition.
	*
	* See docs: {@link https://orm.drizzle.team/docs/update}
	*
	* @param where the 'where' clause.
	*
	* @example
	* You can use conditional operators and `sql function` to filter the rows to be updated.
	*
	* ```ts
	* // Update all cars with green color
	* db.update(cars).set({ color: 'red' })
	*   .where(eq(cars.color, 'green'));
	* // or
	* db.update(cars).set({ color: 'red' })
	*   .where(sql`${cars.color} = 'green'`)
	* ```
	*
	* You can logically combine conditional operators with `and()` and `or()` operators:
	*
	* ```ts
	* // Update all BMW cars with a green color
	* db.update(cars).set({ color: 'red' })
	*   .where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
	*
	* // Update all cars with the green or blue color
	* db.update(cars).set({ color: 'red' })
	*   .where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
	* ```
	*/
	where(where) {
		this.config.where = where;
		return this;
	}
	orderBy(...columns) {
		if (typeof columns[0] === "function") {
			const orderBy = columns[0](new Proxy(this.config.table[require_utils$1.Table.Symbol.Columns], new SelectionProxyHandler({
				sqlAliasedBehavior: "alias",
				sqlBehavior: "sql"
			})));
			const orderByArray = Array.isArray(orderBy) ? orderBy : [orderBy];
			this.config.orderBy = orderByArray;
		} else {
			const orderByArray = columns;
			this.config.orderBy = orderByArray;
		}
		return this;
	}
	limit(limit) {
		this.config.limit = limit;
		return this;
	}
	returning(fields = this.config.table[require_schema$1.SQLiteTable.Symbol.Columns]) {
		this.config.returning = require_utils$1.orderSelectedFields(fields);
		return this;
	}
	/** @internal */
	getSQL() {
		return this.dialect.buildUpdateQuery(this.config);
	}
	toSQL() {
		const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
		return rest;
	}
	/** @internal */
	_prepare(isOneTimeQuery = true) {
		return this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](this.dialect.sqlToQuery(this.getSQL()), this.config.returning, this.config.returning ? "all" : "run", true, void 0, {
			type: "insert",
			tables: extractUsedTable(this.config.table)
		});
	}
	prepare() {
		return this._prepare(false);
	}
	run = (placeholderValues) => {
		return this._prepare().run(placeholderValues);
	};
	all = (placeholderValues) => {
		return this._prepare().all(placeholderValues);
	};
	get = (placeholderValues) => {
		return this._prepare().get(placeholderValues);
	};
	values = (placeholderValues) => {
		return this._prepare().values(placeholderValues);
	};
	async execute() {
		return this.config.returning ? this.all() : this.run();
	}
	$dynamic() {
		return this;
	}
};
//#endregion
//#region node_modules/drizzle-orm/sqlite-core/query-builders/count.js
var SQLiteCountBuilder = class SQLiteCountBuilder extends require_utils$1.SQL {
	constructor(params) {
		super(SQLiteCountBuilder.buildEmbeddedCount(params.source, params.filters).queryChunks);
		this.params = params;
		this.session = params.session;
		this.sql = SQLiteCountBuilder.buildCount(params.source, params.filters);
	}
	sql;
	static [require_utils$1.entityKind] = "SQLiteCountBuilderAsync";
	[Symbol.toStringTag] = "SQLiteCountBuilderAsync";
	session;
	static buildEmbeddedCount(source, filters) {
		return require_utils$1.sql`(select count(*) from ${source}${require_utils$1.sql.raw(" where ").if(filters)}${filters})`;
	}
	static buildCount(source, filters) {
		return require_utils$1.sql`select count(*) from ${source}${require_utils$1.sql.raw(" where ").if(filters)}${filters}`;
	}
	then(onfulfilled, onrejected) {
		return Promise.resolve(this.session.count(this.sql)).then(onfulfilled, onrejected);
	}
	catch(onRejected) {
		return this.then(void 0, onRejected);
	}
	finally(onFinally) {
		return this.then((value) => {
			onFinally?.();
			return value;
		}, (reason) => {
			onFinally?.();
			throw reason;
		});
	}
};
//#endregion
//#region node_modules/drizzle-orm/sqlite-core/query-builders/query.js
var RelationalQueryBuilder = class {
	constructor(mode, fullSchema, schema, tableNamesMap, table, tableConfig, dialect, session) {
		this.mode = mode;
		this.fullSchema = fullSchema;
		this.schema = schema;
		this.tableNamesMap = tableNamesMap;
		this.table = table;
		this.tableConfig = tableConfig;
		this.dialect = dialect;
		this.session = session;
	}
	static [require_utils$1.entityKind] = "SQLiteAsyncRelationalQueryBuilder";
	findMany(config) {
		return this.mode === "sync" ? new SQLiteSyncRelationalQuery(this.fullSchema, this.schema, this.tableNamesMap, this.table, this.tableConfig, this.dialect, this.session, config ? config : {}, "many") : new SQLiteRelationalQuery(this.fullSchema, this.schema, this.tableNamesMap, this.table, this.tableConfig, this.dialect, this.session, config ? config : {}, "many");
	}
	findFirst(config) {
		return this.mode === "sync" ? new SQLiteSyncRelationalQuery(this.fullSchema, this.schema, this.tableNamesMap, this.table, this.tableConfig, this.dialect, this.session, config ? {
			...config,
			limit: 1
		} : { limit: 1 }, "first") : new SQLiteRelationalQuery(this.fullSchema, this.schema, this.tableNamesMap, this.table, this.tableConfig, this.dialect, this.session, config ? {
			...config,
			limit: 1
		} : { limit: 1 }, "first");
	}
};
var SQLiteRelationalQuery = class extends require_drizzle_orm.QueryPromise {
	constructor(fullSchema, schema, tableNamesMap, table, tableConfig, dialect, session, config, mode) {
		super();
		this.fullSchema = fullSchema;
		this.schema = schema;
		this.tableNamesMap = tableNamesMap;
		this.table = table;
		this.tableConfig = tableConfig;
		this.dialect = dialect;
		this.session = session;
		this.config = config;
		this.mode = mode;
	}
	static [require_utils$1.entityKind] = "SQLiteAsyncRelationalQuery";
	/** @internal */
	mode;
	/** @internal */
	getSQL() {
		return this.dialect.buildRelationalQuery({
			fullSchema: this.fullSchema,
			schema: this.schema,
			tableNamesMap: this.tableNamesMap,
			table: this.table,
			tableConfig: this.tableConfig,
			queryConfig: this.config,
			tableAlias: this.tableConfig.tsName
		}).sql;
	}
	/** @internal */
	_prepare(isOneTimeQuery = false) {
		const { query, builtQuery } = this._toSQL();
		return this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](builtQuery, void 0, this.mode === "first" ? "get" : "all", true, (rawRows, mapColumnValue) => {
			const rows = rawRows.map((row) => require_drizzle_orm.mapRelationalRow(this.schema, this.tableConfig, row, query.selection, mapColumnValue));
			if (this.mode === "first") return rows[0];
			return rows;
		});
	}
	prepare() {
		return this._prepare(false);
	}
	_toSQL() {
		const query = this.dialect.buildRelationalQuery({
			fullSchema: this.fullSchema,
			schema: this.schema,
			tableNamesMap: this.tableNamesMap,
			table: this.table,
			tableConfig: this.tableConfig,
			queryConfig: this.config,
			tableAlias: this.tableConfig.tsName
		});
		return {
			query,
			builtQuery: this.dialect.sqlToQuery(query.sql)
		};
	}
	toSQL() {
		return this._toSQL().builtQuery;
	}
	/** @internal */
	executeRaw() {
		if (this.mode === "first") return this._prepare(false).get();
		return this._prepare(false).all();
	}
	async execute() {
		return this.executeRaw();
	}
};
var SQLiteSyncRelationalQuery = class extends SQLiteRelationalQuery {
	static [require_utils$1.entityKind] = "SQLiteSyncRelationalQuery";
	sync() {
		return this.executeRaw();
	}
};
//#endregion
//#region node_modules/drizzle-orm/sqlite-core/query-builders/raw.js
var SQLiteRaw = class extends require_drizzle_orm.QueryPromise {
	constructor(execute, getSQL, action, dialect, mapBatchResult) {
		super();
		this.execute = execute;
		this.getSQL = getSQL;
		this.dialect = dialect;
		this.mapBatchResult = mapBatchResult;
		this.config = { action };
	}
	static [require_utils$1.entityKind] = "SQLiteRaw";
	/** @internal */
	config;
	getQuery() {
		return {
			...this.dialect.sqlToQuery(this.getSQL()),
			method: this.config.action
		};
	}
	mapResult(result, isFromBatch) {
		return isFromBatch ? this.mapBatchResult(result) : result;
	}
	_prepare() {
		return this;
	}
	/** @internal */
	isResponseInArrayMode() {
		return false;
	}
};
//#endregion
//#region node_modules/drizzle-orm/sqlite-core/db.js
var BaseSQLiteDatabase = class {
	constructor(resultKind, dialect, session, schema) {
		this.resultKind = resultKind;
		this.dialect = dialect;
		this.session = session;
		this._ = schema ? {
			schema: schema.schema,
			fullSchema: schema.fullSchema,
			tableNamesMap: schema.tableNamesMap
		} : {
			schema: void 0,
			fullSchema: {},
			tableNamesMap: {}
		};
		this.query = {};
		const query = this.query;
		if (this._.schema) for (const [tableName, columns] of Object.entries(this._.schema)) query[tableName] = new RelationalQueryBuilder(resultKind, schema.fullSchema, this._.schema, this._.tableNamesMap, schema.fullSchema[tableName], columns, dialect, session);
		this.$cache = { invalidate: async (_params) => {} };
	}
	static [require_utils$1.entityKind] = "BaseSQLiteDatabase";
	query;
	/**
	* Creates a subquery that defines a temporary named result set as a CTE.
	*
	* It is useful for breaking down complex queries into simpler parts and for reusing the result set in subsequent parts of the query.
	*
	* See docs: {@link https://orm.drizzle.team/docs/select#with-clause}
	*
	* @param alias The alias for the subquery.
	*
	* Failure to provide an alias will result in a DrizzleTypeError, preventing the subquery from being referenced in other queries.
	*
	* @example
	*
	* ```ts
	* // Create a subquery with alias 'sq' and use it in the select query
	* const sq = db.$with('sq').as(db.select().from(users).where(eq(users.id, 42)));
	*
	* const result = await db.with(sq).select().from(sq);
	* ```
	*
	* To select arbitrary SQL values as fields in a CTE and reference them in other CTEs or in the main query, you need to add aliases to them:
	*
	* ```ts
	* // Select an arbitrary SQL value as a field in a CTE and reference it in the main query
	* const sq = db.$with('sq').as(db.select({
	*   name: sql<string>`upper(${users.name})`.as('name'),
	* })
	* .from(users));
	*
	* const result = await db.with(sq).select({ name: sq.name }).from(sq);
	* ```
	*/
	$with = (alias, selection) => {
		const self = this;
		const as = (qb) => {
			if (typeof qb === "function") qb = qb(new QueryBuilder(self.dialect));
			return new Proxy(new require_utils$1.WithSubquery(qb.getSQL(), selection ?? ("getSelectedFields" in qb ? qb.getSelectedFields() ?? {} : {}), alias, true), new SelectionProxyHandler({
				alias,
				sqlAliasedBehavior: "alias",
				sqlBehavior: "error"
			}));
		};
		return { as };
	};
	$count(source, filters) {
		return new SQLiteCountBuilder({
			source,
			filters,
			session: this.session
		});
	}
	/**
	* Incorporates a previously defined CTE (using `$with`) into the main query.
	*
	* This method allows the main query to reference a temporary named result set.
	*
	* See docs: {@link https://orm.drizzle.team/docs/select#with-clause}
	*
	* @param queries The CTEs to incorporate into the main query.
	*
	* @example
	*
	* ```ts
	* // Define a subquery 'sq' as a CTE using $with
	* const sq = db.$with('sq').as(db.select().from(users).where(eq(users.id, 42)));
	*
	* // Incorporate the CTE 'sq' into the main query and select from it
	* const result = await db.with(sq).select().from(sq);
	* ```
	*/
	with(...queries) {
		const self = this;
		function select(fields) {
			return new SQLiteSelectBuilder({
				fields: fields ?? void 0,
				session: self.session,
				dialect: self.dialect,
				withList: queries
			});
		}
		function selectDistinct(fields) {
			return new SQLiteSelectBuilder({
				fields: fields ?? void 0,
				session: self.session,
				dialect: self.dialect,
				withList: queries,
				distinct: true
			});
		}
		function update(table) {
			return new SQLiteUpdateBuilder(table, self.session, self.dialect, queries);
		}
		function insert(into) {
			return new SQLiteInsertBuilder(into, self.session, self.dialect, queries);
		}
		function delete_(from) {
			return new SQLiteDeleteBase(from, self.session, self.dialect, queries);
		}
		return {
			select,
			selectDistinct,
			update,
			insert,
			delete: delete_
		};
	}
	select(fields) {
		return new SQLiteSelectBuilder({
			fields: fields ?? void 0,
			session: this.session,
			dialect: this.dialect
		});
	}
	selectDistinct(fields) {
		return new SQLiteSelectBuilder({
			fields: fields ?? void 0,
			session: this.session,
			dialect: this.dialect,
			distinct: true
		});
	}
	/**
	* Creates an update query.
	*
	* Calling this method without `.where()` clause will update all rows in a table. The `.where()` clause specifies which rows should be updated.
	*
	* Use `.set()` method to specify which values to update.
	*
	* See docs: {@link https://orm.drizzle.team/docs/update}
	*
	* @param table The table to update.
	*
	* @example
	*
	* ```ts
	* // Update all rows in the 'cars' table
	* await db.update(cars).set({ color: 'red' });
	*
	* // Update rows with filters and conditions
	* await db.update(cars).set({ color: 'red' }).where(eq(cars.brand, 'BMW'));
	*
	* // Update with returning clause
	* const updatedCar: Car[] = await db.update(cars)
	*   .set({ color: 'red' })
	*   .where(eq(cars.id, 1))
	*   .returning();
	* ```
	*/
	update(table) {
		return new SQLiteUpdateBuilder(table, this.session, this.dialect);
	}
	$cache;
	/**
	* Creates an insert query.
	*
	* Calling this method will create new rows in a table. Use `.values()` method to specify which values to insert.
	*
	* See docs: {@link https://orm.drizzle.team/docs/insert}
	*
	* @param table The table to insert into.
	*
	* @example
	*
	* ```ts
	* // Insert one row
	* await db.insert(cars).values({ brand: 'BMW' });
	*
	* // Insert multiple rows
	* await db.insert(cars).values([{ brand: 'BMW' }, { brand: 'Porsche' }]);
	*
	* // Insert with returning clause
	* const insertedCar: Car[] = await db.insert(cars)
	*   .values({ brand: 'BMW' })
	*   .returning();
	* ```
	*/
	insert(into) {
		return new SQLiteInsertBuilder(into, this.session, this.dialect);
	}
	/**
	* Creates a delete query.
	*
	* Calling this method without `.where()` clause will delete all rows in a table. The `.where()` clause specifies which rows should be deleted.
	*
	* See docs: {@link https://orm.drizzle.team/docs/delete}
	*
	* @param table The table to delete from.
	*
	* @example
	*
	* ```ts
	* // Delete all rows in the 'cars' table
	* await db.delete(cars);
	*
	* // Delete rows with filters and conditions
	* await db.delete(cars).where(eq(cars.color, 'green'));
	*
	* // Delete with returning clause
	* const deletedCar: Car[] = await db.delete(cars)
	*   .where(eq(cars.id, 1))
	*   .returning();
	* ```
	*/
	delete(from) {
		return new SQLiteDeleteBase(from, this.session, this.dialect);
	}
	run(query) {
		const sequel = typeof query === "string" ? require_utils$1.sql.raw(query) : query.getSQL();
		if (this.resultKind === "async") return new SQLiteRaw(async () => this.session.run(sequel), () => sequel, "run", this.dialect, this.session.extractRawRunValueFromBatchResult.bind(this.session));
		return this.session.run(sequel);
	}
	all(query) {
		const sequel = typeof query === "string" ? require_utils$1.sql.raw(query) : query.getSQL();
		if (this.resultKind === "async") return new SQLiteRaw(async () => this.session.all(sequel), () => sequel, "all", this.dialect, this.session.extractRawAllValueFromBatchResult.bind(this.session));
		return this.session.all(sequel);
	}
	get(query) {
		const sequel = typeof query === "string" ? require_utils$1.sql.raw(query) : query.getSQL();
		if (this.resultKind === "async") return new SQLiteRaw(async () => this.session.get(sequel), () => sequel, "get", this.dialect, this.session.extractRawGetValueFromBatchResult.bind(this.session));
		return this.session.get(sequel);
	}
	values(query) {
		const sequel = typeof query === "string" ? require_utils$1.sql.raw(query) : query.getSQL();
		if (this.resultKind === "async") return new SQLiteRaw(async () => this.session.values(sequel), () => sequel, "values", this.dialect, this.session.extractRawValuesValueFromBatchResult.bind(this.session));
		return this.session.values(sequel);
	}
	transaction(transaction, config) {
		return this.session.transaction(transaction, config);
	}
};
//#endregion
//#region node_modules/drizzle-orm/cache/core/cache.js
var Cache = class {
	static [require_utils$1.entityKind] = "Cache";
};
var NoopCache = class extends Cache {
	strategy() {
		return "all";
	}
	static [require_utils$1.entityKind] = "NoopCache";
	async get(_key) {}
	async put(_hashedQuery, _response, _tables, _config) {}
	async onMutate(_params) {}
};
async function hashQuery(sql, params) {
	const dataToHash = `${sql}-${JSON.stringify(params)}`;
	const data = new TextEncoder().encode(dataToHash);
	const hashBuffer = await crypto.subtle.digest("SHA-256", data);
	return [...new Uint8Array(hashBuffer)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
//#endregion
//#region node_modules/drizzle-orm/sqlite-core/session.js
var ExecuteResultSync = class extends require_drizzle_orm.QueryPromise {
	constructor(resultCb) {
		super();
		this.resultCb = resultCb;
	}
	static [require_utils$1.entityKind] = "ExecuteResultSync";
	async execute() {
		return this.resultCb();
	}
	sync() {
		return this.resultCb();
	}
};
var SQLitePreparedQuery = class {
	constructor(mode, executeMethod, query, cache, queryMetadata, cacheConfig) {
		this.mode = mode;
		this.executeMethod = executeMethod;
		this.query = query;
		this.cache = cache;
		this.queryMetadata = queryMetadata;
		this.cacheConfig = cacheConfig;
		if (cache && cache.strategy() === "all" && cacheConfig === void 0) this.cacheConfig = {
			enable: true,
			autoInvalidate: true
		};
		if (!this.cacheConfig?.enable) this.cacheConfig = void 0;
	}
	static [require_utils$1.entityKind] = "PreparedQuery";
	/** @internal */
	joinsNotNullableMap;
	/** @internal */
	async queryWithCache(queryString, params, query) {
		if (this.cache === void 0 || require_utils$1.is(this.cache, NoopCache) || this.queryMetadata === void 0) try {
			return await query();
		} catch (e) {
			throw new require_drizzle_orm.DrizzleQueryError(queryString, params, e);
		}
		if (this.cacheConfig && !this.cacheConfig.enable) try {
			return await query();
		} catch (e) {
			throw new require_drizzle_orm.DrizzleQueryError(queryString, params, e);
		}
		if ((this.queryMetadata.type === "insert" || this.queryMetadata.type === "update" || this.queryMetadata.type === "delete") && this.queryMetadata.tables.length > 0) try {
			const [res] = await Promise.all([query(), this.cache.onMutate({ tables: this.queryMetadata.tables })]);
			return res;
		} catch (e) {
			throw new require_drizzle_orm.DrizzleQueryError(queryString, params, e);
		}
		if (!this.cacheConfig) try {
			return await query();
		} catch (e) {
			throw new require_drizzle_orm.DrizzleQueryError(queryString, params, e);
		}
		if (this.queryMetadata.type === "select") {
			const fromCache = await this.cache.get(this.cacheConfig.tag ?? await hashQuery(queryString, params), this.queryMetadata.tables, this.cacheConfig.tag !== void 0, this.cacheConfig.autoInvalidate);
			if (fromCache === void 0) {
				let result;
				try {
					result = await query();
				} catch (e) {
					throw new require_drizzle_orm.DrizzleQueryError(queryString, params, e);
				}
				await this.cache.put(this.cacheConfig.tag ?? await hashQuery(queryString, params), result, this.cacheConfig.autoInvalidate ? this.queryMetadata.tables : [], this.cacheConfig.tag !== void 0, this.cacheConfig.config);
				return result;
			}
			return fromCache;
		}
		try {
			return await query();
		} catch (e) {
			throw new require_drizzle_orm.DrizzleQueryError(queryString, params, e);
		}
	}
	getQuery() {
		return this.query;
	}
	mapRunResult(result, _isFromBatch) {
		return result;
	}
	mapAllResult(_result, _isFromBatch) {
		throw new Error("Not implemented");
	}
	mapGetResult(_result, _isFromBatch) {
		throw new Error("Not implemented");
	}
	execute(placeholderValues) {
		if (this.mode === "async") return this[this.executeMethod](placeholderValues);
		return new ExecuteResultSync(() => this[this.executeMethod](placeholderValues));
	}
	mapResult(response, isFromBatch) {
		switch (this.executeMethod) {
			case "run": return this.mapRunResult(response, isFromBatch);
			case "all": return this.mapAllResult(response, isFromBatch);
			case "get": return this.mapGetResult(response, isFromBatch);
		}
	}
};
var SQLiteSession = class {
	constructor(dialect) {
		this.dialect = dialect;
	}
	static [require_utils$1.entityKind] = "SQLiteSession";
	prepareOneTimeQuery(query, fields, executeMethod, isResponseInArrayMode, customResultMapper, queryMetadata, cacheConfig) {
		return this.prepareQuery(query, fields, executeMethod, isResponseInArrayMode, customResultMapper, queryMetadata, cacheConfig);
	}
	run(query) {
		const staticQuery = this.dialect.sqlToQuery(query);
		try {
			return this.prepareOneTimeQuery(staticQuery, void 0, "run", false).run();
		} catch (err) {
			throw new require_drizzle_orm.DrizzleError({
				cause: err,
				message: `Failed to run the query '${staticQuery.sql}'`
			});
		}
	}
	/** @internal */
	extractRawRunValueFromBatchResult(result) {
		return result;
	}
	all(query) {
		return this.prepareOneTimeQuery(this.dialect.sqlToQuery(query), void 0, "run", false).all();
	}
	/** @internal */
	extractRawAllValueFromBatchResult(_result) {
		throw new Error("Not implemented");
	}
	get(query) {
		return this.prepareOneTimeQuery(this.dialect.sqlToQuery(query), void 0, "run", false).get();
	}
	/** @internal */
	extractRawGetValueFromBatchResult(_result) {
		throw new Error("Not implemented");
	}
	values(query) {
		return this.prepareOneTimeQuery(this.dialect.sqlToQuery(query), void 0, "run", false).values();
	}
	async count(sql) {
		return (await this.values(sql))[0][0];
	}
	/** @internal */
	extractRawValuesValueFromBatchResult(_result) {
		throw new Error("Not implemented");
	}
};
var SQLiteTransaction = class extends BaseSQLiteDatabase {
	constructor(resultType, dialect, session, schema, nestedIndex = 0) {
		super(resultType, dialect, session, schema);
		this.schema = schema;
		this.nestedIndex = nestedIndex;
	}
	static [require_utils$1.entityKind] = "SQLiteTransaction";
	rollback() {
		throw new require_drizzle_orm.TransactionRollbackError();
	}
};
//#endregion
//#region electron/services/conversation.service.ts
/**
* Create a new conversation
* @param data Conversation data (title)
* @param db Drizzle ORM instance
* @returns Created conversation with id and timestamps
*/
async function createConversation(data, db) {
	const now = /* @__PURE__ */ new Date();
	const id = crypto.randomUUID();
	const [conversation] = await db.insert(require_schema$1.conversations).values({
		id,
		title: data.title,
		created_at: now,
		updated_at: now
	}).returning();
	return conversation;
}
/**
* Get a conversation by ID with all messages and citations
* @param id Conversation ID
* @param db Drizzle ORM instance
* @returns Conversation with messages and citations, or null if not found
*/
async function getConversation(id, db) {
	const [conversation] = await db.select().from(require_schema$1.conversations).where(require_drizzle_orm.eq(require_schema$1.conversations.id, id)).limit(1);
	if (!conversation) return null;
	const conversationMessages = await db.select().from(require_schema$1.messages).where(require_drizzle_orm.eq(require_schema$1.messages.conversation_id, id)).orderBy(require_schema$1.messages.created_at);
	const messageIds = conversationMessages.map((m) => m.id);
	let allCitations = [];
	if (messageIds.length > 0) {
		allCitations = await db.select().from(require_schema$1.citations).where(require_drizzle_orm.eq(require_schema$1.citations.message_id, messageIds[0]));
		for (let i = 1; i < messageIds.length; i++) {
			const moreCitations = await db.select().from(require_schema$1.citations).where(require_drizzle_orm.eq(require_schema$1.citations.message_id, messageIds[i]));
			allCitations.push(...moreCitations);
		}
	}
	const citationsByMessage = /* @__PURE__ */ new Map();
	for (const citation of allCitations) {
		if (!citationsByMessage.has(citation.message_id)) citationsByMessage.set(citation.message_id, []);
		citationsByMessage.get(citation.message_id).push(citation);
	}
	const messagesWithCitations = conversationMessages.map((msg) => ({
		...msg,
		citations: citationsByMessage.get(msg.id) || []
	}));
	return {
		...conversation,
		messages: messagesWithCitations
	};
}
/**
* Get all conversations (without messages for list view performance)
* @param db Drizzle ORM instance
* @returns Array of conversations ordered by updated_at DESC
*/
async function getAllConversations(db) {
	return await db.select().from(require_schema$1.conversations).orderBy(require_drizzle_orm.desc(require_schema$1.conversations.updated_at));
}
/**
* Delete a conversation (cascades to messages and citations)
* @param id Conversation ID
* @param db Drizzle ORM instance
* @returns void
*/
async function deleteConversation(id, db) {
	await db.delete(require_schema$1.conversations).where(require_drizzle_orm.eq(require_schema$1.conversations.id, id));
}
//#endregion
//#region node_modules/drizzle-orm/better-sqlite3/session.js
var BetterSQLiteSession = class extends SQLiteSession {
	constructor(client, dialect, schema, options = {}) {
		super(dialect);
		this.client = client;
		this.schema = schema;
		this.logger = options.logger ?? new require_drizzle_orm.NoopLogger();
		this.cache = options.cache ?? new NoopCache();
	}
	static [require_utils$1.entityKind] = "BetterSQLiteSession";
	logger;
	cache;
	prepareQuery(query, fields, executeMethod, isResponseInArrayMode, customResultMapper, queryMetadata, cacheConfig) {
		return new PreparedQuery(this.client.prepare(query.sql), query, this.logger, this.cache, queryMetadata, cacheConfig, fields, executeMethod, isResponseInArrayMode, customResultMapper);
	}
	transaction(transaction, config = {}) {
		const tx = new BetterSQLiteTransaction("sync", this.dialect, this, this.schema);
		return this.client.transaction(transaction)[config.behavior ?? "deferred"](tx);
	}
};
var BetterSQLiteTransaction = class BetterSQLiteTransaction extends SQLiteTransaction {
	static [require_utils$1.entityKind] = "BetterSQLiteTransaction";
	transaction(transaction) {
		const savepointName = `sp${this.nestedIndex}`;
		const tx = new BetterSQLiteTransaction("sync", this.dialect, this.session, this.schema, this.nestedIndex + 1);
		this.session.run(require_utils$1.sql.raw(`savepoint ${savepointName}`));
		try {
			const result = transaction(tx);
			this.session.run(require_utils$1.sql.raw(`release savepoint ${savepointName}`));
			return result;
		} catch (err) {
			this.session.run(require_utils$1.sql.raw(`rollback to savepoint ${savepointName}`));
			throw err;
		}
	}
};
var PreparedQuery = class extends SQLitePreparedQuery {
	constructor(stmt, query, logger, cache, queryMetadata, cacheConfig, fields, executeMethod, _isResponseInArrayMode, customResultMapper) {
		super("sync", executeMethod, query, cache, queryMetadata, cacheConfig);
		this.stmt = stmt;
		this.logger = logger;
		this.fields = fields;
		this._isResponseInArrayMode = _isResponseInArrayMode;
		this.customResultMapper = customResultMapper;
	}
	static [require_utils$1.entityKind] = "BetterSQLitePreparedQuery";
	run(placeholderValues) {
		const params = require_utils$1.fillPlaceholders(this.query.params, placeholderValues ?? {});
		this.logger.logQuery(this.query.sql, params);
		return this.stmt.run(...params);
	}
	all(placeholderValues) {
		const { fields, joinsNotNullableMap, query, logger, stmt, customResultMapper } = this;
		if (!fields && !customResultMapper) {
			const params = require_utils$1.fillPlaceholders(query.params, placeholderValues ?? {});
			logger.logQuery(query.sql, params);
			return stmt.all(...params);
		}
		const rows = this.values(placeholderValues);
		if (customResultMapper) return customResultMapper(rows);
		return rows.map((row) => require_utils$1.mapResultRow(fields, row, joinsNotNullableMap));
	}
	get(placeholderValues) {
		const params = require_utils$1.fillPlaceholders(this.query.params, placeholderValues ?? {});
		this.logger.logQuery(this.query.sql, params);
		const { fields, stmt, joinsNotNullableMap, customResultMapper } = this;
		if (!fields && !customResultMapper) return stmt.get(...params);
		const row = stmt.raw().get(...params);
		if (!row) return;
		if (customResultMapper) return customResultMapper([row]);
		return require_utils$1.mapResultRow(fields, row, joinsNotNullableMap);
	}
	values(placeholderValues) {
		const params = require_utils$1.fillPlaceholders(this.query.params, placeholderValues ?? {});
		this.logger.logQuery(this.query.sql, params);
		return this.stmt.raw().all(...params);
	}
	/** @internal */
	isResponseInArrayMode() {
		return this._isResponseInArrayMode;
	}
};
//#endregion
//#region node_modules/drizzle-orm/better-sqlite3/driver.js
var BetterSQLite3Database = class extends BaseSQLiteDatabase {
	static [require_utils$1.entityKind] = "BetterSQLite3Database";
};
function construct(client, config = {}) {
	const dialect = new SQLiteSyncDialect({ casing: config.casing });
	let logger;
	if (config.logger === true) logger = new require_drizzle_orm.DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	let schema;
	if (config.schema) {
		const tablesConfig = require_drizzle_orm.extractTablesRelationalConfig(config.schema, require_drizzle_orm.createTableRelationsHelpers);
		schema = {
			fullSchema: config.schema,
			schema: tablesConfig.tables,
			tableNamesMap: tablesConfig.tableNamesMap
		};
	}
	const db = new BetterSQLite3Database("sync", dialect, new BetterSQLiteSession(client, dialect, schema, { logger }), schema);
	db.$client = client;
	return db;
}
function drizzle(...params) {
	if (params[0] === void 0 || typeof params[0] === "string") return construct(params[0] === void 0 ? new better_sqlite3$1.default() : new better_sqlite3$1.default(params[0]), params[1]);
	if (require_utils$1.isConfig(params[0])) {
		const { connection, client, ...drizzleConfig } = params[0];
		if (client) return construct(client, drizzleConfig);
		if (typeof connection === "object") {
			const { source, ...options } = connection;
			return construct(new better_sqlite3$1.default(source, options), drizzleConfig);
		}
		return construct(new better_sqlite3$1.default(connection), drizzleConfig);
	}
	return construct(params[0], params[1]);
}
((drizzle2) => {
	function mock(config) {
		return construct({}, config);
	}
	drizzle2.mock = mock;
})(drizzle || (drizzle = {}));
//#endregion
//#region electron/database/connection.ts
var db = null;
var orm = null;
/**
* Get the Drizzle ORM instance
* @returns Drizzle ORM instance
* @throws Error if database not initialized
*/
function getORM() {
	if (!orm) throw new Error("Database not initialized. Call initDatabase() first.");
	return orm;
}
/**
* Initialize the database connection and create tables
* @param dbPath Path to the database file
*/
async function initDatabase(dbPath) {
	if (db) db.close();
	db = new better_sqlite3.default(dbPath);
	db.pragma("recursive_triggers = OFF");
	db.pragma("journal_mode = DELETE");
	db.pragma("foreign_keys = OFF");
	db.exec(`
    CREATE TABLE IF NOT EXISTS notes (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      metadata TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      deleted_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS tags (
      id TEXT PRIMARY KEY,
      name TEXT UNIQUE NOT NULL,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS note_tags (
      note_id TEXT NOT NULL,
      tag_id TEXT NOT NULL,
      PRIMARY KEY (note_id, tag_id),
      FOREIGN KEY (note_id) REFERENCES notes(id) ON DELETE CASCADE,
      FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS links (
      id TEXT PRIMARY KEY,
      source_note_id TEXT NOT NULL,
      target_note_id TEXT NOT NULL,
      link_type TEXT NOT NULL DEFAULT 'manual',
      similarity_score REAL,
      created_at INTEGER NOT NULL,
      FOREIGN KEY (source_note_id) REFERENCES notes(id) ON DELETE CASCADE,
      FOREIGN KEY (target_note_id) REFERENCES notes(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS note_versions (
      id TEXT PRIMARY KEY,
      note_id TEXT NOT NULL,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      metadata TEXT,
      version_number INTEGER NOT NULL,
      created_at INTEGER NOT NULL,
      FOREIGN KEY (note_id) REFERENCES notes(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS conversations (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('user', 'assistant', 'system')),
      content TEXT NOT NULL,
      provider_id TEXT,
      model TEXT,
      created_at INTEGER NOT NULL,
      FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS citations (
      id TEXT PRIMARY KEY,
      message_id TEXT NOT NULL,
      url TEXT NOT NULL,
      title TEXT NOT NULL,
      snippet TEXT,
      position INTEGER NOT NULL,
      created_at INTEGER NOT NULL,
      FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS content (
      id TEXT PRIMARY KEY,
      file_path TEXT NOT NULL,
      thumbnail_path TEXT,
      mime_type TEXT NOT NULL,
      original_filename TEXT NOT NULL,
      file_size INTEGER NOT NULL,
      extracted_text TEXT,
      source TEXT NOT NULL,
      confidence_score INTEGER,
      metadata TEXT,
      note_id TEXT,
      message_id TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      FOREIGN KEY (note_id) REFERENCES notes(id) ON DELETE SET NULL,
      FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS content_tags (
      content_id TEXT NOT NULL,
      tag_id TEXT NOT NULL,
      PRIMARY KEY (content_id, tag_id),
      FOREIGN KEY (content_id) REFERENCES content(id) ON DELETE CASCADE,
      FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
    );

    -- Embeddings table disabled until sqlite-vec extension available
    -- CREATE TABLE IF NOT EXISTS embeddings (
    --   id TEXT PRIMARY KEY,
    --   note_id TEXT NOT NULL UNIQUE,
    --   vector BLOB NOT NULL,
    --   model TEXT NOT NULL DEFAULT 'all-MiniLM-L6-v2',
    --   dimensions INTEGER NOT NULL DEFAULT 384,
    --   created_at INTEGER NOT NULL,
    --   updated_at INTEGER NOT NULL,
    --   FOREIGN KEY (note_id) REFERENCES notes(id) ON DELETE CASCADE
    -- );
  `);
	orm = drizzle(db, { schema: require_schema$1.schema_exports });
	try {
		const result = db.pragma("integrity_check", { simple: true });
		console.log("[DB] Integrity check:", result);
		if (result !== "ok") {
			console.error("[DB] Database integrity check failed:", result);
			throw new Error("Database integrity check failed");
		}
	} catch (error) {
		console.error("[DB] Integrity check error:", error);
		throw error;
	}
}
//#endregion
//#region electron/services/message.service.ts
/**
* Message service - handles message CRUD operations
*/
async function createMessage(data) {
	const db = await getORM();
	const message = {
		id: (0, crypto$1.randomUUID)(),
		conversation_id: data.conversation_id,
		role: data.role,
		content: data.content,
		provider_id: data.provider_id,
		model: data.model,
		created_at: /* @__PURE__ */ new Date()
	};
	await db.insert(require_schema$1.messages).values(message);
	return message;
}
async function getMessagesByConversation(conversationId) {
	return await (await getORM()).select().from(require_schema$1.messages).where(require_drizzle_orm.eq(require_schema$1.messages.conversation_id, conversationId)).orderBy(require_schema$1.messages.created_at);
}
//#endregion
//#region electron/api/routes.ts
/**
* HTTP REST API routes for web version
*/
var router = (0, express.Router)();
router.use((req, res, next) => {
	console.log(`[API] ${req.method} ${req.path}`);
	next();
});
router.get("/api/providers", async (req, res) => {
	try {
		const providers = loadAllProvidersFromEnv();
		res.json({
			success: true,
			providers
		});
	} catch (error) {
		res.status(500).json({
			success: false,
			error: error.message
		});
	}
});
router.get("/api/providers/:id", async (req, res) => {
	try {
		const config = loadProviderFromEnv(req.params.id);
		if (!config) return res.status(404).json({
			success: false,
			error: "Provider not found"
		});
		res.json({
			success: true,
			config
		});
	} catch (error) {
		res.status(500).json({
			success: false,
			error: error.message
		});
	}
});
router.post("/api/providers", async (req, res) => {
	try {
		const { id, apiKey, model, baseURL } = req.body;
		if (!id || !apiKey || !model) return res.status(400).json({
			success: false,
			error: "Missing required fields: id, apiKey, model"
		});
		saveProviderToEnv({
			id,
			apiKey,
			model,
			baseURL
		});
		res.json({ success: true });
	} catch (error) {
		res.status(500).json({
			success: false,
			error: error.message
		});
	}
});
router.delete("/api/providers/:id", async (req, res) => {
	try {
		deleteProviderFromEnv(req.params.id);
		res.json({ success: true });
	} catch (error) {
		res.status(500).json({
			success: false,
			error: error.message
		});
	}
});
router.get("/api/conversations", async (req, res) => {
	try {
		const conversations = await getAllConversations(getORM());
		res.json({
			success: true,
			conversations
		});
	} catch (error) {
		res.status(500).json({
			success: false,
			error: error.message
		});
	}
});
router.post("/api/conversations", async (req, res) => {
	try {
		const { title } = req.body;
		if (!title) return res.status(400).json({
			success: false,
			error: "Missing required field: title"
		});
		const db = getORM();
		const conversation = await createConversation({ title }, db);
		res.json({
			success: true,
			conversation
		});
	} catch (error) {
		res.status(500).json({
			success: false,
			error: error.message
		});
	}
});
router.get("/api/conversations/:id", async (req, res) => {
	try {
		const db = getORM();
		const conversation = await getConversation(req.params.id, db);
		if (!conversation) return res.status(404).json({
			success: false,
			error: "Conversation not found"
		});
		res.json({
			success: true,
			conversation
		});
	} catch (error) {
		res.status(500).json({
			success: false,
			error: error.message
		});
	}
});
router.patch("/api/conversations/:id", async (req, res) => {
	try {
		const { title } = req.body;
		if (!title) return res.status(400).json({
			success: false,
			error: "Missing required field: title"
		});
		const db = getORM();
		if (!await getConversation(req.params.id, db)) return res.status(404).json({
			success: false,
			error: "Conversation not found"
		});
		const { conversations } = await Promise.resolve().then(() => require("./schema-Cofpqhhy.js")).then((n) => n.schema_exports);
		const { eq } = await Promise.resolve().then(() => require("./drizzle-orm-D27XQ0Pd.js")).then((n) => n.drizzle_orm_exports);
		await db.update(conversations).set({
			title,
			updated_at: /* @__PURE__ */ new Date()
		}).where(eq(conversations.id, req.params.id));
		res.json({ success: true });
	} catch (error) {
		res.status(500).json({
			success: false,
			error: error.message
		});
	}
});
router.delete("/api/conversations/:id", async (req, res) => {
	try {
		const db = getORM();
		await deleteConversation(req.params.id, db);
		res.json({ success: true });
	} catch (error) {
		res.status(500).json({
			success: false,
			error: error.message
		});
	}
});
router.get("/api/conversations/:id/messages", async (req, res) => {
	try {
		const db = getORM();
		const messages = await getMessagesByConversation(req.params.id, db);
		res.json({
			success: true,
			messages
		});
	} catch (error) {
		res.status(500).json({
			success: false,
			error: error.message
		});
	}
});
router.post("/api/chat", async (req, res) => {
	try {
		const { conversationId, messages, providerId, model } = req.body;
		if (!conversationId || !messages || !Array.isArray(messages)) return res.status(400).json({
			success: false,
			error: "Missing required fields: conversationId, messages (array)"
		});
		const { callDeepSeek, callClaude, callOpenAI } = await Promise.resolve().then(() => ai_handlers_exports);
		const provider = providerId || "deepseek";
		const config = loadProviderFromEnv(provider);
		if (!config) return res.status(400).json({
			success: false,
			error: `Provider ${provider} not configured`
		});
		const modelToUse = model || config.model;
		const db = getORM();
		const userMessage = messages[messages.length - 1];
		if (userMessage.role === "user") await createMessage({
			conversation_id: conversationId,
			role: userMessage.role,
			content: userMessage.content
		}, db);
		let response;
		switch (config.id) {
			case "deepseek":
				response = await callDeepSeek(messages, config.apiKey, modelToUse);
				break;
			case "claude":
				response = await callClaude(messages, config.apiKey, modelToUse, config.baseURL);
				break;
			case "openai":
				response = await callOpenAI(messages, config.apiKey, modelToUse, config.baseURL);
				break;
			default: return res.status(400).json({
				success: false,
				error: `Unsupported provider: ${config.id}`
			});
		}
		await createMessage({
			conversation_id: conversationId,
			role: "assistant",
			content: response,
			provider_id: config.id,
			model: modelToUse
		}, db);
		res.json({
			success: true,
			content: response
		});
	} catch (error) {
		res.status(500).json({
			success: false,
			error: error.message
		});
	}
});
//#endregion
//#region electron/server.ts
async function startServer(port = 3e3, distPath) {
	const app = (0, express.default)();
	app.use(express.default.json());
	app.use(express.default.urlencoded({ extended: true }));
	app.use((req, res, next) => {
		res.header("Access-Control-Allow-Origin", "*");
		res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
		res.header("Access-Control-Allow-Headers", "Content-Type, Authorization");
		if (req.method === "OPTIONS") return res.sendStatus(200);
		next();
	});
	app.use(router);
	app.use(express.default.static(distPath));
	app.use((_req, res) => {
		const indexPath = path.default.resolve(distPath, "index.html");
		res.sendFile(indexPath);
	});
	return new Promise((resolve, reject) => {
		const server = app.listen(port, () => {
			console.log(`Web server started on http://localhost:${port}`);
			resolve({
				server,
				port
			});
		});
		server.on("error", (error) => {
			if (error.code === "EADDRINUSE") {
				console.error(`Port ${port} is already in use, trying ${port + 1}`);
				const nextPort = port + 1;
				app.listen(nextPort, () => {
					console.log(`Web server started on http://localhost:${nextPort}`);
					resolve({
						server,
						port: nextPort
					});
				});
			} else reject(error);
		});
	});
}
function stopServer(instance) {
	return new Promise((resolve, reject) => {
		instance.server.close((err) => {
			if (err) reject(err);
			else {
				console.log("Web server stopped");
				resolve();
			}
		});
	});
}
//#endregion
//#region electron/windowState.ts
async function getWindowState() {
	const config = await loadConfig();
	if (config.windowBounds && isOnScreen(config.windowBounds)) return config.windowBounds;
	return {
		x: void 0,
		y: void 0,
		width: 1200,
		height: 800
	};
}
async function saveWindowState(window) {
	await updateConfig({ windowBounds: window.getBounds() });
}
function isOnScreen(bounds) {
	try {
		return electron.screen.getDisplayMatching({
			x: bounds.x || 0,
			y: bounds.y || 0,
			width: bounds.width,
			height: bounds.height
		}) !== null;
	} catch {
		return false;
	}
}
//#endregion
//#region electron/tray.ts
function createTray(window, currentMode, onModeSwitch) {
	const iconPath = path.default.join(electron.app.getAppPath(), "resources/icon.svg");
	const tray = new electron.Tray(electron.nativeImage.createFromPath(iconPath).resize({
		width: 16,
		height: 16
	}));
	tray.setToolTip("LibraNia");
	const contextMenu = electron.Menu.buildFromTemplate([
		{
			label: "Show LibraNia",
			click: () => {
				window.show();
				window.focus();
			}
		},
		{ type: "separator" },
		{
			label: "Mode",
			submenu: [{
				label: "Desktop",
				type: "radio",
				checked: currentMode === "desktop",
				click: () => onModeSwitch("desktop")
			}, {
				label: "Web",
				type: "radio",
				checked: currentMode === "web",
				click: () => onModeSwitch("web")
			}]
		},
		{ type: "separator" },
		{
			label: "Quit",
			click: () => electron.app.quit()
		}
	]);
	tray.setContextMenu(contextMenu);
	tray.on("click", () => {
		if (window.isVisible()) window.hide();
		else {
			window.show();
			window.focus();
		}
	});
	return tray;
}
//#endregion
//#region node_modules/kind-of/index.js
var require_kind_of = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var toString = Object.prototype.toString;
	module.exports = function kindOf(val) {
		if (val === void 0) return "undefined";
		if (val === null) return "null";
		var type = typeof val;
		if (type === "boolean") return "boolean";
		if (type === "string") return "string";
		if (type === "number") return "number";
		if (type === "symbol") return "symbol";
		if (type === "function") return isGeneratorFn(val) ? "generatorfunction" : "function";
		if (isArray(val)) return "array";
		if (isBuffer(val)) return "buffer";
		if (isArguments(val)) return "arguments";
		if (isDate(val)) return "date";
		if (isError(val)) return "error";
		if (isRegexp(val)) return "regexp";
		switch (ctorName(val)) {
			case "Symbol": return "symbol";
			case "Promise": return "promise";
			case "WeakMap": return "weakmap";
			case "WeakSet": return "weakset";
			case "Map": return "map";
			case "Set": return "set";
			case "Int8Array": return "int8array";
			case "Uint8Array": return "uint8array";
			case "Uint8ClampedArray": return "uint8clampedarray";
			case "Int16Array": return "int16array";
			case "Uint16Array": return "uint16array";
			case "Int32Array": return "int32array";
			case "Uint32Array": return "uint32array";
			case "Float32Array": return "float32array";
			case "Float64Array": return "float64array";
		}
		if (isGeneratorObj(val)) return "generator";
		type = toString.call(val);
		switch (type) {
			case "[object Object]": return "object";
			case "[object Map Iterator]": return "mapiterator";
			case "[object Set Iterator]": return "setiterator";
			case "[object String Iterator]": return "stringiterator";
			case "[object Array Iterator]": return "arrayiterator";
		}
		return type.slice(8, -1).toLowerCase().replace(/\s/g, "");
	};
	function ctorName(val) {
		return typeof val.constructor === "function" ? val.constructor.name : null;
	}
	function isArray(val) {
		if (Array.isArray) return Array.isArray(val);
		return val instanceof Array;
	}
	function isError(val) {
		return val instanceof Error || typeof val.message === "string" && val.constructor && typeof val.constructor.stackTraceLimit === "number";
	}
	function isDate(val) {
		if (val instanceof Date) return true;
		return typeof val.toDateString === "function" && typeof val.getDate === "function" && typeof val.setDate === "function";
	}
	function isRegexp(val) {
		if (val instanceof RegExp) return true;
		return typeof val.flags === "string" && typeof val.ignoreCase === "boolean" && typeof val.multiline === "boolean" && typeof val.global === "boolean";
	}
	function isGeneratorFn(name, val) {
		return ctorName(name) === "GeneratorFunction";
	}
	function isGeneratorObj(val) {
		return typeof val.throw === "function" && typeof val.return === "function" && typeof val.next === "function";
	}
	function isArguments(val) {
		try {
			if (typeof val.length === "number" && typeof val.callee === "function") return true;
		} catch (err) {
			if (err.message.indexOf("callee") !== -1) return true;
		}
		return false;
	}
	/**
	* If you need to support Safari 5-7 (8-10 yr-old browser),
	* take a look at https://github.com/feross/is-buffer
	*/
	function isBuffer(val) {
		if (val.constructor && typeof val.constructor.isBuffer === "function") return val.constructor.isBuffer(val);
		return false;
	}
}));
//#endregion
//#region node_modules/is-extendable/index.js
/*!
* is-extendable <https://github.com/jonschlinkert/is-extendable>
*
* Copyright (c) 2015, Jon Schlinkert.
* Licensed under the MIT License.
*/
var require_is_extendable = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	module.exports = function isExtendable(val) {
		return typeof val !== "undefined" && val !== null && (typeof val === "object" || typeof val === "function");
	};
}));
//#endregion
//#region node_modules/extend-shallow/index.js
var require_extend_shallow = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var isObject = require_is_extendable();
	module.exports = function extend(o) {
		if (!isObject(o)) o = {};
		var len = arguments.length;
		for (var i = 1; i < len; i++) {
			var obj = arguments[i];
			if (isObject(obj)) assign(o, obj);
		}
		return o;
	};
	function assign(a, b) {
		for (var key in b) if (hasOwn(b, key)) a[key] = b[key];
	}
	/**
	* Returns true if the given `key` is an own property of `obj`.
	*/
	function hasOwn(obj, key) {
		return Object.prototype.hasOwnProperty.call(obj, key);
	}
}));
//#endregion
//#region node_modules/section-matter/index.js
var require_section_matter = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var typeOf = require_kind_of();
	var extend = require_extend_shallow();
	/**
	* Parse sections in `input` with the given `options`.
	*
	* ```js
	* var sections = require('{%= name %}');
	* var result = sections(input, options);
	* // { content: 'Content before sections', sections: [] }
	* ```
	* @param {String|Buffer|Object} `input` If input is an object, it's `content` property must be a string or buffer.
	* @param {Object} options
	* @return {Object} Returns an object with a `content` string and an array of `sections` objects.
	* @api public
	*/
	module.exports = function(input, options) {
		if (typeof options === "function") options = { parse: options };
		var file = toObject(input);
		var opts = extend({}, {
			section_delimiter: "---",
			parse: identity
		}, options);
		var delim = opts.section_delimiter;
		var lines = file.content.split(/\r?\n/);
		var sections = null;
		var section = createSection();
		var content = [];
		var stack = [];
		function initSections(val) {
			file.content = val;
			sections = [];
			content = [];
		}
		function closeSection(val) {
			if (stack.length) {
				section.key = getKey(stack[0], delim);
				section.content = val;
				opts.parse(section, sections);
				sections.push(section);
				section = createSection();
				content = [];
				stack = [];
			}
		}
		for (var i = 0; i < lines.length; i++) {
			var line = lines[i];
			var len = stack.length;
			var ln = line.trim();
			if (isDelimiter(ln, delim)) {
				if (ln.length === 3 && i !== 0) {
					if (len === 0 || len === 2) {
						content.push(line);
						continue;
					}
					stack.push(ln);
					section.data = content.join("\n");
					content = [];
					continue;
				}
				if (sections === null) initSections(content.join("\n"));
				if (len === 2) closeSection(content.join("\n"));
				stack.push(ln);
				continue;
			}
			content.push(line);
		}
		if (sections === null) initSections(content.join("\n"));
		else closeSection(content.join("\n"));
		file.sections = sections;
		return file;
	};
	function isDelimiter(line, delim) {
		if (line.slice(0, delim.length) !== delim) return false;
		if (line.charAt(delim.length + 1) === delim.slice(-1)) return false;
		return true;
	}
	function toObject(input) {
		if (typeOf(input) !== "object") input = { content: input };
		if (typeof input.content !== "string" && !isBuffer(input.content)) throw new TypeError("expected a buffer or string");
		input.content = input.content.toString();
		input.sections = [];
		return input;
	}
	function getKey(val, delim) {
		return val ? val.slice(delim.length).trim() : "";
	}
	function createSection() {
		return {
			key: "",
			data: "",
			content: ""
		};
	}
	function identity(val) {
		return val;
	}
	function isBuffer(val) {
		if (val && val.constructor && typeof val.constructor.isBuffer === "function") return val.constructor.isBuffer(val);
		return false;
	}
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/common.js
var require_common = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	function isNothing(subject) {
		return typeof subject === "undefined" || subject === null;
	}
	function isObject(subject) {
		return typeof subject === "object" && subject !== null;
	}
	function toArray(sequence) {
		if (Array.isArray(sequence)) return sequence;
		else if (isNothing(sequence)) return [];
		return [sequence];
	}
	function extend(target, source) {
		var index, length, key, sourceKeys;
		if (source) {
			sourceKeys = Object.keys(source);
			for (index = 0, length = sourceKeys.length; index < length; index += 1) {
				key = sourceKeys[index];
				target[key] = source[key];
			}
		}
		return target;
	}
	function repeat(string, count) {
		var result = "", cycle;
		for (cycle = 0; cycle < count; cycle += 1) result += string;
		return result;
	}
	function isNegativeZero(number) {
		return number === 0 && Number.NEGATIVE_INFINITY === 1 / number;
	}
	module.exports.isNothing = isNothing;
	module.exports.isObject = isObject;
	module.exports.toArray = toArray;
	module.exports.repeat = repeat;
	module.exports.isNegativeZero = isNegativeZero;
	module.exports.extend = extend;
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/exception.js
var require_exception = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	function YAMLException(reason, mark) {
		Error.call(this);
		this.name = "YAMLException";
		this.reason = reason;
		this.mark = mark;
		this.message = (this.reason || "(unknown reason)") + (this.mark ? " " + this.mark.toString() : "");
		if (Error.captureStackTrace) Error.captureStackTrace(this, this.constructor);
		else this.stack = (/* @__PURE__ */ new Error()).stack || "";
	}
	YAMLException.prototype = Object.create(Error.prototype);
	YAMLException.prototype.constructor = YAMLException;
	YAMLException.prototype.toString = function toString(compact) {
		var result = this.name + ": ";
		result += this.reason || "(unknown reason)";
		if (!compact && this.mark) result += " " + this.mark.toString();
		return result;
	};
	module.exports = YAMLException;
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/mark.js
var require_mark = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var common = require_common();
	function Mark(name, buffer, position, line, column) {
		this.name = name;
		this.buffer = buffer;
		this.position = position;
		this.line = line;
		this.column = column;
	}
	Mark.prototype.getSnippet = function getSnippet(indent, maxLength) {
		var head, start, tail, end, snippet;
		if (!this.buffer) return null;
		indent = indent || 4;
		maxLength = maxLength || 75;
		head = "";
		start = this.position;
		while (start > 0 && "\0\r\n\u2028\u2029".indexOf(this.buffer.charAt(start - 1)) === -1) {
			start -= 1;
			if (this.position - start > maxLength / 2 - 1) {
				head = " ... ";
				start += 5;
				break;
			}
		}
		tail = "";
		end = this.position;
		while (end < this.buffer.length && "\0\r\n\u2028\u2029".indexOf(this.buffer.charAt(end)) === -1) {
			end += 1;
			if (end - this.position > maxLength / 2 - 1) {
				tail = " ... ";
				end -= 5;
				break;
			}
		}
		snippet = this.buffer.slice(start, end);
		return common.repeat(" ", indent) + head + snippet + tail + "\n" + common.repeat(" ", indent + this.position - start + head.length) + "^";
	};
	Mark.prototype.toString = function toString(compact) {
		var snippet, where = "";
		if (this.name) where += "in \"" + this.name + "\" ";
		where += "at line " + (this.line + 1) + ", column " + (this.column + 1);
		if (!compact) {
			snippet = this.getSnippet();
			if (snippet) where += ":\n" + snippet;
		}
		return where;
	};
	module.exports = Mark;
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/type.js
var require_type = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var YAMLException = require_exception();
	var TYPE_CONSTRUCTOR_OPTIONS = [
		"kind",
		"resolve",
		"construct",
		"instanceOf",
		"predicate",
		"represent",
		"defaultStyle",
		"styleAliases"
	];
	var YAML_NODE_KINDS = [
		"scalar",
		"sequence",
		"mapping"
	];
	function compileStyleAliases(map) {
		var result = {};
		if (map !== null) Object.keys(map).forEach(function(style) {
			map[style].forEach(function(alias) {
				result[String(alias)] = style;
			});
		});
		return result;
	}
	function Type(tag, options) {
		options = options || {};
		Object.keys(options).forEach(function(name) {
			if (TYPE_CONSTRUCTOR_OPTIONS.indexOf(name) === -1) throw new YAMLException("Unknown option \"" + name + "\" is met in definition of \"" + tag + "\" YAML type.");
		});
		this.tag = tag;
		this.kind = options["kind"] || null;
		this.resolve = options["resolve"] || function() {
			return true;
		};
		this.construct = options["construct"] || function(data) {
			return data;
		};
		this.instanceOf = options["instanceOf"] || null;
		this.predicate = options["predicate"] || null;
		this.represent = options["represent"] || null;
		this.defaultStyle = options["defaultStyle"] || null;
		this.styleAliases = compileStyleAliases(options["styleAliases"] || null);
		if (YAML_NODE_KINDS.indexOf(this.kind) === -1) throw new YAMLException("Unknown kind \"" + this.kind + "\" is specified for \"" + tag + "\" YAML type.");
	}
	module.exports = Type;
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/schema.js
var require_schema = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var common = require_common();
	var YAMLException = require_exception();
	var Type = require_type();
	function compileList(schema, name, result) {
		var exclude = [];
		schema.include.forEach(function(includedSchema) {
			result = compileList(includedSchema, name, result);
		});
		schema[name].forEach(function(currentType) {
			result.forEach(function(previousType, previousIndex) {
				if (previousType.tag === currentType.tag && previousType.kind === currentType.kind) exclude.push(previousIndex);
			});
			result.push(currentType);
		});
		return result.filter(function(type, index) {
			return exclude.indexOf(index) === -1;
		});
	}
	function compileMap() {
		var result = {
			scalar: {},
			sequence: {},
			mapping: {},
			fallback: {}
		}, index, length;
		function collectType(type) {
			result[type.kind][type.tag] = result["fallback"][type.tag] = type;
		}
		for (index = 0, length = arguments.length; index < length; index += 1) arguments[index].forEach(collectType);
		return result;
	}
	function Schema(definition) {
		this.include = definition.include || [];
		this.implicit = definition.implicit || [];
		this.explicit = definition.explicit || [];
		this.implicit.forEach(function(type) {
			if (type.loadKind && type.loadKind !== "scalar") throw new YAMLException("There is a non-scalar type in the implicit list of a schema. Implicit resolving of such types is not supported.");
		});
		this.compiledImplicit = compileList(this, "implicit", []);
		this.compiledExplicit = compileList(this, "explicit", []);
		this.compiledTypeMap = compileMap(this.compiledImplicit, this.compiledExplicit);
	}
	Schema.DEFAULT = null;
	Schema.create = function createSchema() {
		var schemas, types;
		switch (arguments.length) {
			case 1:
				schemas = Schema.DEFAULT;
				types = arguments[0];
				break;
			case 2:
				schemas = arguments[0];
				types = arguments[1];
				break;
			default: throw new YAMLException("Wrong number of arguments for Schema.create function");
		}
		schemas = common.toArray(schemas);
		types = common.toArray(types);
		if (!schemas.every(function(schema) {
			return schema instanceof Schema;
		})) throw new YAMLException("Specified list of super schemas (or a single Schema object) contains a non-Schema object.");
		if (!types.every(function(type) {
			return type instanceof Type;
		})) throw new YAMLException("Specified list of YAML types (or a single Type object) contains a non-Type object.");
		return new Schema({
			include: schemas,
			explicit: types
		});
	};
	module.exports = Schema;
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/type/str.js
var require_str = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	module.exports = new (require_type())("tag:yaml.org,2002:str", {
		kind: "scalar",
		construct: function(data) {
			return data !== null ? data : "";
		}
	});
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/type/seq.js
var require_seq = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	module.exports = new (require_type())("tag:yaml.org,2002:seq", {
		kind: "sequence",
		construct: function(data) {
			return data !== null ? data : [];
		}
	});
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/type/map.js
var require_map = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	module.exports = new (require_type())("tag:yaml.org,2002:map", {
		kind: "mapping",
		construct: function(data) {
			return data !== null ? data : {};
		}
	});
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/schema/failsafe.js
var require_failsafe = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	module.exports = new (require_schema())({ explicit: [
		require_str(),
		require_seq(),
		require_map()
	] });
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/type/null.js
var require_null = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var Type = require_type();
	function resolveYamlNull(data) {
		if (data === null) return true;
		var max = data.length;
		return max === 1 && data === "~" || max === 4 && (data === "null" || data === "Null" || data === "NULL");
	}
	function constructYamlNull() {
		return null;
	}
	function isNull(object) {
		return object === null;
	}
	module.exports = new Type("tag:yaml.org,2002:null", {
		kind: "scalar",
		resolve: resolveYamlNull,
		construct: constructYamlNull,
		predicate: isNull,
		represent: {
			canonical: function() {
				return "~";
			},
			lowercase: function() {
				return "null";
			},
			uppercase: function() {
				return "NULL";
			},
			camelcase: function() {
				return "Null";
			}
		},
		defaultStyle: "lowercase"
	});
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/type/bool.js
var require_bool = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var Type = require_type();
	function resolveYamlBoolean(data) {
		if (data === null) return false;
		var max = data.length;
		return max === 4 && (data === "true" || data === "True" || data === "TRUE") || max === 5 && (data === "false" || data === "False" || data === "FALSE");
	}
	function constructYamlBoolean(data) {
		return data === "true" || data === "True" || data === "TRUE";
	}
	function isBoolean(object) {
		return Object.prototype.toString.call(object) === "[object Boolean]";
	}
	module.exports = new Type("tag:yaml.org,2002:bool", {
		kind: "scalar",
		resolve: resolveYamlBoolean,
		construct: constructYamlBoolean,
		predicate: isBoolean,
		represent: {
			lowercase: function(object) {
				return object ? "true" : "false";
			},
			uppercase: function(object) {
				return object ? "TRUE" : "FALSE";
			},
			camelcase: function(object) {
				return object ? "True" : "False";
			}
		},
		defaultStyle: "lowercase"
	});
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/type/int.js
var require_int = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var common = require_common();
	var Type = require_type();
	function isHexCode(c) {
		return 48 <= c && c <= 57 || 65 <= c && c <= 70 || 97 <= c && c <= 102;
	}
	function isOctCode(c) {
		return 48 <= c && c <= 55;
	}
	function isDecCode(c) {
		return 48 <= c && c <= 57;
	}
	function resolveYamlInteger(data) {
		if (data === null) return false;
		var max = data.length, index = 0, hasDigits = false, ch;
		if (!max) return false;
		ch = data[index];
		if (ch === "-" || ch === "+") ch = data[++index];
		if (ch === "0") {
			if (index + 1 === max) return true;
			ch = data[++index];
			if (ch === "b") {
				index++;
				for (; index < max; index++) {
					ch = data[index];
					if (ch === "_") continue;
					if (ch !== "0" && ch !== "1") return false;
					hasDigits = true;
				}
				return hasDigits && ch !== "_";
			}
			if (ch === "x") {
				index++;
				for (; index < max; index++) {
					ch = data[index];
					if (ch === "_") continue;
					if (!isHexCode(data.charCodeAt(index))) return false;
					hasDigits = true;
				}
				return hasDigits && ch !== "_";
			}
			for (; index < max; index++) {
				ch = data[index];
				if (ch === "_") continue;
				if (!isOctCode(data.charCodeAt(index))) return false;
				hasDigits = true;
			}
			return hasDigits && ch !== "_";
		}
		if (ch === "_") return false;
		for (; index < max; index++) {
			ch = data[index];
			if (ch === "_") continue;
			if (ch === ":") break;
			if (!isDecCode(data.charCodeAt(index))) return false;
			hasDigits = true;
		}
		if (!hasDigits || ch === "_") return false;
		if (ch !== ":") return true;
		return /^(:[0-5]?[0-9])+$/.test(data.slice(index));
	}
	function constructYamlInteger(data) {
		var value = data, sign = 1, ch, base, digits = [];
		if (value.indexOf("_") !== -1) value = value.replace(/_/g, "");
		ch = value[0];
		if (ch === "-" || ch === "+") {
			if (ch === "-") sign = -1;
			value = value.slice(1);
			ch = value[0];
		}
		if (value === "0") return 0;
		if (ch === "0") {
			if (value[1] === "b") return sign * parseInt(value.slice(2), 2);
			if (value[1] === "x") return sign * parseInt(value, 16);
			return sign * parseInt(value, 8);
		}
		if (value.indexOf(":") !== -1) {
			value.split(":").forEach(function(v) {
				digits.unshift(parseInt(v, 10));
			});
			value = 0;
			base = 1;
			digits.forEach(function(d) {
				value += d * base;
				base *= 60;
			});
			return sign * value;
		}
		return sign * parseInt(value, 10);
	}
	function isInteger(object) {
		return Object.prototype.toString.call(object) === "[object Number]" && object % 1 === 0 && !common.isNegativeZero(object);
	}
	module.exports = new Type("tag:yaml.org,2002:int", {
		kind: "scalar",
		resolve: resolveYamlInteger,
		construct: constructYamlInteger,
		predicate: isInteger,
		represent: {
			binary: function(obj) {
				return obj >= 0 ? "0b" + obj.toString(2) : "-0b" + obj.toString(2).slice(1);
			},
			octal: function(obj) {
				return obj >= 0 ? "0" + obj.toString(8) : "-0" + obj.toString(8).slice(1);
			},
			decimal: function(obj) {
				return obj.toString(10);
			},
			hexadecimal: function(obj) {
				return obj >= 0 ? "0x" + obj.toString(16).toUpperCase() : "-0x" + obj.toString(16).toUpperCase().slice(1);
			}
		},
		defaultStyle: "decimal",
		styleAliases: {
			binary: [2, "bin"],
			octal: [8, "oct"],
			decimal: [10, "dec"],
			hexadecimal: [16, "hex"]
		}
	});
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/type/float.js
var require_float = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var common = require_common();
	var Type = require_type();
	var YAML_FLOAT_PATTERN = /* @__PURE__ */ new RegExp("^(?:[-+]?(?:0|[1-9][0-9_]*)(?:\\.[0-9_]*)?(?:[eE][-+]?[0-9]+)?|\\.[0-9_]+(?:[eE][-+]?[0-9]+)?|[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+\\.[0-9_]*|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$");
	function resolveYamlFloat(data) {
		if (data === null) return false;
		if (!YAML_FLOAT_PATTERN.test(data) || data[data.length - 1] === "_") return false;
		return true;
	}
	function constructYamlFloat(data) {
		var value = data.replace(/_/g, "").toLowerCase(), sign = value[0] === "-" ? -1 : 1, base, digits = [];
		if ("+-".indexOf(value[0]) >= 0) value = value.slice(1);
		if (value === ".inf") return sign === 1 ? Number.POSITIVE_INFINITY : Number.NEGATIVE_INFINITY;
		else if (value === ".nan") return NaN;
		else if (value.indexOf(":") >= 0) {
			value.split(":").forEach(function(v) {
				digits.unshift(parseFloat(v, 10));
			});
			value = 0;
			base = 1;
			digits.forEach(function(d) {
				value += d * base;
				base *= 60;
			});
			return sign * value;
		}
		return sign * parseFloat(value, 10);
	}
	var SCIENTIFIC_WITHOUT_DOT = /^[-+]?[0-9]+e/;
	function representYamlFloat(object, style) {
		var res;
		if (isNaN(object)) switch (style) {
			case "lowercase": return ".nan";
			case "uppercase": return ".NAN";
			case "camelcase": return ".NaN";
		}
		else if (Number.POSITIVE_INFINITY === object) switch (style) {
			case "lowercase": return ".inf";
			case "uppercase": return ".INF";
			case "camelcase": return ".Inf";
		}
		else if (Number.NEGATIVE_INFINITY === object) switch (style) {
			case "lowercase": return "-.inf";
			case "uppercase": return "-.INF";
			case "camelcase": return "-.Inf";
		}
		else if (common.isNegativeZero(object)) return "-0.0";
		res = object.toString(10);
		return SCIENTIFIC_WITHOUT_DOT.test(res) ? res.replace("e", ".e") : res;
	}
	function isFloat(object) {
		return Object.prototype.toString.call(object) === "[object Number]" && (object % 1 !== 0 || common.isNegativeZero(object));
	}
	module.exports = new Type("tag:yaml.org,2002:float", {
		kind: "scalar",
		resolve: resolveYamlFloat,
		construct: constructYamlFloat,
		predicate: isFloat,
		represent: representYamlFloat,
		defaultStyle: "lowercase"
	});
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/schema/json.js
var require_json = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	module.exports = new (require_schema())({
		include: [require_failsafe()],
		implicit: [
			require_null(),
			require_bool(),
			require_int(),
			require_float()
		]
	});
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/schema/core.js
var require_core = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	module.exports = new (require_schema())({ include: [require_json()] });
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/type/timestamp.js
var require_timestamp = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var Type = require_type();
	var YAML_DATE_REGEXP = /* @__PURE__ */ new RegExp("^([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])$");
	var YAML_TIMESTAMP_REGEXP = /* @__PURE__ */ new RegExp("^([0-9][0-9][0-9][0-9])-([0-9][0-9]?)-([0-9][0-9]?)(?:[Tt]|[ \\t]+)([0-9][0-9]?):([0-9][0-9]):([0-9][0-9])(?:\\.([0-9]*))?(?:[ \\t]*(Z|([-+])([0-9][0-9]?)(?::([0-9][0-9]))?))?$");
	function resolveYamlTimestamp(data) {
		if (data === null) return false;
		if (YAML_DATE_REGEXP.exec(data) !== null) return true;
		if (YAML_TIMESTAMP_REGEXP.exec(data) !== null) return true;
		return false;
	}
	function constructYamlTimestamp(data) {
		var match, year, month, day, hour, minute, second, fraction = 0, delta = null, tz_hour, tz_minute, date;
		match = YAML_DATE_REGEXP.exec(data);
		if (match === null) match = YAML_TIMESTAMP_REGEXP.exec(data);
		if (match === null) throw new Error("Date resolve error");
		year = +match[1];
		month = +match[2] - 1;
		day = +match[3];
		if (!match[4]) return new Date(Date.UTC(year, month, day));
		hour = +match[4];
		minute = +match[5];
		second = +match[6];
		if (match[7]) {
			fraction = match[7].slice(0, 3);
			while (fraction.length < 3) fraction += "0";
			fraction = +fraction;
		}
		if (match[9]) {
			tz_hour = +match[10];
			tz_minute = +(match[11] || 0);
			delta = (tz_hour * 60 + tz_minute) * 6e4;
			if (match[9] === "-") delta = -delta;
		}
		date = new Date(Date.UTC(year, month, day, hour, minute, second, fraction));
		if (delta) date.setTime(date.getTime() - delta);
		return date;
	}
	function representYamlTimestamp(object) {
		return object.toISOString();
	}
	module.exports = new Type("tag:yaml.org,2002:timestamp", {
		kind: "scalar",
		resolve: resolveYamlTimestamp,
		construct: constructYamlTimestamp,
		instanceOf: Date,
		represent: representYamlTimestamp
	});
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/type/merge.js
var require_merge = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var Type = require_type();
	function resolveYamlMerge(data) {
		return data === "<<" || data === null;
	}
	module.exports = new Type("tag:yaml.org,2002:merge", {
		kind: "scalar",
		resolve: resolveYamlMerge
	});
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/type/binary.js
var require_binary = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var NodeBuffer;
	try {
		NodeBuffer = require("buffer").Buffer;
	} catch (__) {}
	var Type = require_type();
	var BASE64_MAP = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=\n\r";
	function resolveYamlBinary(data) {
		if (data === null) return false;
		var code, idx, bitlen = 0, max = data.length, map = BASE64_MAP;
		for (idx = 0; idx < max; idx++) {
			code = map.indexOf(data.charAt(idx));
			if (code > 64) continue;
			if (code < 0) return false;
			bitlen += 6;
		}
		return bitlen % 8 === 0;
	}
	function constructYamlBinary(data) {
		var idx, tailbits, input = data.replace(/[\r\n=]/g, ""), max = input.length, map = BASE64_MAP, bits = 0, result = [];
		for (idx = 0; idx < max; idx++) {
			if (idx % 4 === 0 && idx) {
				result.push(bits >> 16 & 255);
				result.push(bits >> 8 & 255);
				result.push(bits & 255);
			}
			bits = bits << 6 | map.indexOf(input.charAt(idx));
		}
		tailbits = max % 4 * 6;
		if (tailbits === 0) {
			result.push(bits >> 16 & 255);
			result.push(bits >> 8 & 255);
			result.push(bits & 255);
		} else if (tailbits === 18) {
			result.push(bits >> 10 & 255);
			result.push(bits >> 2 & 255);
		} else if (tailbits === 12) result.push(bits >> 4 & 255);
		if (NodeBuffer) return NodeBuffer.from ? NodeBuffer.from(result) : new NodeBuffer(result);
		return result;
	}
	function representYamlBinary(object) {
		var result = "", bits = 0, idx, tail, max = object.length, map = BASE64_MAP;
		for (idx = 0; idx < max; idx++) {
			if (idx % 3 === 0 && idx) {
				result += map[bits >> 18 & 63];
				result += map[bits >> 12 & 63];
				result += map[bits >> 6 & 63];
				result += map[bits & 63];
			}
			bits = (bits << 8) + object[idx];
		}
		tail = max % 3;
		if (tail === 0) {
			result += map[bits >> 18 & 63];
			result += map[bits >> 12 & 63];
			result += map[bits >> 6 & 63];
			result += map[bits & 63];
		} else if (tail === 2) {
			result += map[bits >> 10 & 63];
			result += map[bits >> 4 & 63];
			result += map[bits << 2 & 63];
			result += map[64];
		} else if (tail === 1) {
			result += map[bits >> 2 & 63];
			result += map[bits << 4 & 63];
			result += map[64];
			result += map[64];
		}
		return result;
	}
	function isBinary(object) {
		return NodeBuffer && NodeBuffer.isBuffer(object);
	}
	module.exports = new Type("tag:yaml.org,2002:binary", {
		kind: "scalar",
		resolve: resolveYamlBinary,
		construct: constructYamlBinary,
		predicate: isBinary,
		represent: representYamlBinary
	});
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/type/omap.js
var require_omap = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var Type = require_type();
	var _hasOwnProperty = Object.prototype.hasOwnProperty;
	var _toString = Object.prototype.toString;
	function resolveYamlOmap(data) {
		if (data === null) return true;
		var objectKeys = [], index, length, pair, pairKey, pairHasKey, object = data;
		for (index = 0, length = object.length; index < length; index += 1) {
			pair = object[index];
			pairHasKey = false;
			if (_toString.call(pair) !== "[object Object]") return false;
			for (pairKey in pair) if (_hasOwnProperty.call(pair, pairKey)) if (!pairHasKey) pairHasKey = true;
			else return false;
			if (!pairHasKey) return false;
			if (objectKeys.indexOf(pairKey) === -1) objectKeys.push(pairKey);
			else return false;
		}
		return true;
	}
	function constructYamlOmap(data) {
		return data !== null ? data : [];
	}
	module.exports = new Type("tag:yaml.org,2002:omap", {
		kind: "sequence",
		resolve: resolveYamlOmap,
		construct: constructYamlOmap
	});
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/type/pairs.js
var require_pairs = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var Type = require_type();
	var _toString = Object.prototype.toString;
	function resolveYamlPairs(data) {
		if (data === null) return true;
		var index, length, pair, keys, result, object = data;
		result = new Array(object.length);
		for (index = 0, length = object.length; index < length; index += 1) {
			pair = object[index];
			if (_toString.call(pair) !== "[object Object]") return false;
			keys = Object.keys(pair);
			if (keys.length !== 1) return false;
			result[index] = [keys[0], pair[keys[0]]];
		}
		return true;
	}
	function constructYamlPairs(data) {
		if (data === null) return [];
		var index, length, pair, keys, result, object = data;
		result = new Array(object.length);
		for (index = 0, length = object.length; index < length; index += 1) {
			pair = object[index];
			keys = Object.keys(pair);
			result[index] = [keys[0], pair[keys[0]]];
		}
		return result;
	}
	module.exports = new Type("tag:yaml.org,2002:pairs", {
		kind: "sequence",
		resolve: resolveYamlPairs,
		construct: constructYamlPairs
	});
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/type/set.js
var require_set = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var Type = require_type();
	var _hasOwnProperty = Object.prototype.hasOwnProperty;
	function resolveYamlSet(data) {
		if (data === null) return true;
		var key, object = data;
		for (key in object) if (_hasOwnProperty.call(object, key)) {
			if (object[key] !== null) return false;
		}
		return true;
	}
	function constructYamlSet(data) {
		return data !== null ? data : {};
	}
	module.exports = new Type("tag:yaml.org,2002:set", {
		kind: "mapping",
		resolve: resolveYamlSet,
		construct: constructYamlSet
	});
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/schema/default_safe.js
var require_default_safe = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	module.exports = new (require_schema())({
		include: [require_core()],
		implicit: [require_timestamp(), require_merge()],
		explicit: [
			require_binary(),
			require_omap(),
			require_pairs(),
			require_set()
		]
	});
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/type/js/undefined.js
var require_undefined = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var Type = require_type();
	function resolveJavascriptUndefined() {
		return true;
	}
	function constructJavascriptUndefined() {}
	function representJavascriptUndefined() {
		return "";
	}
	function isUndefined(object) {
		return typeof object === "undefined";
	}
	module.exports = new Type("tag:yaml.org,2002:js/undefined", {
		kind: "scalar",
		resolve: resolveJavascriptUndefined,
		construct: constructJavascriptUndefined,
		predicate: isUndefined,
		represent: representJavascriptUndefined
	});
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/type/js/regexp.js
var require_regexp = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var Type = require_type();
	function resolveJavascriptRegExp(data) {
		if (data === null) return false;
		if (data.length === 0) return false;
		var regexp = data, tail = /\/([gim]*)$/.exec(data), modifiers = "";
		if (regexp[0] === "/") {
			if (tail) modifiers = tail[1];
			if (modifiers.length > 3) return false;
			if (regexp[regexp.length - modifiers.length - 1] !== "/") return false;
		}
		return true;
	}
	function constructJavascriptRegExp(data) {
		var regexp = data, tail = /\/([gim]*)$/.exec(data), modifiers = "";
		if (regexp[0] === "/") {
			if (tail) modifiers = tail[1];
			regexp = regexp.slice(1, regexp.length - modifiers.length - 1);
		}
		return new RegExp(regexp, modifiers);
	}
	function representJavascriptRegExp(object) {
		var result = "/" + object.source + "/";
		if (object.global) result += "g";
		if (object.multiline) result += "m";
		if (object.ignoreCase) result += "i";
		return result;
	}
	function isRegExp(object) {
		return Object.prototype.toString.call(object) === "[object RegExp]";
	}
	module.exports = new Type("tag:yaml.org,2002:js/regexp", {
		kind: "scalar",
		resolve: resolveJavascriptRegExp,
		construct: constructJavascriptRegExp,
		predicate: isRegExp,
		represent: representJavascriptRegExp
	});
}));
//#endregion
//#region node_modules/esprima/dist/esprima.js
var require_esprima = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	(function webpackUniversalModuleDefinition(root, factory) {
		/* istanbul ignore next */
		if (typeof exports === "object" && typeof module === "object") module.exports = factory();
		else if (typeof define === "function" && define.amd) define([], factory);
		else if (typeof exports === "object") exports["esprima"] = factory();
		else root["esprima"] = factory();
	})(exports, function() {
		return (function(modules) {
			var installedModules = {};
			function __webpack_require__(moduleId) {
				/* istanbul ignore if */
				if (installedModules[moduleId]) return installedModules[moduleId].exports;
				var module$1 = installedModules[moduleId] = {
					exports: {},
					id: moduleId,
					loaded: false
				};
				modules[moduleId].call(module$1.exports, module$1, module$1.exports, __webpack_require__);
				module$1.loaded = true;
				return module$1.exports;
			}
			__webpack_require__.m = modules;
			__webpack_require__.c = installedModules;
			__webpack_require__.p = "";
			return __webpack_require__(0);
		})([
			function(module$2, exports$1, __webpack_require__) {
				"use strict";
				Object.defineProperty(exports$1, "__esModule", { value: true });
				var comment_handler_1 = __webpack_require__(1);
				var jsx_parser_1 = __webpack_require__(3);
				var parser_1 = __webpack_require__(8);
				var tokenizer_1 = __webpack_require__(15);
				function parse(code, options, delegate) {
					var commentHandler = null;
					var proxyDelegate = function(node, metadata) {
						if (delegate) delegate(node, metadata);
						if (commentHandler) commentHandler.visit(node, metadata);
					};
					var parserDelegate = typeof delegate === "function" ? proxyDelegate : null;
					var collectComment = false;
					if (options) {
						collectComment = typeof options.comment === "boolean" && options.comment;
						var attachComment = typeof options.attachComment === "boolean" && options.attachComment;
						if (collectComment || attachComment) {
							commentHandler = new comment_handler_1.CommentHandler();
							commentHandler.attach = attachComment;
							options.comment = true;
							parserDelegate = proxyDelegate;
						}
					}
					var isModule = false;
					if (options && typeof options.sourceType === "string") isModule = options.sourceType === "module";
					var parser;
					if (options && typeof options.jsx === "boolean" && options.jsx) parser = new jsx_parser_1.JSXParser(code, options, parserDelegate);
					else parser = new parser_1.Parser(code, options, parserDelegate);
					var ast = isModule ? parser.parseModule() : parser.parseScript();
					if (collectComment && commentHandler) ast.comments = commentHandler.comments;
					if (parser.config.tokens) ast.tokens = parser.tokens;
					if (parser.config.tolerant) ast.errors = parser.errorHandler.errors;
					return ast;
				}
				exports$1.parse = parse;
				function parseModule(code, options, delegate) {
					var parsingOptions = options || {};
					parsingOptions.sourceType = "module";
					return parse(code, parsingOptions, delegate);
				}
				exports$1.parseModule = parseModule;
				function parseScript(code, options, delegate) {
					var parsingOptions = options || {};
					parsingOptions.sourceType = "script";
					return parse(code, parsingOptions, delegate);
				}
				exports$1.parseScript = parseScript;
				function tokenize(code, options, delegate) {
					var tokenizer = new tokenizer_1.Tokenizer(code, options);
					var tokens = [];
					try {
						while (true) {
							var token = tokenizer.getNextToken();
							if (!token) break;
							if (delegate) token = delegate(token);
							tokens.push(token);
						}
					} catch (e) {
						tokenizer.errorHandler.tolerate(e);
					}
					if (tokenizer.errorHandler.tolerant) tokens.errors = tokenizer.errors();
					return tokens;
				}
				exports$1.tokenize = tokenize;
				exports$1.Syntax = __webpack_require__(2).Syntax;
				exports$1.version = "4.0.1";
			},
			function(module$3, exports$2, __webpack_require__) {
				"use strict";
				Object.defineProperty(exports$2, "__esModule", { value: true });
				var syntax_1 = __webpack_require__(2);
				exports$2.CommentHandler = function() {
					function CommentHandler() {
						this.attach = false;
						this.comments = [];
						this.stack = [];
						this.leading = [];
						this.trailing = [];
					}
					CommentHandler.prototype.insertInnerComments = function(node, metadata) {
						if (node.type === syntax_1.Syntax.BlockStatement && node.body.length === 0) {
							var innerComments = [];
							for (var i = this.leading.length - 1; i >= 0; --i) {
								var entry = this.leading[i];
								if (metadata.end.offset >= entry.start) {
									innerComments.unshift(entry.comment);
									this.leading.splice(i, 1);
									this.trailing.splice(i, 1);
								}
							}
							if (innerComments.length) node.innerComments = innerComments;
						}
					};
					CommentHandler.prototype.findTrailingComments = function(metadata) {
						var trailingComments = [];
						if (this.trailing.length > 0) {
							for (var i = this.trailing.length - 1; i >= 0; --i) {
								var entry_1 = this.trailing[i];
								if (entry_1.start >= metadata.end.offset) trailingComments.unshift(entry_1.comment);
							}
							this.trailing.length = 0;
							return trailingComments;
						}
						var entry = this.stack[this.stack.length - 1];
						if (entry && entry.node.trailingComments) {
							var firstComment = entry.node.trailingComments[0];
							if (firstComment && firstComment.range[0] >= metadata.end.offset) {
								trailingComments = entry.node.trailingComments;
								delete entry.node.trailingComments;
							}
						}
						return trailingComments;
					};
					CommentHandler.prototype.findLeadingComments = function(metadata) {
						var leadingComments = [];
						var target;
						while (this.stack.length > 0) {
							var entry = this.stack[this.stack.length - 1];
							if (entry && entry.start >= metadata.start.offset) {
								target = entry.node;
								this.stack.pop();
							} else break;
						}
						if (target) {
							for (var i = (target.leadingComments ? target.leadingComments.length : 0) - 1; i >= 0; --i) {
								var comment = target.leadingComments[i];
								if (comment.range[1] <= metadata.start.offset) {
									leadingComments.unshift(comment);
									target.leadingComments.splice(i, 1);
								}
							}
							if (target.leadingComments && target.leadingComments.length === 0) delete target.leadingComments;
							return leadingComments;
						}
						for (var i = this.leading.length - 1; i >= 0; --i) {
							var entry = this.leading[i];
							if (entry.start <= metadata.start.offset) {
								leadingComments.unshift(entry.comment);
								this.leading.splice(i, 1);
							}
						}
						return leadingComments;
					};
					CommentHandler.prototype.visitNode = function(node, metadata) {
						if (node.type === syntax_1.Syntax.Program && node.body.length > 0) return;
						this.insertInnerComments(node, metadata);
						var trailingComments = this.findTrailingComments(metadata);
						var leadingComments = this.findLeadingComments(metadata);
						if (leadingComments.length > 0) node.leadingComments = leadingComments;
						if (trailingComments.length > 0) node.trailingComments = trailingComments;
						this.stack.push({
							node,
							start: metadata.start.offset
						});
					};
					CommentHandler.prototype.visitComment = function(node, metadata) {
						var type = node.type[0] === "L" ? "Line" : "Block";
						var comment = {
							type,
							value: node.value
						};
						if (node.range) comment.range = node.range;
						if (node.loc) comment.loc = node.loc;
						this.comments.push(comment);
						if (this.attach) {
							var entry = {
								comment: {
									type,
									value: node.value,
									range: [metadata.start.offset, metadata.end.offset]
								},
								start: metadata.start.offset
							};
							if (node.loc) entry.comment.loc = node.loc;
							node.type = type;
							this.leading.push(entry);
							this.trailing.push(entry);
						}
					};
					CommentHandler.prototype.visit = function(node, metadata) {
						if (node.type === "LineComment") this.visitComment(node, metadata);
						else if (node.type === "BlockComment") this.visitComment(node, metadata);
						else if (this.attach) this.visitNode(node, metadata);
					};
					return CommentHandler;
				}();
			},
			function(module$4, exports$3) {
				"use strict";
				Object.defineProperty(exports$3, "__esModule", { value: true });
				exports$3.Syntax = {
					AssignmentExpression: "AssignmentExpression",
					AssignmentPattern: "AssignmentPattern",
					ArrayExpression: "ArrayExpression",
					ArrayPattern: "ArrayPattern",
					ArrowFunctionExpression: "ArrowFunctionExpression",
					AwaitExpression: "AwaitExpression",
					BlockStatement: "BlockStatement",
					BinaryExpression: "BinaryExpression",
					BreakStatement: "BreakStatement",
					CallExpression: "CallExpression",
					CatchClause: "CatchClause",
					ClassBody: "ClassBody",
					ClassDeclaration: "ClassDeclaration",
					ClassExpression: "ClassExpression",
					ConditionalExpression: "ConditionalExpression",
					ContinueStatement: "ContinueStatement",
					DoWhileStatement: "DoWhileStatement",
					DebuggerStatement: "DebuggerStatement",
					EmptyStatement: "EmptyStatement",
					ExportAllDeclaration: "ExportAllDeclaration",
					ExportDefaultDeclaration: "ExportDefaultDeclaration",
					ExportNamedDeclaration: "ExportNamedDeclaration",
					ExportSpecifier: "ExportSpecifier",
					ExpressionStatement: "ExpressionStatement",
					ForStatement: "ForStatement",
					ForOfStatement: "ForOfStatement",
					ForInStatement: "ForInStatement",
					FunctionDeclaration: "FunctionDeclaration",
					FunctionExpression: "FunctionExpression",
					Identifier: "Identifier",
					IfStatement: "IfStatement",
					ImportDeclaration: "ImportDeclaration",
					ImportDefaultSpecifier: "ImportDefaultSpecifier",
					ImportNamespaceSpecifier: "ImportNamespaceSpecifier",
					ImportSpecifier: "ImportSpecifier",
					Literal: "Literal",
					LabeledStatement: "LabeledStatement",
					LogicalExpression: "LogicalExpression",
					MemberExpression: "MemberExpression",
					MetaProperty: "MetaProperty",
					MethodDefinition: "MethodDefinition",
					NewExpression: "NewExpression",
					ObjectExpression: "ObjectExpression",
					ObjectPattern: "ObjectPattern",
					Program: "Program",
					Property: "Property",
					RestElement: "RestElement",
					ReturnStatement: "ReturnStatement",
					SequenceExpression: "SequenceExpression",
					SpreadElement: "SpreadElement",
					Super: "Super",
					SwitchCase: "SwitchCase",
					SwitchStatement: "SwitchStatement",
					TaggedTemplateExpression: "TaggedTemplateExpression",
					TemplateElement: "TemplateElement",
					TemplateLiteral: "TemplateLiteral",
					ThisExpression: "ThisExpression",
					ThrowStatement: "ThrowStatement",
					TryStatement: "TryStatement",
					UnaryExpression: "UnaryExpression",
					UpdateExpression: "UpdateExpression",
					VariableDeclaration: "VariableDeclaration",
					VariableDeclarator: "VariableDeclarator",
					WhileStatement: "WhileStatement",
					WithStatement: "WithStatement",
					YieldExpression: "YieldExpression"
				};
			},
			function(module$5, exports$4, __webpack_require__) {
				"use strict";
				/* istanbul ignore next */
				var __extends = this && this.__extends || (function() {
					var extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
						d.__proto__ = b;
					} || function(d, b) {
						for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
					};
					return function(d, b) {
						extendStatics(d, b);
						function __() {
							this.constructor = d;
						}
						d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
					};
				})();
				Object.defineProperty(exports$4, "__esModule", { value: true });
				var character_1 = __webpack_require__(4);
				var JSXNode = __webpack_require__(5);
				var jsx_syntax_1 = __webpack_require__(6);
				var Node = __webpack_require__(7);
				var parser_1 = __webpack_require__(8);
				var token_1 = __webpack_require__(13);
				var xhtml_entities_1 = __webpack_require__(14);
				token_1.TokenName[100] = "JSXIdentifier";
				token_1.TokenName[101] = "JSXText";
				function getQualifiedElementName(elementName) {
					var qualifiedName;
					switch (elementName.type) {
						case jsx_syntax_1.JSXSyntax.JSXIdentifier:
							qualifiedName = elementName.name;
							break;
						case jsx_syntax_1.JSXSyntax.JSXNamespacedName:
							var ns = elementName;
							qualifiedName = getQualifiedElementName(ns.namespace) + ":" + getQualifiedElementName(ns.name);
							break;
						case jsx_syntax_1.JSXSyntax.JSXMemberExpression:
							var expr = elementName;
							qualifiedName = getQualifiedElementName(expr.object) + "." + getQualifiedElementName(expr.property);
							break;
						/* istanbul ignore next */
						default: break;
					}
					return qualifiedName;
				}
				exports$4.JSXParser = function(_super) {
					__extends(JSXParser, _super);
					function JSXParser(code, options, delegate) {
						return _super.call(this, code, options, delegate) || this;
					}
					JSXParser.prototype.parsePrimaryExpression = function() {
						return this.match("<") ? this.parseJSXRoot() : _super.prototype.parsePrimaryExpression.call(this);
					};
					JSXParser.prototype.startJSX = function() {
						this.scanner.index = this.startMarker.index;
						this.scanner.lineNumber = this.startMarker.line;
						this.scanner.lineStart = this.startMarker.index - this.startMarker.column;
					};
					JSXParser.prototype.finishJSX = function() {
						this.nextToken();
					};
					JSXParser.prototype.reenterJSX = function() {
						this.startJSX();
						this.expectJSX("}");
						if (this.config.tokens) this.tokens.pop();
					};
					JSXParser.prototype.createJSXNode = function() {
						this.collectComments();
						return {
							index: this.scanner.index,
							line: this.scanner.lineNumber,
							column: this.scanner.index - this.scanner.lineStart
						};
					};
					JSXParser.prototype.createJSXChildNode = function() {
						return {
							index: this.scanner.index,
							line: this.scanner.lineNumber,
							column: this.scanner.index - this.scanner.lineStart
						};
					};
					JSXParser.prototype.scanXHTMLEntity = function(quote) {
						var result = "&";
						var valid = true;
						var terminated = false;
						var numeric = false;
						var hex = false;
						while (!this.scanner.eof() && valid && !terminated) {
							var ch = this.scanner.source[this.scanner.index];
							if (ch === quote) break;
							terminated = ch === ";";
							result += ch;
							++this.scanner.index;
							if (!terminated) switch (result.length) {
								case 2:
									numeric = ch === "#";
									break;
								case 3:
									if (numeric) {
										hex = ch === "x";
										valid = hex || character_1.Character.isDecimalDigit(ch.charCodeAt(0));
										numeric = numeric && !hex;
									}
									break;
								default:
									valid = valid && !(numeric && !character_1.Character.isDecimalDigit(ch.charCodeAt(0)));
									valid = valid && !(hex && !character_1.Character.isHexDigit(ch.charCodeAt(0)));
									break;
							}
						}
						if (valid && terminated && result.length > 2) {
							var str = result.substr(1, result.length - 2);
							if (numeric && str.length > 1) result = String.fromCharCode(parseInt(str.substr(1), 10));
							else if (hex && str.length > 2) result = String.fromCharCode(parseInt("0" + str.substr(1), 16));
							else if (!numeric && !hex && xhtml_entities_1.XHTMLEntities[str]) result = xhtml_entities_1.XHTMLEntities[str];
						}
						return result;
					};
					JSXParser.prototype.lexJSX = function() {
						var cp = this.scanner.source.charCodeAt(this.scanner.index);
						if (cp === 60 || cp === 62 || cp === 47 || cp === 58 || cp === 61 || cp === 123 || cp === 125) {
							var value = this.scanner.source[this.scanner.index++];
							return {
								type: 7,
								value,
								lineNumber: this.scanner.lineNumber,
								lineStart: this.scanner.lineStart,
								start: this.scanner.index - 1,
								end: this.scanner.index
							};
						}
						if (cp === 34 || cp === 39) {
							var start = this.scanner.index;
							var quote = this.scanner.source[this.scanner.index++];
							var str = "";
							while (!this.scanner.eof()) {
								var ch = this.scanner.source[this.scanner.index++];
								if (ch === quote) break;
								else if (ch === "&") str += this.scanXHTMLEntity(quote);
								else str += ch;
							}
							return {
								type: 8,
								value: str,
								lineNumber: this.scanner.lineNumber,
								lineStart: this.scanner.lineStart,
								start,
								end: this.scanner.index
							};
						}
						if (cp === 46) {
							var n1 = this.scanner.source.charCodeAt(this.scanner.index + 1);
							var n2 = this.scanner.source.charCodeAt(this.scanner.index + 2);
							var value = n1 === 46 && n2 === 46 ? "..." : ".";
							var start = this.scanner.index;
							this.scanner.index += value.length;
							return {
								type: 7,
								value,
								lineNumber: this.scanner.lineNumber,
								lineStart: this.scanner.lineStart,
								start,
								end: this.scanner.index
							};
						}
						if (cp === 96) return {
							type: 10,
							value: "",
							lineNumber: this.scanner.lineNumber,
							lineStart: this.scanner.lineStart,
							start: this.scanner.index,
							end: this.scanner.index
						};
						if (character_1.Character.isIdentifierStart(cp) && cp !== 92) {
							var start = this.scanner.index;
							++this.scanner.index;
							while (!this.scanner.eof()) {
								var ch = this.scanner.source.charCodeAt(this.scanner.index);
								if (character_1.Character.isIdentifierPart(ch) && ch !== 92) ++this.scanner.index;
								else if (ch === 45) ++this.scanner.index;
								else break;
							}
							return {
								type: 100,
								value: this.scanner.source.slice(start, this.scanner.index),
								lineNumber: this.scanner.lineNumber,
								lineStart: this.scanner.lineStart,
								start,
								end: this.scanner.index
							};
						}
						return this.scanner.lex();
					};
					JSXParser.prototype.nextJSXToken = function() {
						this.collectComments();
						this.startMarker.index = this.scanner.index;
						this.startMarker.line = this.scanner.lineNumber;
						this.startMarker.column = this.scanner.index - this.scanner.lineStart;
						var token = this.lexJSX();
						this.lastMarker.index = this.scanner.index;
						this.lastMarker.line = this.scanner.lineNumber;
						this.lastMarker.column = this.scanner.index - this.scanner.lineStart;
						if (this.config.tokens) this.tokens.push(this.convertToken(token));
						return token;
					};
					JSXParser.prototype.nextJSXText = function() {
						this.startMarker.index = this.scanner.index;
						this.startMarker.line = this.scanner.lineNumber;
						this.startMarker.column = this.scanner.index - this.scanner.lineStart;
						var start = this.scanner.index;
						var text = "";
						while (!this.scanner.eof()) {
							var ch = this.scanner.source[this.scanner.index];
							if (ch === "{" || ch === "<") break;
							++this.scanner.index;
							text += ch;
							if (character_1.Character.isLineTerminator(ch.charCodeAt(0))) {
								++this.scanner.lineNumber;
								if (ch === "\r" && this.scanner.source[this.scanner.index] === "\n") ++this.scanner.index;
								this.scanner.lineStart = this.scanner.index;
							}
						}
						this.lastMarker.index = this.scanner.index;
						this.lastMarker.line = this.scanner.lineNumber;
						this.lastMarker.column = this.scanner.index - this.scanner.lineStart;
						var token = {
							type: 101,
							value: text,
							lineNumber: this.scanner.lineNumber,
							lineStart: this.scanner.lineStart,
							start,
							end: this.scanner.index
						};
						if (text.length > 0 && this.config.tokens) this.tokens.push(this.convertToken(token));
						return token;
					};
					JSXParser.prototype.peekJSXToken = function() {
						var state = this.scanner.saveState();
						this.scanner.scanComments();
						var next = this.lexJSX();
						this.scanner.restoreState(state);
						return next;
					};
					JSXParser.prototype.expectJSX = function(value) {
						var token = this.nextJSXToken();
						if (token.type !== 7 || token.value !== value) this.throwUnexpectedToken(token);
					};
					JSXParser.prototype.matchJSX = function(value) {
						var next = this.peekJSXToken();
						return next.type === 7 && next.value === value;
					};
					JSXParser.prototype.parseJSXIdentifier = function() {
						var node = this.createJSXNode();
						var token = this.nextJSXToken();
						if (token.type !== 100) this.throwUnexpectedToken(token);
						return this.finalize(node, new JSXNode.JSXIdentifier(token.value));
					};
					JSXParser.prototype.parseJSXElementName = function() {
						var node = this.createJSXNode();
						var elementName = this.parseJSXIdentifier();
						if (this.matchJSX(":")) {
							var namespace = elementName;
							this.expectJSX(":");
							var name_1 = this.parseJSXIdentifier();
							elementName = this.finalize(node, new JSXNode.JSXNamespacedName(namespace, name_1));
						} else if (this.matchJSX(".")) while (this.matchJSX(".")) {
							var object = elementName;
							this.expectJSX(".");
							var property = this.parseJSXIdentifier();
							elementName = this.finalize(node, new JSXNode.JSXMemberExpression(object, property));
						}
						return elementName;
					};
					JSXParser.prototype.parseJSXAttributeName = function() {
						var node = this.createJSXNode();
						var attributeName;
						var identifier = this.parseJSXIdentifier();
						if (this.matchJSX(":")) {
							var namespace = identifier;
							this.expectJSX(":");
							var name_2 = this.parseJSXIdentifier();
							attributeName = this.finalize(node, new JSXNode.JSXNamespacedName(namespace, name_2));
						} else attributeName = identifier;
						return attributeName;
					};
					JSXParser.prototype.parseJSXStringLiteralAttribute = function() {
						var node = this.createJSXNode();
						var token = this.nextJSXToken();
						if (token.type !== 8) this.throwUnexpectedToken(token);
						var raw = this.getTokenRaw(token);
						return this.finalize(node, new Node.Literal(token.value, raw));
					};
					JSXParser.prototype.parseJSXExpressionAttribute = function() {
						var node = this.createJSXNode();
						this.expectJSX("{");
						this.finishJSX();
						if (this.match("}")) this.tolerateError("JSX attributes must only be assigned a non-empty expression");
						var expression = this.parseAssignmentExpression();
						this.reenterJSX();
						return this.finalize(node, new JSXNode.JSXExpressionContainer(expression));
					};
					JSXParser.prototype.parseJSXAttributeValue = function() {
						return this.matchJSX("{") ? this.parseJSXExpressionAttribute() : this.matchJSX("<") ? this.parseJSXElement() : this.parseJSXStringLiteralAttribute();
					};
					JSXParser.prototype.parseJSXNameValueAttribute = function() {
						var node = this.createJSXNode();
						var name = this.parseJSXAttributeName();
						var value = null;
						if (this.matchJSX("=")) {
							this.expectJSX("=");
							value = this.parseJSXAttributeValue();
						}
						return this.finalize(node, new JSXNode.JSXAttribute(name, value));
					};
					JSXParser.prototype.parseJSXSpreadAttribute = function() {
						var node = this.createJSXNode();
						this.expectJSX("{");
						this.expectJSX("...");
						this.finishJSX();
						var argument = this.parseAssignmentExpression();
						this.reenterJSX();
						return this.finalize(node, new JSXNode.JSXSpreadAttribute(argument));
					};
					JSXParser.prototype.parseJSXAttributes = function() {
						var attributes = [];
						while (!this.matchJSX("/") && !this.matchJSX(">")) {
							var attribute = this.matchJSX("{") ? this.parseJSXSpreadAttribute() : this.parseJSXNameValueAttribute();
							attributes.push(attribute);
						}
						return attributes;
					};
					JSXParser.prototype.parseJSXOpeningElement = function() {
						var node = this.createJSXNode();
						this.expectJSX("<");
						var name = this.parseJSXElementName();
						var attributes = this.parseJSXAttributes();
						var selfClosing = this.matchJSX("/");
						if (selfClosing) this.expectJSX("/");
						this.expectJSX(">");
						return this.finalize(node, new JSXNode.JSXOpeningElement(name, selfClosing, attributes));
					};
					JSXParser.prototype.parseJSXBoundaryElement = function() {
						var node = this.createJSXNode();
						this.expectJSX("<");
						if (this.matchJSX("/")) {
							this.expectJSX("/");
							var name_3 = this.parseJSXElementName();
							this.expectJSX(">");
							return this.finalize(node, new JSXNode.JSXClosingElement(name_3));
						}
						var name = this.parseJSXElementName();
						var attributes = this.parseJSXAttributes();
						var selfClosing = this.matchJSX("/");
						if (selfClosing) this.expectJSX("/");
						this.expectJSX(">");
						return this.finalize(node, new JSXNode.JSXOpeningElement(name, selfClosing, attributes));
					};
					JSXParser.prototype.parseJSXEmptyExpression = function() {
						var node = this.createJSXChildNode();
						this.collectComments();
						this.lastMarker.index = this.scanner.index;
						this.lastMarker.line = this.scanner.lineNumber;
						this.lastMarker.column = this.scanner.index - this.scanner.lineStart;
						return this.finalize(node, new JSXNode.JSXEmptyExpression());
					};
					JSXParser.prototype.parseJSXExpressionContainer = function() {
						var node = this.createJSXNode();
						this.expectJSX("{");
						var expression;
						if (this.matchJSX("}")) {
							expression = this.parseJSXEmptyExpression();
							this.expectJSX("}");
						} else {
							this.finishJSX();
							expression = this.parseAssignmentExpression();
							this.reenterJSX();
						}
						return this.finalize(node, new JSXNode.JSXExpressionContainer(expression));
					};
					JSXParser.prototype.parseJSXChildren = function() {
						var children = [];
						while (!this.scanner.eof()) {
							var node = this.createJSXChildNode();
							var token = this.nextJSXText();
							if (token.start < token.end) {
								var raw = this.getTokenRaw(token);
								var child = this.finalize(node, new JSXNode.JSXText(token.value, raw));
								children.push(child);
							}
							if (this.scanner.source[this.scanner.index] === "{") {
								var container = this.parseJSXExpressionContainer();
								children.push(container);
							} else break;
						}
						return children;
					};
					JSXParser.prototype.parseComplexJSXElement = function(el) {
						var stack = [];
						while (!this.scanner.eof()) {
							el.children = el.children.concat(this.parseJSXChildren());
							var node = this.createJSXChildNode();
							var element = this.parseJSXBoundaryElement();
							if (element.type === jsx_syntax_1.JSXSyntax.JSXOpeningElement) {
								var opening = element;
								if (opening.selfClosing) {
									var child = this.finalize(node, new JSXNode.JSXElement(opening, [], null));
									el.children.push(child);
								} else {
									stack.push(el);
									el = {
										node,
										opening,
										closing: null,
										children: []
									};
								}
							}
							if (element.type === jsx_syntax_1.JSXSyntax.JSXClosingElement) {
								el.closing = element;
								var open_1 = getQualifiedElementName(el.opening.name);
								if (open_1 !== getQualifiedElementName(el.closing.name)) this.tolerateError("Expected corresponding JSX closing tag for %0", open_1);
								if (stack.length > 0) {
									var child = this.finalize(el.node, new JSXNode.JSXElement(el.opening, el.children, el.closing));
									el = stack[stack.length - 1];
									el.children.push(child);
									stack.pop();
								} else break;
							}
						}
						return el;
					};
					JSXParser.prototype.parseJSXElement = function() {
						var node = this.createJSXNode();
						var opening = this.parseJSXOpeningElement();
						var children = [];
						var closing = null;
						if (!opening.selfClosing) {
							var el = this.parseComplexJSXElement({
								node,
								opening,
								closing,
								children
							});
							children = el.children;
							closing = el.closing;
						}
						return this.finalize(node, new JSXNode.JSXElement(opening, children, closing));
					};
					JSXParser.prototype.parseJSXRoot = function() {
						if (this.config.tokens) this.tokens.pop();
						this.startJSX();
						var element = this.parseJSXElement();
						this.finishJSX();
						return element;
					};
					JSXParser.prototype.isStartOfExpression = function() {
						return _super.prototype.isStartOfExpression.call(this) || this.match("<");
					};
					return JSXParser;
				}(parser_1.Parser);
			},
			function(module$6, exports$5) {
				"use strict";
				Object.defineProperty(exports$5, "__esModule", { value: true });
				var Regex = {
					NonAsciiIdentifierStart: /[\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0559\u0561-\u0587\u05D0-\u05EA\u05F0-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u08A0-\u08B4\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C60\u0C61\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D05-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D5F-\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u170C\u170E-\u1711\u1720-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1877\u1880-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4B\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1CE9-\u1CEC\u1CEE-\u1CF1\u1CF5\u1CF6\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2118-\u211D\u2124\u2126\u2128\u212A-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303C\u3041-\u3096\u309B-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312D\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FD5\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6EF\uA717-\uA71F\uA722-\uA788\uA78B-\uA7AD\uA7B0-\uA7B7\uA7F7-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA8FD\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uA9E0-\uA9E4\uA9E6-\uA9EF\uA9FA-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB65\uAB70-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDD40-\uDD74\uDE80-\uDE9C\uDEA0-\uDED0\uDF00-\uDF1F\uDF30-\uDF4A\uDF50-\uDF75\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF\uDFD1-\uDFD5]|\uD801[\uDC00-\uDC9D\uDD00-\uDD27\uDD30-\uDD63\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC60-\uDC76\uDC80-\uDC9E\uDCE0-\uDCF2\uDCF4\uDCF5\uDD00-\uDD15\uDD20-\uDD39\uDD80-\uDDB7\uDDBE\uDDBF\uDE00\uDE10-\uDE13\uDE15-\uDE17\uDE19-\uDE33\uDE60-\uDE7C\uDE80-\uDE9C\uDEC0-\uDEC7\uDEC9-\uDEE4\uDF00-\uDF35\uDF40-\uDF55\uDF60-\uDF72\uDF80-\uDF91]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2]|\uD804[\uDC03-\uDC37\uDC83-\uDCAF\uDCD0-\uDCE8\uDD03-\uDD26\uDD50-\uDD72\uDD76\uDD83-\uDDB2\uDDC1-\uDDC4\uDDDA\uDDDC\uDE00-\uDE11\uDE13-\uDE2B\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEDE\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3D\uDF50\uDF5D-\uDF61]|\uD805[\uDC80-\uDCAF\uDCC4\uDCC5\uDCC7\uDD80-\uDDAE\uDDD8-\uDDDB\uDE00-\uDE2F\uDE44\uDE80-\uDEAA\uDF00-\uDF19]|\uD806[\uDCA0-\uDCDF\uDCFF\uDEC0-\uDEF8]|\uD808[\uDC00-\uDF99]|\uD809[\uDC00-\uDC6E\uDC80-\uDD43]|[\uD80C\uD840-\uD868\uD86A-\uD86C\uD86F-\uD872][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2E]|\uD811[\uDC00-\uDE46]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDED0-\uDEED\uDF00-\uDF2F\uDF40-\uDF43\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDF00-\uDF44\uDF50\uDF93-\uDF9F]|\uD82C[\uDC00\uDC01]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB]|\uD83A[\uDC00-\uDCC4]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD869[\uDC00-\uDED6\uDF00-\uDFFF]|\uD86D[\uDC00-\uDF34\uDF40-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEA1]|\uD87E[\uDC00-\uDE1D]/,
					NonAsciiIdentifierPart: /[\xAA\xB5\xB7\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0300-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u0483-\u0487\u048A-\u052F\u0531-\u0556\u0559\u0561-\u0587\u0591-\u05BD\u05BF\u05C1\u05C2\u05C4\u05C5\u05C7\u05D0-\u05EA\u05F0-\u05F2\u0610-\u061A\u0620-\u0669\u066E-\u06D3\u06D5-\u06DC\u06DF-\u06E8\u06EA-\u06FC\u06FF\u0710-\u074A\u074D-\u07B1\u07C0-\u07F5\u07FA\u0800-\u082D\u0840-\u085B\u08A0-\u08B4\u08E3-\u0963\u0966-\u096F\u0971-\u0983\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BC-\u09C4\u09C7\u09C8\u09CB-\u09CE\u09D7\u09DC\u09DD\u09DF-\u09E3\u09E6-\u09F1\u0A01-\u0A03\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A3C\u0A3E-\u0A42\u0A47\u0A48\u0A4B-\u0A4D\u0A51\u0A59-\u0A5C\u0A5E\u0A66-\u0A75\u0A81-\u0A83\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABC-\u0AC5\u0AC7-\u0AC9\u0ACB-\u0ACD\u0AD0\u0AE0-\u0AE3\u0AE6-\u0AEF\u0AF9\u0B01-\u0B03\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3C-\u0B44\u0B47\u0B48\u0B4B-\u0B4D\u0B56\u0B57\u0B5C\u0B5D\u0B5F-\u0B63\u0B66-\u0B6F\u0B71\u0B82\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BBE-\u0BC2\u0BC6-\u0BC8\u0BCA-\u0BCD\u0BD0\u0BD7\u0BE6-\u0BEF\u0C00-\u0C03\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D-\u0C44\u0C46-\u0C48\u0C4A-\u0C4D\u0C55\u0C56\u0C58-\u0C5A\u0C60-\u0C63\u0C66-\u0C6F\u0C81-\u0C83\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBC-\u0CC4\u0CC6-\u0CC8\u0CCA-\u0CCD\u0CD5\u0CD6\u0CDE\u0CE0-\u0CE3\u0CE6-\u0CEF\u0CF1\u0CF2\u0D01-\u0D03\u0D05-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D-\u0D44\u0D46-\u0D48\u0D4A-\u0D4E\u0D57\u0D5F-\u0D63\u0D66-\u0D6F\u0D7A-\u0D7F\u0D82\u0D83\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0DCA\u0DCF-\u0DD4\u0DD6\u0DD8-\u0DDF\u0DE6-\u0DEF\u0DF2\u0DF3\u0E01-\u0E3A\u0E40-\u0E4E\u0E50-\u0E59\u0E81\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB9\u0EBB-\u0EBD\u0EC0-\u0EC4\u0EC6\u0EC8-\u0ECD\u0ED0-\u0ED9\u0EDC-\u0EDF\u0F00\u0F18\u0F19\u0F20-\u0F29\u0F35\u0F37\u0F39\u0F3E-\u0F47\u0F49-\u0F6C\u0F71-\u0F84\u0F86-\u0F97\u0F99-\u0FBC\u0FC6\u1000-\u1049\u1050-\u109D\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u135D-\u135F\u1369-\u1371\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u170C\u170E-\u1714\u1720-\u1734\u1740-\u1753\u1760-\u176C\u176E-\u1770\u1772\u1773\u1780-\u17D3\u17D7\u17DC\u17DD\u17E0-\u17E9\u180B-\u180D\u1810-\u1819\u1820-\u1877\u1880-\u18AA\u18B0-\u18F5\u1900-\u191E\u1920-\u192B\u1930-\u193B\u1946-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u19D0-\u19DA\u1A00-\u1A1B\u1A20-\u1A5E\u1A60-\u1A7C\u1A7F-\u1A89\u1A90-\u1A99\u1AA7\u1AB0-\u1ABD\u1B00-\u1B4B\u1B50-\u1B59\u1B6B-\u1B73\u1B80-\u1BF3\u1C00-\u1C37\u1C40-\u1C49\u1C4D-\u1C7D\u1CD0-\u1CD2\u1CD4-\u1CF6\u1CF8\u1CF9\u1D00-\u1DF5\u1DFC-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u200C\u200D\u203F\u2040\u2054\u2071\u207F\u2090-\u209C\u20D0-\u20DC\u20E1\u20E5-\u20F0\u2102\u2107\u210A-\u2113\u2115\u2118-\u211D\u2124\u2126\u2128\u212A-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D7F-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2DE0-\u2DFF\u3005-\u3007\u3021-\u302F\u3031-\u3035\u3038-\u303C\u3041-\u3096\u3099-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312D\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FD5\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA62B\uA640-\uA66F\uA674-\uA67D\uA67F-\uA6F1\uA717-\uA71F\uA722-\uA788\uA78B-\uA7AD\uA7B0-\uA7B7\uA7F7-\uA827\uA840-\uA873\uA880-\uA8C4\uA8D0-\uA8D9\uA8E0-\uA8F7\uA8FB\uA8FD\uA900-\uA92D\uA930-\uA953\uA960-\uA97C\uA980-\uA9C0\uA9CF-\uA9D9\uA9E0-\uA9FE\uAA00-\uAA36\uAA40-\uAA4D\uAA50-\uAA59\uAA60-\uAA76\uAA7A-\uAAC2\uAADB-\uAADD\uAAE0-\uAAEF\uAAF2-\uAAF6\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB65\uAB70-\uABEA\uABEC\uABED\uABF0-\uABF9\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE00-\uFE0F\uFE20-\uFE2F\uFE33\uFE34\uFE4D-\uFE4F\uFE70-\uFE74\uFE76-\uFEFC\uFF10-\uFF19\uFF21-\uFF3A\uFF3F\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDD40-\uDD74\uDDFD\uDE80-\uDE9C\uDEA0-\uDED0\uDEE0\uDF00-\uDF1F\uDF30-\uDF4A\uDF50-\uDF7A\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF\uDFD1-\uDFD5]|\uD801[\uDC00-\uDC9D\uDCA0-\uDCA9\uDD00-\uDD27\uDD30-\uDD63\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC60-\uDC76\uDC80-\uDC9E\uDCE0-\uDCF2\uDCF4\uDCF5\uDD00-\uDD15\uDD20-\uDD39\uDD80-\uDDB7\uDDBE\uDDBF\uDE00-\uDE03\uDE05\uDE06\uDE0C-\uDE13\uDE15-\uDE17\uDE19-\uDE33\uDE38-\uDE3A\uDE3F\uDE60-\uDE7C\uDE80-\uDE9C\uDEC0-\uDEC7\uDEC9-\uDEE6\uDF00-\uDF35\uDF40-\uDF55\uDF60-\uDF72\uDF80-\uDF91]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2]|\uD804[\uDC00-\uDC46\uDC66-\uDC6F\uDC7F-\uDCBA\uDCD0-\uDCE8\uDCF0-\uDCF9\uDD00-\uDD34\uDD36-\uDD3F\uDD50-\uDD73\uDD76\uDD80-\uDDC4\uDDCA-\uDDCC\uDDD0-\uDDDA\uDDDC\uDE00-\uDE11\uDE13-\uDE37\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEEA\uDEF0-\uDEF9\uDF00-\uDF03\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3C-\uDF44\uDF47\uDF48\uDF4B-\uDF4D\uDF50\uDF57\uDF5D-\uDF63\uDF66-\uDF6C\uDF70-\uDF74]|\uD805[\uDC80-\uDCC5\uDCC7\uDCD0-\uDCD9\uDD80-\uDDB5\uDDB8-\uDDC0\uDDD8-\uDDDD\uDE00-\uDE40\uDE44\uDE50-\uDE59\uDE80-\uDEB7\uDEC0-\uDEC9\uDF00-\uDF19\uDF1D-\uDF2B\uDF30-\uDF39]|\uD806[\uDCA0-\uDCE9\uDCFF\uDEC0-\uDEF8]|\uD808[\uDC00-\uDF99]|\uD809[\uDC00-\uDC6E\uDC80-\uDD43]|[\uD80C\uD840-\uD868\uD86A-\uD86C\uD86F-\uD872][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2E]|\uD811[\uDC00-\uDE46]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDE60-\uDE69\uDED0-\uDEED\uDEF0-\uDEF4\uDF00-\uDF36\uDF40-\uDF43\uDF50-\uDF59\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDF00-\uDF44\uDF50-\uDF7E\uDF8F-\uDF9F]|\uD82C[\uDC00\uDC01]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99\uDC9D\uDC9E]|\uD834[\uDD65-\uDD69\uDD6D-\uDD72\uDD7B-\uDD82\uDD85-\uDD8B\uDDAA-\uDDAD\uDE42-\uDE44]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB\uDFCE-\uDFFF]|\uD836[\uDE00-\uDE36\uDE3B-\uDE6C\uDE75\uDE84\uDE9B-\uDE9F\uDEA1-\uDEAF]|\uD83A[\uDC00-\uDCC4\uDCD0-\uDCD6]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD869[\uDC00-\uDED6\uDF00-\uDFFF]|\uD86D[\uDC00-\uDF34\uDF40-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEA1]|\uD87E[\uDC00-\uDE1D]|\uDB40[\uDD00-\uDDEF]/
				};
				exports$5.Character = {
					fromCodePoint: function(cp) {
						return cp < 65536 ? String.fromCharCode(cp) : String.fromCharCode(55296 + (cp - 65536 >> 10)) + String.fromCharCode(56320 + (cp - 65536 & 1023));
					},
					isWhiteSpace: function(cp) {
						return cp === 32 || cp === 9 || cp === 11 || cp === 12 || cp === 160 || cp >= 5760 && [
							5760,
							8192,
							8193,
							8194,
							8195,
							8196,
							8197,
							8198,
							8199,
							8200,
							8201,
							8202,
							8239,
							8287,
							12288,
							65279
						].indexOf(cp) >= 0;
					},
					isLineTerminator: function(cp) {
						return cp === 10 || cp === 13 || cp === 8232 || cp === 8233;
					},
					isIdentifierStart: function(cp) {
						return cp === 36 || cp === 95 || cp >= 65 && cp <= 90 || cp >= 97 && cp <= 122 || cp === 92 || cp >= 128 && Regex.NonAsciiIdentifierStart.test(exports$5.Character.fromCodePoint(cp));
					},
					isIdentifierPart: function(cp) {
						return cp === 36 || cp === 95 || cp >= 65 && cp <= 90 || cp >= 97 && cp <= 122 || cp >= 48 && cp <= 57 || cp === 92 || cp >= 128 && Regex.NonAsciiIdentifierPart.test(exports$5.Character.fromCodePoint(cp));
					},
					isDecimalDigit: function(cp) {
						return cp >= 48 && cp <= 57;
					},
					isHexDigit: function(cp) {
						return cp >= 48 && cp <= 57 || cp >= 65 && cp <= 70 || cp >= 97 && cp <= 102;
					},
					isOctalDigit: function(cp) {
						return cp >= 48 && cp <= 55;
					}
				};
			},
			function(module$7, exports$6, __webpack_require__) {
				"use strict";
				Object.defineProperty(exports$6, "__esModule", { value: true });
				var jsx_syntax_1 = __webpack_require__(6);
				exports$6.JSXClosingElement = function() {
					function JSXClosingElement(name) {
						this.type = jsx_syntax_1.JSXSyntax.JSXClosingElement;
						this.name = name;
					}
					return JSXClosingElement;
				}();
				exports$6.JSXElement = function() {
					function JSXElement(openingElement, children, closingElement) {
						this.type = jsx_syntax_1.JSXSyntax.JSXElement;
						this.openingElement = openingElement;
						this.children = children;
						this.closingElement = closingElement;
					}
					return JSXElement;
				}();
				exports$6.JSXEmptyExpression = function() {
					function JSXEmptyExpression() {
						this.type = jsx_syntax_1.JSXSyntax.JSXEmptyExpression;
					}
					return JSXEmptyExpression;
				}();
				exports$6.JSXExpressionContainer = function() {
					function JSXExpressionContainer(expression) {
						this.type = jsx_syntax_1.JSXSyntax.JSXExpressionContainer;
						this.expression = expression;
					}
					return JSXExpressionContainer;
				}();
				exports$6.JSXIdentifier = function() {
					function JSXIdentifier(name) {
						this.type = jsx_syntax_1.JSXSyntax.JSXIdentifier;
						this.name = name;
					}
					return JSXIdentifier;
				}();
				exports$6.JSXMemberExpression = function() {
					function JSXMemberExpression(object, property) {
						this.type = jsx_syntax_1.JSXSyntax.JSXMemberExpression;
						this.object = object;
						this.property = property;
					}
					return JSXMemberExpression;
				}();
				exports$6.JSXAttribute = function() {
					function JSXAttribute(name, value) {
						this.type = jsx_syntax_1.JSXSyntax.JSXAttribute;
						this.name = name;
						this.value = value;
					}
					return JSXAttribute;
				}();
				exports$6.JSXNamespacedName = function() {
					function JSXNamespacedName(namespace, name) {
						this.type = jsx_syntax_1.JSXSyntax.JSXNamespacedName;
						this.namespace = namespace;
						this.name = name;
					}
					return JSXNamespacedName;
				}();
				exports$6.JSXOpeningElement = function() {
					function JSXOpeningElement(name, selfClosing, attributes) {
						this.type = jsx_syntax_1.JSXSyntax.JSXOpeningElement;
						this.name = name;
						this.selfClosing = selfClosing;
						this.attributes = attributes;
					}
					return JSXOpeningElement;
				}();
				exports$6.JSXSpreadAttribute = function() {
					function JSXSpreadAttribute(argument) {
						this.type = jsx_syntax_1.JSXSyntax.JSXSpreadAttribute;
						this.argument = argument;
					}
					return JSXSpreadAttribute;
				}();
				exports$6.JSXText = function() {
					function JSXText(value, raw) {
						this.type = jsx_syntax_1.JSXSyntax.JSXText;
						this.value = value;
						this.raw = raw;
					}
					return JSXText;
				}();
			},
			function(module$8, exports$7) {
				"use strict";
				Object.defineProperty(exports$7, "__esModule", { value: true });
				exports$7.JSXSyntax = {
					JSXAttribute: "JSXAttribute",
					JSXClosingElement: "JSXClosingElement",
					JSXElement: "JSXElement",
					JSXEmptyExpression: "JSXEmptyExpression",
					JSXExpressionContainer: "JSXExpressionContainer",
					JSXIdentifier: "JSXIdentifier",
					JSXMemberExpression: "JSXMemberExpression",
					JSXNamespacedName: "JSXNamespacedName",
					JSXOpeningElement: "JSXOpeningElement",
					JSXSpreadAttribute: "JSXSpreadAttribute",
					JSXText: "JSXText"
				};
			},
			function(module$9, exports$8, __webpack_require__) {
				"use strict";
				Object.defineProperty(exports$8, "__esModule", { value: true });
				var syntax_1 = __webpack_require__(2);
				exports$8.ArrayExpression = function() {
					function ArrayExpression(elements) {
						this.type = syntax_1.Syntax.ArrayExpression;
						this.elements = elements;
					}
					return ArrayExpression;
				}();
				exports$8.ArrayPattern = function() {
					function ArrayPattern(elements) {
						this.type = syntax_1.Syntax.ArrayPattern;
						this.elements = elements;
					}
					return ArrayPattern;
				}();
				exports$8.ArrowFunctionExpression = function() {
					function ArrowFunctionExpression(params, body, expression) {
						this.type = syntax_1.Syntax.ArrowFunctionExpression;
						this.id = null;
						this.params = params;
						this.body = body;
						this.generator = false;
						this.expression = expression;
						this.async = false;
					}
					return ArrowFunctionExpression;
				}();
				exports$8.AssignmentExpression = function() {
					function AssignmentExpression(operator, left, right) {
						this.type = syntax_1.Syntax.AssignmentExpression;
						this.operator = operator;
						this.left = left;
						this.right = right;
					}
					return AssignmentExpression;
				}();
				exports$8.AssignmentPattern = function() {
					function AssignmentPattern(left, right) {
						this.type = syntax_1.Syntax.AssignmentPattern;
						this.left = left;
						this.right = right;
					}
					return AssignmentPattern;
				}();
				exports$8.AsyncArrowFunctionExpression = function() {
					function AsyncArrowFunctionExpression(params, body, expression) {
						this.type = syntax_1.Syntax.ArrowFunctionExpression;
						this.id = null;
						this.params = params;
						this.body = body;
						this.generator = false;
						this.expression = expression;
						this.async = true;
					}
					return AsyncArrowFunctionExpression;
				}();
				exports$8.AsyncFunctionDeclaration = function() {
					function AsyncFunctionDeclaration(id, params, body) {
						this.type = syntax_1.Syntax.FunctionDeclaration;
						this.id = id;
						this.params = params;
						this.body = body;
						this.generator = false;
						this.expression = false;
						this.async = true;
					}
					return AsyncFunctionDeclaration;
				}();
				exports$8.AsyncFunctionExpression = function() {
					function AsyncFunctionExpression(id, params, body) {
						this.type = syntax_1.Syntax.FunctionExpression;
						this.id = id;
						this.params = params;
						this.body = body;
						this.generator = false;
						this.expression = false;
						this.async = true;
					}
					return AsyncFunctionExpression;
				}();
				exports$8.AwaitExpression = function() {
					function AwaitExpression(argument) {
						this.type = syntax_1.Syntax.AwaitExpression;
						this.argument = argument;
					}
					return AwaitExpression;
				}();
				exports$8.BinaryExpression = function() {
					function BinaryExpression(operator, left, right) {
						var logical = operator === "||" || operator === "&&";
						this.type = logical ? syntax_1.Syntax.LogicalExpression : syntax_1.Syntax.BinaryExpression;
						this.operator = operator;
						this.left = left;
						this.right = right;
					}
					return BinaryExpression;
				}();
				exports$8.BlockStatement = function() {
					function BlockStatement(body) {
						this.type = syntax_1.Syntax.BlockStatement;
						this.body = body;
					}
					return BlockStatement;
				}();
				exports$8.BreakStatement = function() {
					function BreakStatement(label) {
						this.type = syntax_1.Syntax.BreakStatement;
						this.label = label;
					}
					return BreakStatement;
				}();
				exports$8.CallExpression = function() {
					function CallExpression(callee, args) {
						this.type = syntax_1.Syntax.CallExpression;
						this.callee = callee;
						this.arguments = args;
					}
					return CallExpression;
				}();
				exports$8.CatchClause = function() {
					function CatchClause(param, body) {
						this.type = syntax_1.Syntax.CatchClause;
						this.param = param;
						this.body = body;
					}
					return CatchClause;
				}();
				exports$8.ClassBody = function() {
					function ClassBody(body) {
						this.type = syntax_1.Syntax.ClassBody;
						this.body = body;
					}
					return ClassBody;
				}();
				exports$8.ClassDeclaration = function() {
					function ClassDeclaration(id, superClass, body) {
						this.type = syntax_1.Syntax.ClassDeclaration;
						this.id = id;
						this.superClass = superClass;
						this.body = body;
					}
					return ClassDeclaration;
				}();
				exports$8.ClassExpression = function() {
					function ClassExpression(id, superClass, body) {
						this.type = syntax_1.Syntax.ClassExpression;
						this.id = id;
						this.superClass = superClass;
						this.body = body;
					}
					return ClassExpression;
				}();
				exports$8.ComputedMemberExpression = function() {
					function ComputedMemberExpression(object, property) {
						this.type = syntax_1.Syntax.MemberExpression;
						this.computed = true;
						this.object = object;
						this.property = property;
					}
					return ComputedMemberExpression;
				}();
				exports$8.ConditionalExpression = function() {
					function ConditionalExpression(test, consequent, alternate) {
						this.type = syntax_1.Syntax.ConditionalExpression;
						this.test = test;
						this.consequent = consequent;
						this.alternate = alternate;
					}
					return ConditionalExpression;
				}();
				exports$8.ContinueStatement = function() {
					function ContinueStatement(label) {
						this.type = syntax_1.Syntax.ContinueStatement;
						this.label = label;
					}
					return ContinueStatement;
				}();
				exports$8.DebuggerStatement = function() {
					function DebuggerStatement() {
						this.type = syntax_1.Syntax.DebuggerStatement;
					}
					return DebuggerStatement;
				}();
				exports$8.Directive = function() {
					function Directive(expression, directive) {
						this.type = syntax_1.Syntax.ExpressionStatement;
						this.expression = expression;
						this.directive = directive;
					}
					return Directive;
				}();
				exports$8.DoWhileStatement = function() {
					function DoWhileStatement(body, test) {
						this.type = syntax_1.Syntax.DoWhileStatement;
						this.body = body;
						this.test = test;
					}
					return DoWhileStatement;
				}();
				exports$8.EmptyStatement = function() {
					function EmptyStatement() {
						this.type = syntax_1.Syntax.EmptyStatement;
					}
					return EmptyStatement;
				}();
				exports$8.ExportAllDeclaration = function() {
					function ExportAllDeclaration(source) {
						this.type = syntax_1.Syntax.ExportAllDeclaration;
						this.source = source;
					}
					return ExportAllDeclaration;
				}();
				exports$8.ExportDefaultDeclaration = function() {
					function ExportDefaultDeclaration(declaration) {
						this.type = syntax_1.Syntax.ExportDefaultDeclaration;
						this.declaration = declaration;
					}
					return ExportDefaultDeclaration;
				}();
				exports$8.ExportNamedDeclaration = function() {
					function ExportNamedDeclaration(declaration, specifiers, source) {
						this.type = syntax_1.Syntax.ExportNamedDeclaration;
						this.declaration = declaration;
						this.specifiers = specifiers;
						this.source = source;
					}
					return ExportNamedDeclaration;
				}();
				exports$8.ExportSpecifier = function() {
					function ExportSpecifier(local, exported) {
						this.type = syntax_1.Syntax.ExportSpecifier;
						this.exported = exported;
						this.local = local;
					}
					return ExportSpecifier;
				}();
				exports$8.ExpressionStatement = function() {
					function ExpressionStatement(expression) {
						this.type = syntax_1.Syntax.ExpressionStatement;
						this.expression = expression;
					}
					return ExpressionStatement;
				}();
				exports$8.ForInStatement = function() {
					function ForInStatement(left, right, body) {
						this.type = syntax_1.Syntax.ForInStatement;
						this.left = left;
						this.right = right;
						this.body = body;
						this.each = false;
					}
					return ForInStatement;
				}();
				exports$8.ForOfStatement = function() {
					function ForOfStatement(left, right, body) {
						this.type = syntax_1.Syntax.ForOfStatement;
						this.left = left;
						this.right = right;
						this.body = body;
					}
					return ForOfStatement;
				}();
				exports$8.ForStatement = function() {
					function ForStatement(init, test, update, body) {
						this.type = syntax_1.Syntax.ForStatement;
						this.init = init;
						this.test = test;
						this.update = update;
						this.body = body;
					}
					return ForStatement;
				}();
				exports$8.FunctionDeclaration = function() {
					function FunctionDeclaration(id, params, body, generator) {
						this.type = syntax_1.Syntax.FunctionDeclaration;
						this.id = id;
						this.params = params;
						this.body = body;
						this.generator = generator;
						this.expression = false;
						this.async = false;
					}
					return FunctionDeclaration;
				}();
				exports$8.FunctionExpression = function() {
					function FunctionExpression(id, params, body, generator) {
						this.type = syntax_1.Syntax.FunctionExpression;
						this.id = id;
						this.params = params;
						this.body = body;
						this.generator = generator;
						this.expression = false;
						this.async = false;
					}
					return FunctionExpression;
				}();
				exports$8.Identifier = function() {
					function Identifier(name) {
						this.type = syntax_1.Syntax.Identifier;
						this.name = name;
					}
					return Identifier;
				}();
				exports$8.IfStatement = function() {
					function IfStatement(test, consequent, alternate) {
						this.type = syntax_1.Syntax.IfStatement;
						this.test = test;
						this.consequent = consequent;
						this.alternate = alternate;
					}
					return IfStatement;
				}();
				exports$8.ImportDeclaration = function() {
					function ImportDeclaration(specifiers, source) {
						this.type = syntax_1.Syntax.ImportDeclaration;
						this.specifiers = specifiers;
						this.source = source;
					}
					return ImportDeclaration;
				}();
				exports$8.ImportDefaultSpecifier = function() {
					function ImportDefaultSpecifier(local) {
						this.type = syntax_1.Syntax.ImportDefaultSpecifier;
						this.local = local;
					}
					return ImportDefaultSpecifier;
				}();
				exports$8.ImportNamespaceSpecifier = function() {
					function ImportNamespaceSpecifier(local) {
						this.type = syntax_1.Syntax.ImportNamespaceSpecifier;
						this.local = local;
					}
					return ImportNamespaceSpecifier;
				}();
				exports$8.ImportSpecifier = function() {
					function ImportSpecifier(local, imported) {
						this.type = syntax_1.Syntax.ImportSpecifier;
						this.local = local;
						this.imported = imported;
					}
					return ImportSpecifier;
				}();
				exports$8.LabeledStatement = function() {
					function LabeledStatement(label, body) {
						this.type = syntax_1.Syntax.LabeledStatement;
						this.label = label;
						this.body = body;
					}
					return LabeledStatement;
				}();
				exports$8.Literal = function() {
					function Literal(value, raw) {
						this.type = syntax_1.Syntax.Literal;
						this.value = value;
						this.raw = raw;
					}
					return Literal;
				}();
				exports$8.MetaProperty = function() {
					function MetaProperty(meta, property) {
						this.type = syntax_1.Syntax.MetaProperty;
						this.meta = meta;
						this.property = property;
					}
					return MetaProperty;
				}();
				exports$8.MethodDefinition = function() {
					function MethodDefinition(key, computed, value, kind, isStatic) {
						this.type = syntax_1.Syntax.MethodDefinition;
						this.key = key;
						this.computed = computed;
						this.value = value;
						this.kind = kind;
						this.static = isStatic;
					}
					return MethodDefinition;
				}();
				exports$8.Module = function() {
					function Module(body) {
						this.type = syntax_1.Syntax.Program;
						this.body = body;
						this.sourceType = "module";
					}
					return Module;
				}();
				exports$8.NewExpression = function() {
					function NewExpression(callee, args) {
						this.type = syntax_1.Syntax.NewExpression;
						this.callee = callee;
						this.arguments = args;
					}
					return NewExpression;
				}();
				exports$8.ObjectExpression = function() {
					function ObjectExpression(properties) {
						this.type = syntax_1.Syntax.ObjectExpression;
						this.properties = properties;
					}
					return ObjectExpression;
				}();
				exports$8.ObjectPattern = function() {
					function ObjectPattern(properties) {
						this.type = syntax_1.Syntax.ObjectPattern;
						this.properties = properties;
					}
					return ObjectPattern;
				}();
				exports$8.Property = function() {
					function Property(kind, key, computed, value, method, shorthand) {
						this.type = syntax_1.Syntax.Property;
						this.key = key;
						this.computed = computed;
						this.value = value;
						this.kind = kind;
						this.method = method;
						this.shorthand = shorthand;
					}
					return Property;
				}();
				exports$8.RegexLiteral = function() {
					function RegexLiteral(value, raw, pattern, flags) {
						this.type = syntax_1.Syntax.Literal;
						this.value = value;
						this.raw = raw;
						this.regex = {
							pattern,
							flags
						};
					}
					return RegexLiteral;
				}();
				exports$8.RestElement = function() {
					function RestElement(argument) {
						this.type = syntax_1.Syntax.RestElement;
						this.argument = argument;
					}
					return RestElement;
				}();
				exports$8.ReturnStatement = function() {
					function ReturnStatement(argument) {
						this.type = syntax_1.Syntax.ReturnStatement;
						this.argument = argument;
					}
					return ReturnStatement;
				}();
				exports$8.Script = function() {
					function Script(body) {
						this.type = syntax_1.Syntax.Program;
						this.body = body;
						this.sourceType = "script";
					}
					return Script;
				}();
				exports$8.SequenceExpression = function() {
					function SequenceExpression(expressions) {
						this.type = syntax_1.Syntax.SequenceExpression;
						this.expressions = expressions;
					}
					return SequenceExpression;
				}();
				exports$8.SpreadElement = function() {
					function SpreadElement(argument) {
						this.type = syntax_1.Syntax.SpreadElement;
						this.argument = argument;
					}
					return SpreadElement;
				}();
				exports$8.StaticMemberExpression = function() {
					function StaticMemberExpression(object, property) {
						this.type = syntax_1.Syntax.MemberExpression;
						this.computed = false;
						this.object = object;
						this.property = property;
					}
					return StaticMemberExpression;
				}();
				exports$8.Super = function() {
					function Super() {
						this.type = syntax_1.Syntax.Super;
					}
					return Super;
				}();
				exports$8.SwitchCase = function() {
					function SwitchCase(test, consequent) {
						this.type = syntax_1.Syntax.SwitchCase;
						this.test = test;
						this.consequent = consequent;
					}
					return SwitchCase;
				}();
				exports$8.SwitchStatement = function() {
					function SwitchStatement(discriminant, cases) {
						this.type = syntax_1.Syntax.SwitchStatement;
						this.discriminant = discriminant;
						this.cases = cases;
					}
					return SwitchStatement;
				}();
				exports$8.TaggedTemplateExpression = function() {
					function TaggedTemplateExpression(tag, quasi) {
						this.type = syntax_1.Syntax.TaggedTemplateExpression;
						this.tag = tag;
						this.quasi = quasi;
					}
					return TaggedTemplateExpression;
				}();
				exports$8.TemplateElement = function() {
					function TemplateElement(value, tail) {
						this.type = syntax_1.Syntax.TemplateElement;
						this.value = value;
						this.tail = tail;
					}
					return TemplateElement;
				}();
				exports$8.TemplateLiteral = function() {
					function TemplateLiteral(quasis, expressions) {
						this.type = syntax_1.Syntax.TemplateLiteral;
						this.quasis = quasis;
						this.expressions = expressions;
					}
					return TemplateLiteral;
				}();
				exports$8.ThisExpression = function() {
					function ThisExpression() {
						this.type = syntax_1.Syntax.ThisExpression;
					}
					return ThisExpression;
				}();
				exports$8.ThrowStatement = function() {
					function ThrowStatement(argument) {
						this.type = syntax_1.Syntax.ThrowStatement;
						this.argument = argument;
					}
					return ThrowStatement;
				}();
				exports$8.TryStatement = function() {
					function TryStatement(block, handler, finalizer) {
						this.type = syntax_1.Syntax.TryStatement;
						this.block = block;
						this.handler = handler;
						this.finalizer = finalizer;
					}
					return TryStatement;
				}();
				exports$8.UnaryExpression = function() {
					function UnaryExpression(operator, argument) {
						this.type = syntax_1.Syntax.UnaryExpression;
						this.operator = operator;
						this.argument = argument;
						this.prefix = true;
					}
					return UnaryExpression;
				}();
				exports$8.UpdateExpression = function() {
					function UpdateExpression(operator, argument, prefix) {
						this.type = syntax_1.Syntax.UpdateExpression;
						this.operator = operator;
						this.argument = argument;
						this.prefix = prefix;
					}
					return UpdateExpression;
				}();
				exports$8.VariableDeclaration = function() {
					function VariableDeclaration(declarations, kind) {
						this.type = syntax_1.Syntax.VariableDeclaration;
						this.declarations = declarations;
						this.kind = kind;
					}
					return VariableDeclaration;
				}();
				exports$8.VariableDeclarator = function() {
					function VariableDeclarator(id, init) {
						this.type = syntax_1.Syntax.VariableDeclarator;
						this.id = id;
						this.init = init;
					}
					return VariableDeclarator;
				}();
				exports$8.WhileStatement = function() {
					function WhileStatement(test, body) {
						this.type = syntax_1.Syntax.WhileStatement;
						this.test = test;
						this.body = body;
					}
					return WhileStatement;
				}();
				exports$8.WithStatement = function() {
					function WithStatement(object, body) {
						this.type = syntax_1.Syntax.WithStatement;
						this.object = object;
						this.body = body;
					}
					return WithStatement;
				}();
				exports$8.YieldExpression = function() {
					function YieldExpression(argument, delegate) {
						this.type = syntax_1.Syntax.YieldExpression;
						this.argument = argument;
						this.delegate = delegate;
					}
					return YieldExpression;
				}();
			},
			function(module$10, exports$9, __webpack_require__) {
				"use strict";
				Object.defineProperty(exports$9, "__esModule", { value: true });
				var assert_1 = __webpack_require__(9);
				var error_handler_1 = __webpack_require__(10);
				var messages_1 = __webpack_require__(11);
				var Node = __webpack_require__(7);
				var scanner_1 = __webpack_require__(12);
				var syntax_1 = __webpack_require__(2);
				var token_1 = __webpack_require__(13);
				var ArrowParameterPlaceHolder = "ArrowParameterPlaceHolder";
				exports$9.Parser = function() {
					function Parser(code, options, delegate) {
						if (options === void 0) options = {};
						this.config = {
							range: typeof options.range === "boolean" && options.range,
							loc: typeof options.loc === "boolean" && options.loc,
							source: null,
							tokens: typeof options.tokens === "boolean" && options.tokens,
							comment: typeof options.comment === "boolean" && options.comment,
							tolerant: typeof options.tolerant === "boolean" && options.tolerant
						};
						if (this.config.loc && options.source && options.source !== null) this.config.source = String(options.source);
						this.delegate = delegate;
						this.errorHandler = new error_handler_1.ErrorHandler();
						this.errorHandler.tolerant = this.config.tolerant;
						this.scanner = new scanner_1.Scanner(code, this.errorHandler);
						this.scanner.trackComment = this.config.comment;
						this.operatorPrecedence = {
							")": 0,
							";": 0,
							",": 0,
							"=": 0,
							"]": 0,
							"||": 1,
							"&&": 2,
							"|": 3,
							"^": 4,
							"&": 5,
							"==": 6,
							"!=": 6,
							"===": 6,
							"!==": 6,
							"<": 7,
							">": 7,
							"<=": 7,
							">=": 7,
							"<<": 8,
							">>": 8,
							">>>": 8,
							"+": 9,
							"-": 9,
							"*": 11,
							"/": 11,
							"%": 11
						};
						this.lookahead = {
							type: 2,
							value: "",
							lineNumber: this.scanner.lineNumber,
							lineStart: 0,
							start: 0,
							end: 0
						};
						this.hasLineTerminator = false;
						this.context = {
							isModule: false,
							await: false,
							allowIn: true,
							allowStrictDirective: true,
							allowYield: true,
							firstCoverInitializedNameError: null,
							isAssignmentTarget: false,
							isBindingElement: false,
							inFunctionBody: false,
							inIteration: false,
							inSwitch: false,
							labelSet: {},
							strict: false
						};
						this.tokens = [];
						this.startMarker = {
							index: 0,
							line: this.scanner.lineNumber,
							column: 0
						};
						this.lastMarker = {
							index: 0,
							line: this.scanner.lineNumber,
							column: 0
						};
						this.nextToken();
						this.lastMarker = {
							index: this.scanner.index,
							line: this.scanner.lineNumber,
							column: this.scanner.index - this.scanner.lineStart
						};
					}
					Parser.prototype.throwError = function(messageFormat) {
						var values = [];
						for (var _i = 1; _i < arguments.length; _i++) values[_i - 1] = arguments[_i];
						var args = Array.prototype.slice.call(arguments, 1);
						var msg = messageFormat.replace(/%(\d)/g, function(whole, idx) {
							assert_1.assert(idx < args.length, "Message reference must be in range");
							return args[idx];
						});
						var index = this.lastMarker.index;
						var line = this.lastMarker.line;
						var column = this.lastMarker.column + 1;
						throw this.errorHandler.createError(index, line, column, msg);
					};
					Parser.prototype.tolerateError = function(messageFormat) {
						var values = [];
						for (var _i = 1; _i < arguments.length; _i++) values[_i - 1] = arguments[_i];
						var args = Array.prototype.slice.call(arguments, 1);
						var msg = messageFormat.replace(/%(\d)/g, function(whole, idx) {
							assert_1.assert(idx < args.length, "Message reference must be in range");
							return args[idx];
						});
						var index = this.lastMarker.index;
						var line = this.scanner.lineNumber;
						var column = this.lastMarker.column + 1;
						this.errorHandler.tolerateError(index, line, column, msg);
					};
					Parser.prototype.unexpectedTokenError = function(token, message) {
						var msg = message || messages_1.Messages.UnexpectedToken;
						var value;
						if (token) {
							if (!message) {
								msg = token.type === 2 ? messages_1.Messages.UnexpectedEOS : token.type === 3 ? messages_1.Messages.UnexpectedIdentifier : token.type === 6 ? messages_1.Messages.UnexpectedNumber : token.type === 8 ? messages_1.Messages.UnexpectedString : token.type === 10 ? messages_1.Messages.UnexpectedTemplate : messages_1.Messages.UnexpectedToken;
								if (token.type === 4) {
									if (this.scanner.isFutureReservedWord(token.value)) msg = messages_1.Messages.UnexpectedReserved;
									else if (this.context.strict && this.scanner.isStrictModeReservedWord(token.value)) msg = messages_1.Messages.StrictReservedWord;
								}
							}
							value = token.value;
						} else value = "ILLEGAL";
						msg = msg.replace("%0", value);
						if (token && typeof token.lineNumber === "number") {
							var index = token.start;
							var line = token.lineNumber;
							var lastMarkerLineStart = this.lastMarker.index - this.lastMarker.column;
							var column = token.start - lastMarkerLineStart + 1;
							return this.errorHandler.createError(index, line, column, msg);
						} else {
							var index = this.lastMarker.index;
							var line = this.lastMarker.line;
							var column = this.lastMarker.column + 1;
							return this.errorHandler.createError(index, line, column, msg);
						}
					};
					Parser.prototype.throwUnexpectedToken = function(token, message) {
						throw this.unexpectedTokenError(token, message);
					};
					Parser.prototype.tolerateUnexpectedToken = function(token, message) {
						this.errorHandler.tolerate(this.unexpectedTokenError(token, message));
					};
					Parser.prototype.collectComments = function() {
						if (!this.config.comment) this.scanner.scanComments();
						else {
							var comments = this.scanner.scanComments();
							if (comments.length > 0 && this.delegate) for (var i = 0; i < comments.length; ++i) {
								var e = comments[i];
								var node = void 0;
								node = {
									type: e.multiLine ? "BlockComment" : "LineComment",
									value: this.scanner.source.slice(e.slice[0], e.slice[1])
								};
								if (this.config.range) node.range = e.range;
								if (this.config.loc) node.loc = e.loc;
								var metadata = {
									start: {
										line: e.loc.start.line,
										column: e.loc.start.column,
										offset: e.range[0]
									},
									end: {
										line: e.loc.end.line,
										column: e.loc.end.column,
										offset: e.range[1]
									}
								};
								this.delegate(node, metadata);
							}
						}
					};
					Parser.prototype.getTokenRaw = function(token) {
						return this.scanner.source.slice(token.start, token.end);
					};
					Parser.prototype.convertToken = function(token) {
						var t = {
							type: token_1.TokenName[token.type],
							value: this.getTokenRaw(token)
						};
						if (this.config.range) t.range = [token.start, token.end];
						if (this.config.loc) t.loc = {
							start: {
								line: this.startMarker.line,
								column: this.startMarker.column
							},
							end: {
								line: this.scanner.lineNumber,
								column: this.scanner.index - this.scanner.lineStart
							}
						};
						if (token.type === 9) t.regex = {
							pattern: token.pattern,
							flags: token.flags
						};
						return t;
					};
					Parser.prototype.nextToken = function() {
						var token = this.lookahead;
						this.lastMarker.index = this.scanner.index;
						this.lastMarker.line = this.scanner.lineNumber;
						this.lastMarker.column = this.scanner.index - this.scanner.lineStart;
						this.collectComments();
						if (this.scanner.index !== this.startMarker.index) {
							this.startMarker.index = this.scanner.index;
							this.startMarker.line = this.scanner.lineNumber;
							this.startMarker.column = this.scanner.index - this.scanner.lineStart;
						}
						var next = this.scanner.lex();
						this.hasLineTerminator = token.lineNumber !== next.lineNumber;
						if (next && this.context.strict && next.type === 3) {
							if (this.scanner.isStrictModeReservedWord(next.value)) next.type = 4;
						}
						this.lookahead = next;
						if (this.config.tokens && next.type !== 2) this.tokens.push(this.convertToken(next));
						return token;
					};
					Parser.prototype.nextRegexToken = function() {
						this.collectComments();
						var token = this.scanner.scanRegExp();
						if (this.config.tokens) {
							this.tokens.pop();
							this.tokens.push(this.convertToken(token));
						}
						this.lookahead = token;
						this.nextToken();
						return token;
					};
					Parser.prototype.createNode = function() {
						return {
							index: this.startMarker.index,
							line: this.startMarker.line,
							column: this.startMarker.column
						};
					};
					Parser.prototype.startNode = function(token, lastLineStart) {
						if (lastLineStart === void 0) lastLineStart = 0;
						var column = token.start - token.lineStart;
						var line = token.lineNumber;
						if (column < 0) {
							column += lastLineStart;
							line--;
						}
						return {
							index: token.start,
							line,
							column
						};
					};
					Parser.prototype.finalize = function(marker, node) {
						if (this.config.range) node.range = [marker.index, this.lastMarker.index];
						if (this.config.loc) {
							node.loc = {
								start: {
									line: marker.line,
									column: marker.column
								},
								end: {
									line: this.lastMarker.line,
									column: this.lastMarker.column
								}
							};
							if (this.config.source) node.loc.source = this.config.source;
						}
						if (this.delegate) {
							var metadata = {
								start: {
									line: marker.line,
									column: marker.column,
									offset: marker.index
								},
								end: {
									line: this.lastMarker.line,
									column: this.lastMarker.column,
									offset: this.lastMarker.index
								}
							};
							this.delegate(node, metadata);
						}
						return node;
					};
					Parser.prototype.expect = function(value) {
						var token = this.nextToken();
						if (token.type !== 7 || token.value !== value) this.throwUnexpectedToken(token);
					};
					Parser.prototype.expectCommaSeparator = function() {
						if (this.config.tolerant) {
							var token = this.lookahead;
							if (token.type === 7 && token.value === ",") this.nextToken();
							else if (token.type === 7 && token.value === ";") {
								this.nextToken();
								this.tolerateUnexpectedToken(token);
							} else this.tolerateUnexpectedToken(token, messages_1.Messages.UnexpectedToken);
						} else this.expect(",");
					};
					Parser.prototype.expectKeyword = function(keyword) {
						var token = this.nextToken();
						if (token.type !== 4 || token.value !== keyword) this.throwUnexpectedToken(token);
					};
					Parser.prototype.match = function(value) {
						return this.lookahead.type === 7 && this.lookahead.value === value;
					};
					Parser.prototype.matchKeyword = function(keyword) {
						return this.lookahead.type === 4 && this.lookahead.value === keyword;
					};
					Parser.prototype.matchContextualKeyword = function(keyword) {
						return this.lookahead.type === 3 && this.lookahead.value === keyword;
					};
					Parser.prototype.matchAssign = function() {
						if (this.lookahead.type !== 7) return false;
						var op = this.lookahead.value;
						return op === "=" || op === "*=" || op === "**=" || op === "/=" || op === "%=" || op === "+=" || op === "-=" || op === "<<=" || op === ">>=" || op === ">>>=" || op === "&=" || op === "^=" || op === "|=";
					};
					Parser.prototype.isolateCoverGrammar = function(parseFunction) {
						var previousIsBindingElement = this.context.isBindingElement;
						var previousIsAssignmentTarget = this.context.isAssignmentTarget;
						var previousFirstCoverInitializedNameError = this.context.firstCoverInitializedNameError;
						this.context.isBindingElement = true;
						this.context.isAssignmentTarget = true;
						this.context.firstCoverInitializedNameError = null;
						var result = parseFunction.call(this);
						if (this.context.firstCoverInitializedNameError !== null) this.throwUnexpectedToken(this.context.firstCoverInitializedNameError);
						this.context.isBindingElement = previousIsBindingElement;
						this.context.isAssignmentTarget = previousIsAssignmentTarget;
						this.context.firstCoverInitializedNameError = previousFirstCoverInitializedNameError;
						return result;
					};
					Parser.prototype.inheritCoverGrammar = function(parseFunction) {
						var previousIsBindingElement = this.context.isBindingElement;
						var previousIsAssignmentTarget = this.context.isAssignmentTarget;
						var previousFirstCoverInitializedNameError = this.context.firstCoverInitializedNameError;
						this.context.isBindingElement = true;
						this.context.isAssignmentTarget = true;
						this.context.firstCoverInitializedNameError = null;
						var result = parseFunction.call(this);
						this.context.isBindingElement = this.context.isBindingElement && previousIsBindingElement;
						this.context.isAssignmentTarget = this.context.isAssignmentTarget && previousIsAssignmentTarget;
						this.context.firstCoverInitializedNameError = previousFirstCoverInitializedNameError || this.context.firstCoverInitializedNameError;
						return result;
					};
					Parser.prototype.consumeSemicolon = function() {
						if (this.match(";")) this.nextToken();
						else if (!this.hasLineTerminator) {
							if (this.lookahead.type !== 2 && !this.match("}")) this.throwUnexpectedToken(this.lookahead);
							this.lastMarker.index = this.startMarker.index;
							this.lastMarker.line = this.startMarker.line;
							this.lastMarker.column = this.startMarker.column;
						}
					};
					Parser.prototype.parsePrimaryExpression = function() {
						var node = this.createNode();
						var expr;
						var token, raw;
						switch (this.lookahead.type) {
							case 3:
								if ((this.context.isModule || this.context.await) && this.lookahead.value === "await") this.tolerateUnexpectedToken(this.lookahead);
								expr = this.matchAsyncFunction() ? this.parseFunctionExpression() : this.finalize(node, new Node.Identifier(this.nextToken().value));
								break;
							case 6:
							case 8:
								if (this.context.strict && this.lookahead.octal) this.tolerateUnexpectedToken(this.lookahead, messages_1.Messages.StrictOctalLiteral);
								this.context.isAssignmentTarget = false;
								this.context.isBindingElement = false;
								token = this.nextToken();
								raw = this.getTokenRaw(token);
								expr = this.finalize(node, new Node.Literal(token.value, raw));
								break;
							case 1:
								this.context.isAssignmentTarget = false;
								this.context.isBindingElement = false;
								token = this.nextToken();
								raw = this.getTokenRaw(token);
								expr = this.finalize(node, new Node.Literal(token.value === "true", raw));
								break;
							case 5:
								this.context.isAssignmentTarget = false;
								this.context.isBindingElement = false;
								token = this.nextToken();
								raw = this.getTokenRaw(token);
								expr = this.finalize(node, new Node.Literal(null, raw));
								break;
							case 10:
								expr = this.parseTemplateLiteral();
								break;
							case 7:
								switch (this.lookahead.value) {
									case "(":
										this.context.isBindingElement = false;
										expr = this.inheritCoverGrammar(this.parseGroupExpression);
										break;
									case "[":
										expr = this.inheritCoverGrammar(this.parseArrayInitializer);
										break;
									case "{":
										expr = this.inheritCoverGrammar(this.parseObjectInitializer);
										break;
									case "/":
									case "/=":
										this.context.isAssignmentTarget = false;
										this.context.isBindingElement = false;
										this.scanner.index = this.startMarker.index;
										token = this.nextRegexToken();
										raw = this.getTokenRaw(token);
										expr = this.finalize(node, new Node.RegexLiteral(token.regex, raw, token.pattern, token.flags));
										break;
									default: expr = this.throwUnexpectedToken(this.nextToken());
								}
								break;
							case 4:
								if (!this.context.strict && this.context.allowYield && this.matchKeyword("yield")) expr = this.parseIdentifierName();
								else if (!this.context.strict && this.matchKeyword("let")) expr = this.finalize(node, new Node.Identifier(this.nextToken().value));
								else {
									this.context.isAssignmentTarget = false;
									this.context.isBindingElement = false;
									if (this.matchKeyword("function")) expr = this.parseFunctionExpression();
									else if (this.matchKeyword("this")) {
										this.nextToken();
										expr = this.finalize(node, new Node.ThisExpression());
									} else if (this.matchKeyword("class")) expr = this.parseClassExpression();
									else expr = this.throwUnexpectedToken(this.nextToken());
								}
								break;
							default: expr = this.throwUnexpectedToken(this.nextToken());
						}
						return expr;
					};
					Parser.prototype.parseSpreadElement = function() {
						var node = this.createNode();
						this.expect("...");
						var arg = this.inheritCoverGrammar(this.parseAssignmentExpression);
						return this.finalize(node, new Node.SpreadElement(arg));
					};
					Parser.prototype.parseArrayInitializer = function() {
						var node = this.createNode();
						var elements = [];
						this.expect("[");
						while (!this.match("]")) if (this.match(",")) {
							this.nextToken();
							elements.push(null);
						} else if (this.match("...")) {
							var element = this.parseSpreadElement();
							if (!this.match("]")) {
								this.context.isAssignmentTarget = false;
								this.context.isBindingElement = false;
								this.expect(",");
							}
							elements.push(element);
						} else {
							elements.push(this.inheritCoverGrammar(this.parseAssignmentExpression));
							if (!this.match("]")) this.expect(",");
						}
						this.expect("]");
						return this.finalize(node, new Node.ArrayExpression(elements));
					};
					Parser.prototype.parsePropertyMethod = function(params) {
						this.context.isAssignmentTarget = false;
						this.context.isBindingElement = false;
						var previousStrict = this.context.strict;
						var previousAllowStrictDirective = this.context.allowStrictDirective;
						this.context.allowStrictDirective = params.simple;
						var body = this.isolateCoverGrammar(this.parseFunctionSourceElements);
						if (this.context.strict && params.firstRestricted) this.tolerateUnexpectedToken(params.firstRestricted, params.message);
						if (this.context.strict && params.stricted) this.tolerateUnexpectedToken(params.stricted, params.message);
						this.context.strict = previousStrict;
						this.context.allowStrictDirective = previousAllowStrictDirective;
						return body;
					};
					Parser.prototype.parsePropertyMethodFunction = function() {
						var isGenerator = false;
						var node = this.createNode();
						var previousAllowYield = this.context.allowYield;
						this.context.allowYield = true;
						var params = this.parseFormalParameters();
						var method = this.parsePropertyMethod(params);
						this.context.allowYield = previousAllowYield;
						return this.finalize(node, new Node.FunctionExpression(null, params.params, method, isGenerator));
					};
					Parser.prototype.parsePropertyMethodAsyncFunction = function() {
						var node = this.createNode();
						var previousAllowYield = this.context.allowYield;
						var previousAwait = this.context.await;
						this.context.allowYield = false;
						this.context.await = true;
						var params = this.parseFormalParameters();
						var method = this.parsePropertyMethod(params);
						this.context.allowYield = previousAllowYield;
						this.context.await = previousAwait;
						return this.finalize(node, new Node.AsyncFunctionExpression(null, params.params, method));
					};
					Parser.prototype.parseObjectPropertyKey = function() {
						var node = this.createNode();
						var token = this.nextToken();
						var key;
						switch (token.type) {
							case 8:
							case 6:
								if (this.context.strict && token.octal) this.tolerateUnexpectedToken(token, messages_1.Messages.StrictOctalLiteral);
								var raw = this.getTokenRaw(token);
								key = this.finalize(node, new Node.Literal(token.value, raw));
								break;
							case 3:
							case 1:
							case 5:
							case 4:
								key = this.finalize(node, new Node.Identifier(token.value));
								break;
							case 7:
								if (token.value === "[") {
									key = this.isolateCoverGrammar(this.parseAssignmentExpression);
									this.expect("]");
								} else key = this.throwUnexpectedToken(token);
								break;
							default: key = this.throwUnexpectedToken(token);
						}
						return key;
					};
					Parser.prototype.isPropertyKey = function(key, value) {
						return key.type === syntax_1.Syntax.Identifier && key.name === value || key.type === syntax_1.Syntax.Literal && key.value === value;
					};
					Parser.prototype.parseObjectProperty = function(hasProto) {
						var node = this.createNode();
						var token = this.lookahead;
						var kind;
						var key = null;
						var value = null;
						var computed = false;
						var method = false;
						var shorthand = false;
						var isAsync = false;
						if (token.type === 3) {
							var id = token.value;
							this.nextToken();
							computed = this.match("[");
							isAsync = !this.hasLineTerminator && id === "async" && !this.match(":") && !this.match("(") && !this.match("*") && !this.match(",");
							key = isAsync ? this.parseObjectPropertyKey() : this.finalize(node, new Node.Identifier(id));
						} else if (this.match("*")) this.nextToken();
						else {
							computed = this.match("[");
							key = this.parseObjectPropertyKey();
						}
						var lookaheadPropertyKey = this.qualifiedPropertyName(this.lookahead);
						if (token.type === 3 && !isAsync && token.value === "get" && lookaheadPropertyKey) {
							kind = "get";
							computed = this.match("[");
							key = this.parseObjectPropertyKey();
							this.context.allowYield = false;
							value = this.parseGetterMethod();
						} else if (token.type === 3 && !isAsync && token.value === "set" && lookaheadPropertyKey) {
							kind = "set";
							computed = this.match("[");
							key = this.parseObjectPropertyKey();
							value = this.parseSetterMethod();
						} else if (token.type === 7 && token.value === "*" && lookaheadPropertyKey) {
							kind = "init";
							computed = this.match("[");
							key = this.parseObjectPropertyKey();
							value = this.parseGeneratorMethod();
							method = true;
						} else {
							if (!key) this.throwUnexpectedToken(this.lookahead);
							kind = "init";
							if (this.match(":") && !isAsync) {
								if (!computed && this.isPropertyKey(key, "__proto__")) {
									if (hasProto.value) this.tolerateError(messages_1.Messages.DuplicateProtoProperty);
									hasProto.value = true;
								}
								this.nextToken();
								value = this.inheritCoverGrammar(this.parseAssignmentExpression);
							} else if (this.match("(")) {
								value = isAsync ? this.parsePropertyMethodAsyncFunction() : this.parsePropertyMethodFunction();
								method = true;
							} else if (token.type === 3) {
								var id = this.finalize(node, new Node.Identifier(token.value));
								if (this.match("=")) {
									this.context.firstCoverInitializedNameError = this.lookahead;
									this.nextToken();
									shorthand = true;
									var init = this.isolateCoverGrammar(this.parseAssignmentExpression);
									value = this.finalize(node, new Node.AssignmentPattern(id, init));
								} else {
									shorthand = true;
									value = id;
								}
							} else this.throwUnexpectedToken(this.nextToken());
						}
						return this.finalize(node, new Node.Property(kind, key, computed, value, method, shorthand));
					};
					Parser.prototype.parseObjectInitializer = function() {
						var node = this.createNode();
						this.expect("{");
						var properties = [];
						var hasProto = { value: false };
						while (!this.match("}")) {
							properties.push(this.parseObjectProperty(hasProto));
							if (!this.match("}")) this.expectCommaSeparator();
						}
						this.expect("}");
						return this.finalize(node, new Node.ObjectExpression(properties));
					};
					Parser.prototype.parseTemplateHead = function() {
						assert_1.assert(this.lookahead.head, "Template literal must start with a template head");
						var node = this.createNode();
						var token = this.nextToken();
						var raw = token.value;
						var cooked = token.cooked;
						return this.finalize(node, new Node.TemplateElement({
							raw,
							cooked
						}, token.tail));
					};
					Parser.prototype.parseTemplateElement = function() {
						if (this.lookahead.type !== 10) this.throwUnexpectedToken();
						var node = this.createNode();
						var token = this.nextToken();
						var raw = token.value;
						var cooked = token.cooked;
						return this.finalize(node, new Node.TemplateElement({
							raw,
							cooked
						}, token.tail));
					};
					Parser.prototype.parseTemplateLiteral = function() {
						var node = this.createNode();
						var expressions = [];
						var quasis = [];
						var quasi = this.parseTemplateHead();
						quasis.push(quasi);
						while (!quasi.tail) {
							expressions.push(this.parseExpression());
							quasi = this.parseTemplateElement();
							quasis.push(quasi);
						}
						return this.finalize(node, new Node.TemplateLiteral(quasis, expressions));
					};
					Parser.prototype.reinterpretExpressionAsPattern = function(expr) {
						switch (expr.type) {
							case syntax_1.Syntax.Identifier:
							case syntax_1.Syntax.MemberExpression:
							case syntax_1.Syntax.RestElement:
							case syntax_1.Syntax.AssignmentPattern: break;
							case syntax_1.Syntax.SpreadElement:
								expr.type = syntax_1.Syntax.RestElement;
								this.reinterpretExpressionAsPattern(expr.argument);
								break;
							case syntax_1.Syntax.ArrayExpression:
								expr.type = syntax_1.Syntax.ArrayPattern;
								for (var i = 0; i < expr.elements.length; i++) if (expr.elements[i] !== null) this.reinterpretExpressionAsPattern(expr.elements[i]);
								break;
							case syntax_1.Syntax.ObjectExpression:
								expr.type = syntax_1.Syntax.ObjectPattern;
								for (var i = 0; i < expr.properties.length; i++) this.reinterpretExpressionAsPattern(expr.properties[i].value);
								break;
							case syntax_1.Syntax.AssignmentExpression:
								expr.type = syntax_1.Syntax.AssignmentPattern;
								delete expr.operator;
								this.reinterpretExpressionAsPattern(expr.left);
								break;
							default: break;
						}
					};
					Parser.prototype.parseGroupExpression = function() {
						var expr;
						this.expect("(");
						if (this.match(")")) {
							this.nextToken();
							if (!this.match("=>")) this.expect("=>");
							expr = {
								type: ArrowParameterPlaceHolder,
								params: [],
								async: false
							};
						} else {
							var startToken = this.lookahead;
							var params = [];
							if (this.match("...")) {
								expr = this.parseRestElement(params);
								this.expect(")");
								if (!this.match("=>")) this.expect("=>");
								expr = {
									type: ArrowParameterPlaceHolder,
									params: [expr],
									async: false
								};
							} else {
								var arrow = false;
								this.context.isBindingElement = true;
								expr = this.inheritCoverGrammar(this.parseAssignmentExpression);
								if (this.match(",")) {
									var expressions = [];
									this.context.isAssignmentTarget = false;
									expressions.push(expr);
									while (this.lookahead.type !== 2) {
										if (!this.match(",")) break;
										this.nextToken();
										if (this.match(")")) {
											this.nextToken();
											for (var i = 0; i < expressions.length; i++) this.reinterpretExpressionAsPattern(expressions[i]);
											arrow = true;
											expr = {
												type: ArrowParameterPlaceHolder,
												params: expressions,
												async: false
											};
										} else if (this.match("...")) {
											if (!this.context.isBindingElement) this.throwUnexpectedToken(this.lookahead);
											expressions.push(this.parseRestElement(params));
											this.expect(")");
											if (!this.match("=>")) this.expect("=>");
											this.context.isBindingElement = false;
											for (var i = 0; i < expressions.length; i++) this.reinterpretExpressionAsPattern(expressions[i]);
											arrow = true;
											expr = {
												type: ArrowParameterPlaceHolder,
												params: expressions,
												async: false
											};
										} else expressions.push(this.inheritCoverGrammar(this.parseAssignmentExpression));
										if (arrow) break;
									}
									if (!arrow) expr = this.finalize(this.startNode(startToken), new Node.SequenceExpression(expressions));
								}
								if (!arrow) {
									this.expect(")");
									if (this.match("=>")) {
										if (expr.type === syntax_1.Syntax.Identifier && expr.name === "yield") {
											arrow = true;
											expr = {
												type: ArrowParameterPlaceHolder,
												params: [expr],
												async: false
											};
										}
										if (!arrow) {
											if (!this.context.isBindingElement) this.throwUnexpectedToken(this.lookahead);
											if (expr.type === syntax_1.Syntax.SequenceExpression) for (var i = 0; i < expr.expressions.length; i++) this.reinterpretExpressionAsPattern(expr.expressions[i]);
											else this.reinterpretExpressionAsPattern(expr);
											expr = {
												type: ArrowParameterPlaceHolder,
												params: expr.type === syntax_1.Syntax.SequenceExpression ? expr.expressions : [expr],
												async: false
											};
										}
									}
									this.context.isBindingElement = false;
								}
							}
						}
						return expr;
					};
					Parser.prototype.parseArguments = function() {
						this.expect("(");
						var args = [];
						if (!this.match(")")) while (true) {
							var expr = this.match("...") ? this.parseSpreadElement() : this.isolateCoverGrammar(this.parseAssignmentExpression);
							args.push(expr);
							if (this.match(")")) break;
							this.expectCommaSeparator();
							if (this.match(")")) break;
						}
						this.expect(")");
						return args;
					};
					Parser.prototype.isIdentifierName = function(token) {
						return token.type === 3 || token.type === 4 || token.type === 1 || token.type === 5;
					};
					Parser.prototype.parseIdentifierName = function() {
						var node = this.createNode();
						var token = this.nextToken();
						if (!this.isIdentifierName(token)) this.throwUnexpectedToken(token);
						return this.finalize(node, new Node.Identifier(token.value));
					};
					Parser.prototype.parseNewExpression = function() {
						var node = this.createNode();
						var id = this.parseIdentifierName();
						assert_1.assert(id.name === "new", "New expression must start with `new`");
						var expr;
						if (this.match(".")) {
							this.nextToken();
							if (this.lookahead.type === 3 && this.context.inFunctionBody && this.lookahead.value === "target") {
								var property = this.parseIdentifierName();
								expr = new Node.MetaProperty(id, property);
							} else this.throwUnexpectedToken(this.lookahead);
						} else {
							var callee = this.isolateCoverGrammar(this.parseLeftHandSideExpression);
							var args = this.match("(") ? this.parseArguments() : [];
							expr = new Node.NewExpression(callee, args);
							this.context.isAssignmentTarget = false;
							this.context.isBindingElement = false;
						}
						return this.finalize(node, expr);
					};
					Parser.prototype.parseAsyncArgument = function() {
						var arg = this.parseAssignmentExpression();
						this.context.firstCoverInitializedNameError = null;
						return arg;
					};
					Parser.prototype.parseAsyncArguments = function() {
						this.expect("(");
						var args = [];
						if (!this.match(")")) while (true) {
							var expr = this.match("...") ? this.parseSpreadElement() : this.isolateCoverGrammar(this.parseAsyncArgument);
							args.push(expr);
							if (this.match(")")) break;
							this.expectCommaSeparator();
							if (this.match(")")) break;
						}
						this.expect(")");
						return args;
					};
					Parser.prototype.parseLeftHandSideExpressionAllowCall = function() {
						var startToken = this.lookahead;
						var maybeAsync = this.matchContextualKeyword("async");
						var previousAllowIn = this.context.allowIn;
						this.context.allowIn = true;
						var expr;
						if (this.matchKeyword("super") && this.context.inFunctionBody) {
							expr = this.createNode();
							this.nextToken();
							expr = this.finalize(expr, new Node.Super());
							if (!this.match("(") && !this.match(".") && !this.match("[")) this.throwUnexpectedToken(this.lookahead);
						} else expr = this.inheritCoverGrammar(this.matchKeyword("new") ? this.parseNewExpression : this.parsePrimaryExpression);
						while (true) if (this.match(".")) {
							this.context.isBindingElement = false;
							this.context.isAssignmentTarget = true;
							this.expect(".");
							var property = this.parseIdentifierName();
							expr = this.finalize(this.startNode(startToken), new Node.StaticMemberExpression(expr, property));
						} else if (this.match("(")) {
							var asyncArrow = maybeAsync && startToken.lineNumber === this.lookahead.lineNumber;
							this.context.isBindingElement = false;
							this.context.isAssignmentTarget = false;
							var args = asyncArrow ? this.parseAsyncArguments() : this.parseArguments();
							expr = this.finalize(this.startNode(startToken), new Node.CallExpression(expr, args));
							if (asyncArrow && this.match("=>")) {
								for (var i = 0; i < args.length; ++i) this.reinterpretExpressionAsPattern(args[i]);
								expr = {
									type: ArrowParameterPlaceHolder,
									params: args,
									async: true
								};
							}
						} else if (this.match("[")) {
							this.context.isBindingElement = false;
							this.context.isAssignmentTarget = true;
							this.expect("[");
							var property = this.isolateCoverGrammar(this.parseExpression);
							this.expect("]");
							expr = this.finalize(this.startNode(startToken), new Node.ComputedMemberExpression(expr, property));
						} else if (this.lookahead.type === 10 && this.lookahead.head) {
							var quasi = this.parseTemplateLiteral();
							expr = this.finalize(this.startNode(startToken), new Node.TaggedTemplateExpression(expr, quasi));
						} else break;
						this.context.allowIn = previousAllowIn;
						return expr;
					};
					Parser.prototype.parseSuper = function() {
						var node = this.createNode();
						this.expectKeyword("super");
						if (!this.match("[") && !this.match(".")) this.throwUnexpectedToken(this.lookahead);
						return this.finalize(node, new Node.Super());
					};
					Parser.prototype.parseLeftHandSideExpression = function() {
						assert_1.assert(this.context.allowIn, "callee of new expression always allow in keyword.");
						var node = this.startNode(this.lookahead);
						var expr = this.matchKeyword("super") && this.context.inFunctionBody ? this.parseSuper() : this.inheritCoverGrammar(this.matchKeyword("new") ? this.parseNewExpression : this.parsePrimaryExpression);
						while (true) if (this.match("[")) {
							this.context.isBindingElement = false;
							this.context.isAssignmentTarget = true;
							this.expect("[");
							var property = this.isolateCoverGrammar(this.parseExpression);
							this.expect("]");
							expr = this.finalize(node, new Node.ComputedMemberExpression(expr, property));
						} else if (this.match(".")) {
							this.context.isBindingElement = false;
							this.context.isAssignmentTarget = true;
							this.expect(".");
							var property = this.parseIdentifierName();
							expr = this.finalize(node, new Node.StaticMemberExpression(expr, property));
						} else if (this.lookahead.type === 10 && this.lookahead.head) {
							var quasi = this.parseTemplateLiteral();
							expr = this.finalize(node, new Node.TaggedTemplateExpression(expr, quasi));
						} else break;
						return expr;
					};
					Parser.prototype.parseUpdateExpression = function() {
						var expr;
						var startToken = this.lookahead;
						if (this.match("++") || this.match("--")) {
							var node = this.startNode(startToken);
							var token = this.nextToken();
							expr = this.inheritCoverGrammar(this.parseUnaryExpression);
							if (this.context.strict && expr.type === syntax_1.Syntax.Identifier && this.scanner.isRestrictedWord(expr.name)) this.tolerateError(messages_1.Messages.StrictLHSPrefix);
							if (!this.context.isAssignmentTarget) this.tolerateError(messages_1.Messages.InvalidLHSInAssignment);
							var prefix = true;
							expr = this.finalize(node, new Node.UpdateExpression(token.value, expr, prefix));
							this.context.isAssignmentTarget = false;
							this.context.isBindingElement = false;
						} else {
							expr = this.inheritCoverGrammar(this.parseLeftHandSideExpressionAllowCall);
							if (!this.hasLineTerminator && this.lookahead.type === 7) {
								if (this.match("++") || this.match("--")) {
									if (this.context.strict && expr.type === syntax_1.Syntax.Identifier && this.scanner.isRestrictedWord(expr.name)) this.tolerateError(messages_1.Messages.StrictLHSPostfix);
									if (!this.context.isAssignmentTarget) this.tolerateError(messages_1.Messages.InvalidLHSInAssignment);
									this.context.isAssignmentTarget = false;
									this.context.isBindingElement = false;
									var operator = this.nextToken().value;
									var prefix = false;
									expr = this.finalize(this.startNode(startToken), new Node.UpdateExpression(operator, expr, prefix));
								}
							}
						}
						return expr;
					};
					Parser.prototype.parseAwaitExpression = function() {
						var node = this.createNode();
						this.nextToken();
						var argument = this.parseUnaryExpression();
						return this.finalize(node, new Node.AwaitExpression(argument));
					};
					Parser.prototype.parseUnaryExpression = function() {
						var expr;
						if (this.match("+") || this.match("-") || this.match("~") || this.match("!") || this.matchKeyword("delete") || this.matchKeyword("void") || this.matchKeyword("typeof")) {
							var node = this.startNode(this.lookahead);
							var token = this.nextToken();
							expr = this.inheritCoverGrammar(this.parseUnaryExpression);
							expr = this.finalize(node, new Node.UnaryExpression(token.value, expr));
							if (this.context.strict && expr.operator === "delete" && expr.argument.type === syntax_1.Syntax.Identifier) this.tolerateError(messages_1.Messages.StrictDelete);
							this.context.isAssignmentTarget = false;
							this.context.isBindingElement = false;
						} else if (this.context.await && this.matchContextualKeyword("await")) expr = this.parseAwaitExpression();
						else expr = this.parseUpdateExpression();
						return expr;
					};
					Parser.prototype.parseExponentiationExpression = function() {
						var startToken = this.lookahead;
						var expr = this.inheritCoverGrammar(this.parseUnaryExpression);
						if (expr.type !== syntax_1.Syntax.UnaryExpression && this.match("**")) {
							this.nextToken();
							this.context.isAssignmentTarget = false;
							this.context.isBindingElement = false;
							var left = expr;
							var right = this.isolateCoverGrammar(this.parseExponentiationExpression);
							expr = this.finalize(this.startNode(startToken), new Node.BinaryExpression("**", left, right));
						}
						return expr;
					};
					Parser.prototype.binaryPrecedence = function(token) {
						var op = token.value;
						var precedence;
						if (token.type === 7) precedence = this.operatorPrecedence[op] || 0;
						else if (token.type === 4) precedence = op === "instanceof" || this.context.allowIn && op === "in" ? 7 : 0;
						else precedence = 0;
						return precedence;
					};
					Parser.prototype.parseBinaryExpression = function() {
						var startToken = this.lookahead;
						var expr = this.inheritCoverGrammar(this.parseExponentiationExpression);
						var token = this.lookahead;
						var prec = this.binaryPrecedence(token);
						if (prec > 0) {
							this.nextToken();
							this.context.isAssignmentTarget = false;
							this.context.isBindingElement = false;
							var markers = [startToken, this.lookahead];
							var left = expr;
							var right = this.isolateCoverGrammar(this.parseExponentiationExpression);
							var stack = [
								left,
								token.value,
								right
							];
							var precedences = [prec];
							while (true) {
								prec = this.binaryPrecedence(this.lookahead);
								if (prec <= 0) break;
								while (stack.length > 2 && prec <= precedences[precedences.length - 1]) {
									right = stack.pop();
									var operator = stack.pop();
									precedences.pop();
									left = stack.pop();
									markers.pop();
									var node = this.startNode(markers[markers.length - 1]);
									stack.push(this.finalize(node, new Node.BinaryExpression(operator, left, right)));
								}
								stack.push(this.nextToken().value);
								precedences.push(prec);
								markers.push(this.lookahead);
								stack.push(this.isolateCoverGrammar(this.parseExponentiationExpression));
							}
							var i = stack.length - 1;
							expr = stack[i];
							var lastMarker = markers.pop();
							while (i > 1) {
								var marker = markers.pop();
								var lastLineStart = lastMarker && lastMarker.lineStart;
								var node = this.startNode(marker, lastLineStart);
								var operator = stack[i - 1];
								expr = this.finalize(node, new Node.BinaryExpression(operator, stack[i - 2], expr));
								i -= 2;
								lastMarker = marker;
							}
						}
						return expr;
					};
					Parser.prototype.parseConditionalExpression = function() {
						var startToken = this.lookahead;
						var expr = this.inheritCoverGrammar(this.parseBinaryExpression);
						if (this.match("?")) {
							this.nextToken();
							var previousAllowIn = this.context.allowIn;
							this.context.allowIn = true;
							var consequent = this.isolateCoverGrammar(this.parseAssignmentExpression);
							this.context.allowIn = previousAllowIn;
							this.expect(":");
							var alternate = this.isolateCoverGrammar(this.parseAssignmentExpression);
							expr = this.finalize(this.startNode(startToken), new Node.ConditionalExpression(expr, consequent, alternate));
							this.context.isAssignmentTarget = false;
							this.context.isBindingElement = false;
						}
						return expr;
					};
					Parser.prototype.checkPatternParam = function(options, param) {
						switch (param.type) {
							case syntax_1.Syntax.Identifier:
								this.validateParam(options, param, param.name);
								break;
							case syntax_1.Syntax.RestElement:
								this.checkPatternParam(options, param.argument);
								break;
							case syntax_1.Syntax.AssignmentPattern:
								this.checkPatternParam(options, param.left);
								break;
							case syntax_1.Syntax.ArrayPattern:
								for (var i = 0; i < param.elements.length; i++) if (param.elements[i] !== null) this.checkPatternParam(options, param.elements[i]);
								break;
							case syntax_1.Syntax.ObjectPattern:
								for (var i = 0; i < param.properties.length; i++) this.checkPatternParam(options, param.properties[i].value);
								break;
							default: break;
						}
						options.simple = options.simple && param instanceof Node.Identifier;
					};
					Parser.prototype.reinterpretAsCoverFormalsList = function(expr) {
						var params = [expr];
						var options;
						var asyncArrow = false;
						switch (expr.type) {
							case syntax_1.Syntax.Identifier: break;
							case ArrowParameterPlaceHolder:
								params = expr.params;
								asyncArrow = expr.async;
								break;
							default: return null;
						}
						options = {
							simple: true,
							paramSet: {}
						};
						for (var i = 0; i < params.length; ++i) {
							var param = params[i];
							if (param.type === syntax_1.Syntax.AssignmentPattern) {
								if (param.right.type === syntax_1.Syntax.YieldExpression) {
									if (param.right.argument) this.throwUnexpectedToken(this.lookahead);
									param.right.type = syntax_1.Syntax.Identifier;
									param.right.name = "yield";
									delete param.right.argument;
									delete param.right.delegate;
								}
							} else if (asyncArrow && param.type === syntax_1.Syntax.Identifier && param.name === "await") this.throwUnexpectedToken(this.lookahead);
							this.checkPatternParam(options, param);
							params[i] = param;
						}
						if (this.context.strict || !this.context.allowYield) for (var i = 0; i < params.length; ++i) {
							var param = params[i];
							if (param.type === syntax_1.Syntax.YieldExpression) this.throwUnexpectedToken(this.lookahead);
						}
						if (options.message === messages_1.Messages.StrictParamDupe) {
							var token = this.context.strict ? options.stricted : options.firstRestricted;
							this.throwUnexpectedToken(token, options.message);
						}
						return {
							simple: options.simple,
							params,
							stricted: options.stricted,
							firstRestricted: options.firstRestricted,
							message: options.message
						};
					};
					Parser.prototype.parseAssignmentExpression = function() {
						var expr;
						if (!this.context.allowYield && this.matchKeyword("yield")) expr = this.parseYieldExpression();
						else {
							var startToken = this.lookahead;
							var token = startToken;
							expr = this.parseConditionalExpression();
							if (token.type === 3 && token.lineNumber === this.lookahead.lineNumber && token.value === "async") {
								if (this.lookahead.type === 3 || this.matchKeyword("yield")) {
									var arg = this.parsePrimaryExpression();
									this.reinterpretExpressionAsPattern(arg);
									expr = {
										type: ArrowParameterPlaceHolder,
										params: [arg],
										async: true
									};
								}
							}
							if (expr.type === ArrowParameterPlaceHolder || this.match("=>")) {
								this.context.isAssignmentTarget = false;
								this.context.isBindingElement = false;
								var isAsync = expr.async;
								var list = this.reinterpretAsCoverFormalsList(expr);
								if (list) {
									if (this.hasLineTerminator) this.tolerateUnexpectedToken(this.lookahead);
									this.context.firstCoverInitializedNameError = null;
									var previousStrict = this.context.strict;
									var previousAllowStrictDirective = this.context.allowStrictDirective;
									this.context.allowStrictDirective = list.simple;
									var previousAllowYield = this.context.allowYield;
									var previousAwait = this.context.await;
									this.context.allowYield = true;
									this.context.await = isAsync;
									var node = this.startNode(startToken);
									this.expect("=>");
									var body = void 0;
									if (this.match("{")) {
										var previousAllowIn = this.context.allowIn;
										this.context.allowIn = true;
										body = this.parseFunctionSourceElements();
										this.context.allowIn = previousAllowIn;
									} else body = this.isolateCoverGrammar(this.parseAssignmentExpression);
									var expression = body.type !== syntax_1.Syntax.BlockStatement;
									if (this.context.strict && list.firstRestricted) this.throwUnexpectedToken(list.firstRestricted, list.message);
									if (this.context.strict && list.stricted) this.tolerateUnexpectedToken(list.stricted, list.message);
									expr = isAsync ? this.finalize(node, new Node.AsyncArrowFunctionExpression(list.params, body, expression)) : this.finalize(node, new Node.ArrowFunctionExpression(list.params, body, expression));
									this.context.strict = previousStrict;
									this.context.allowStrictDirective = previousAllowStrictDirective;
									this.context.allowYield = previousAllowYield;
									this.context.await = previousAwait;
								}
							} else if (this.matchAssign()) {
								if (!this.context.isAssignmentTarget) this.tolerateError(messages_1.Messages.InvalidLHSInAssignment);
								if (this.context.strict && expr.type === syntax_1.Syntax.Identifier) {
									var id = expr;
									if (this.scanner.isRestrictedWord(id.name)) this.tolerateUnexpectedToken(token, messages_1.Messages.StrictLHSAssignment);
									if (this.scanner.isStrictModeReservedWord(id.name)) this.tolerateUnexpectedToken(token, messages_1.Messages.StrictReservedWord);
								}
								if (!this.match("=")) {
									this.context.isAssignmentTarget = false;
									this.context.isBindingElement = false;
								} else this.reinterpretExpressionAsPattern(expr);
								token = this.nextToken();
								var operator = token.value;
								var right = this.isolateCoverGrammar(this.parseAssignmentExpression);
								expr = this.finalize(this.startNode(startToken), new Node.AssignmentExpression(operator, expr, right));
								this.context.firstCoverInitializedNameError = null;
							}
						}
						return expr;
					};
					Parser.prototype.parseExpression = function() {
						var startToken = this.lookahead;
						var expr = this.isolateCoverGrammar(this.parseAssignmentExpression);
						if (this.match(",")) {
							var expressions = [];
							expressions.push(expr);
							while (this.lookahead.type !== 2) {
								if (!this.match(",")) break;
								this.nextToken();
								expressions.push(this.isolateCoverGrammar(this.parseAssignmentExpression));
							}
							expr = this.finalize(this.startNode(startToken), new Node.SequenceExpression(expressions));
						}
						return expr;
					};
					Parser.prototype.parseStatementListItem = function() {
						var statement;
						this.context.isAssignmentTarget = true;
						this.context.isBindingElement = true;
						if (this.lookahead.type === 4) switch (this.lookahead.value) {
							case "export":
								if (!this.context.isModule) this.tolerateUnexpectedToken(this.lookahead, messages_1.Messages.IllegalExportDeclaration);
								statement = this.parseExportDeclaration();
								break;
							case "import":
								if (!this.context.isModule) this.tolerateUnexpectedToken(this.lookahead, messages_1.Messages.IllegalImportDeclaration);
								statement = this.parseImportDeclaration();
								break;
							case "const":
								statement = this.parseLexicalDeclaration({ inFor: false });
								break;
							case "function":
								statement = this.parseFunctionDeclaration();
								break;
							case "class":
								statement = this.parseClassDeclaration();
								break;
							case "let":
								statement = this.isLexicalDeclaration() ? this.parseLexicalDeclaration({ inFor: false }) : this.parseStatement();
								break;
							default:
								statement = this.parseStatement();
								break;
						}
						else statement = this.parseStatement();
						return statement;
					};
					Parser.prototype.parseBlock = function() {
						var node = this.createNode();
						this.expect("{");
						var block = [];
						while (true) {
							if (this.match("}")) break;
							block.push(this.parseStatementListItem());
						}
						this.expect("}");
						return this.finalize(node, new Node.BlockStatement(block));
					};
					Parser.prototype.parseLexicalBinding = function(kind, options) {
						var node = this.createNode();
						var id = this.parsePattern([], kind);
						if (this.context.strict && id.type === syntax_1.Syntax.Identifier) {
							if (this.scanner.isRestrictedWord(id.name)) this.tolerateError(messages_1.Messages.StrictVarName);
						}
						var init = null;
						if (kind === "const") {
							if (!this.matchKeyword("in") && !this.matchContextualKeyword("of")) if (this.match("=")) {
								this.nextToken();
								init = this.isolateCoverGrammar(this.parseAssignmentExpression);
							} else this.throwError(messages_1.Messages.DeclarationMissingInitializer, "const");
						} else if (!options.inFor && id.type !== syntax_1.Syntax.Identifier || this.match("=")) {
							this.expect("=");
							init = this.isolateCoverGrammar(this.parseAssignmentExpression);
						}
						return this.finalize(node, new Node.VariableDeclarator(id, init));
					};
					Parser.prototype.parseBindingList = function(kind, options) {
						var list = [this.parseLexicalBinding(kind, options)];
						while (this.match(",")) {
							this.nextToken();
							list.push(this.parseLexicalBinding(kind, options));
						}
						return list;
					};
					Parser.prototype.isLexicalDeclaration = function() {
						var state = this.scanner.saveState();
						this.scanner.scanComments();
						var next = this.scanner.lex();
						this.scanner.restoreState(state);
						return next.type === 3 || next.type === 7 && next.value === "[" || next.type === 7 && next.value === "{" || next.type === 4 && next.value === "let" || next.type === 4 && next.value === "yield";
					};
					Parser.prototype.parseLexicalDeclaration = function(options) {
						var node = this.createNode();
						var kind = this.nextToken().value;
						assert_1.assert(kind === "let" || kind === "const", "Lexical declaration must be either let or const");
						var declarations = this.parseBindingList(kind, options);
						this.consumeSemicolon();
						return this.finalize(node, new Node.VariableDeclaration(declarations, kind));
					};
					Parser.prototype.parseBindingRestElement = function(params, kind) {
						var node = this.createNode();
						this.expect("...");
						var arg = this.parsePattern(params, kind);
						return this.finalize(node, new Node.RestElement(arg));
					};
					Parser.prototype.parseArrayPattern = function(params, kind) {
						var node = this.createNode();
						this.expect("[");
						var elements = [];
						while (!this.match("]")) if (this.match(",")) {
							this.nextToken();
							elements.push(null);
						} else {
							if (this.match("...")) {
								elements.push(this.parseBindingRestElement(params, kind));
								break;
							} else elements.push(this.parsePatternWithDefault(params, kind));
							if (!this.match("]")) this.expect(",");
						}
						this.expect("]");
						return this.finalize(node, new Node.ArrayPattern(elements));
					};
					Parser.prototype.parsePropertyPattern = function(params, kind) {
						var node = this.createNode();
						var computed = false;
						var shorthand = false;
						var method = false;
						var key;
						var value;
						if (this.lookahead.type === 3) {
							var keyToken = this.lookahead;
							key = this.parseVariableIdentifier();
							var init = this.finalize(node, new Node.Identifier(keyToken.value));
							if (this.match("=")) {
								params.push(keyToken);
								shorthand = true;
								this.nextToken();
								var expr = this.parseAssignmentExpression();
								value = this.finalize(this.startNode(keyToken), new Node.AssignmentPattern(init, expr));
							} else if (!this.match(":")) {
								params.push(keyToken);
								shorthand = true;
								value = init;
							} else {
								this.expect(":");
								value = this.parsePatternWithDefault(params, kind);
							}
						} else {
							computed = this.match("[");
							key = this.parseObjectPropertyKey();
							this.expect(":");
							value = this.parsePatternWithDefault(params, kind);
						}
						return this.finalize(node, new Node.Property("init", key, computed, value, method, shorthand));
					};
					Parser.prototype.parseObjectPattern = function(params, kind) {
						var node = this.createNode();
						var properties = [];
						this.expect("{");
						while (!this.match("}")) {
							properties.push(this.parsePropertyPattern(params, kind));
							if (!this.match("}")) this.expect(",");
						}
						this.expect("}");
						return this.finalize(node, new Node.ObjectPattern(properties));
					};
					Parser.prototype.parsePattern = function(params, kind) {
						var pattern;
						if (this.match("[")) pattern = this.parseArrayPattern(params, kind);
						else if (this.match("{")) pattern = this.parseObjectPattern(params, kind);
						else {
							if (this.matchKeyword("let") && (kind === "const" || kind === "let")) this.tolerateUnexpectedToken(this.lookahead, messages_1.Messages.LetInLexicalBinding);
							params.push(this.lookahead);
							pattern = this.parseVariableIdentifier(kind);
						}
						return pattern;
					};
					Parser.prototype.parsePatternWithDefault = function(params, kind) {
						var startToken = this.lookahead;
						var pattern = this.parsePattern(params, kind);
						if (this.match("=")) {
							this.nextToken();
							var previousAllowYield = this.context.allowYield;
							this.context.allowYield = true;
							var right = this.isolateCoverGrammar(this.parseAssignmentExpression);
							this.context.allowYield = previousAllowYield;
							pattern = this.finalize(this.startNode(startToken), new Node.AssignmentPattern(pattern, right));
						}
						return pattern;
					};
					Parser.prototype.parseVariableIdentifier = function(kind) {
						var node = this.createNode();
						var token = this.nextToken();
						if (token.type === 4 && token.value === "yield") {
							if (this.context.strict) this.tolerateUnexpectedToken(token, messages_1.Messages.StrictReservedWord);
							else if (!this.context.allowYield) this.throwUnexpectedToken(token);
						} else if (token.type !== 3) {
							if (this.context.strict && token.type === 4 && this.scanner.isStrictModeReservedWord(token.value)) this.tolerateUnexpectedToken(token, messages_1.Messages.StrictReservedWord);
							else if (this.context.strict || token.value !== "let" || kind !== "var") this.throwUnexpectedToken(token);
						} else if ((this.context.isModule || this.context.await) && token.type === 3 && token.value === "await") this.tolerateUnexpectedToken(token);
						return this.finalize(node, new Node.Identifier(token.value));
					};
					Parser.prototype.parseVariableDeclaration = function(options) {
						var node = this.createNode();
						var id = this.parsePattern([], "var");
						if (this.context.strict && id.type === syntax_1.Syntax.Identifier) {
							if (this.scanner.isRestrictedWord(id.name)) this.tolerateError(messages_1.Messages.StrictVarName);
						}
						var init = null;
						if (this.match("=")) {
							this.nextToken();
							init = this.isolateCoverGrammar(this.parseAssignmentExpression);
						} else if (id.type !== syntax_1.Syntax.Identifier && !options.inFor) this.expect("=");
						return this.finalize(node, new Node.VariableDeclarator(id, init));
					};
					Parser.prototype.parseVariableDeclarationList = function(options) {
						var opt = { inFor: options.inFor };
						var list = [];
						list.push(this.parseVariableDeclaration(opt));
						while (this.match(",")) {
							this.nextToken();
							list.push(this.parseVariableDeclaration(opt));
						}
						return list;
					};
					Parser.prototype.parseVariableStatement = function() {
						var node = this.createNode();
						this.expectKeyword("var");
						var declarations = this.parseVariableDeclarationList({ inFor: false });
						this.consumeSemicolon();
						return this.finalize(node, new Node.VariableDeclaration(declarations, "var"));
					};
					Parser.prototype.parseEmptyStatement = function() {
						var node = this.createNode();
						this.expect(";");
						return this.finalize(node, new Node.EmptyStatement());
					};
					Parser.prototype.parseExpressionStatement = function() {
						var node = this.createNode();
						var expr = this.parseExpression();
						this.consumeSemicolon();
						return this.finalize(node, new Node.ExpressionStatement(expr));
					};
					Parser.prototype.parseIfClause = function() {
						if (this.context.strict && this.matchKeyword("function")) this.tolerateError(messages_1.Messages.StrictFunction);
						return this.parseStatement();
					};
					Parser.prototype.parseIfStatement = function() {
						var node = this.createNode();
						var consequent;
						var alternate = null;
						this.expectKeyword("if");
						this.expect("(");
						var test = this.parseExpression();
						if (!this.match(")") && this.config.tolerant) {
							this.tolerateUnexpectedToken(this.nextToken());
							consequent = this.finalize(this.createNode(), new Node.EmptyStatement());
						} else {
							this.expect(")");
							consequent = this.parseIfClause();
							if (this.matchKeyword("else")) {
								this.nextToken();
								alternate = this.parseIfClause();
							}
						}
						return this.finalize(node, new Node.IfStatement(test, consequent, alternate));
					};
					Parser.prototype.parseDoWhileStatement = function() {
						var node = this.createNode();
						this.expectKeyword("do");
						var previousInIteration = this.context.inIteration;
						this.context.inIteration = true;
						var body = this.parseStatement();
						this.context.inIteration = previousInIteration;
						this.expectKeyword("while");
						this.expect("(");
						var test = this.parseExpression();
						if (!this.match(")") && this.config.tolerant) this.tolerateUnexpectedToken(this.nextToken());
						else {
							this.expect(")");
							if (this.match(";")) this.nextToken();
						}
						return this.finalize(node, new Node.DoWhileStatement(body, test));
					};
					Parser.prototype.parseWhileStatement = function() {
						var node = this.createNode();
						var body;
						this.expectKeyword("while");
						this.expect("(");
						var test = this.parseExpression();
						if (!this.match(")") && this.config.tolerant) {
							this.tolerateUnexpectedToken(this.nextToken());
							body = this.finalize(this.createNode(), new Node.EmptyStatement());
						} else {
							this.expect(")");
							var previousInIteration = this.context.inIteration;
							this.context.inIteration = true;
							body = this.parseStatement();
							this.context.inIteration = previousInIteration;
						}
						return this.finalize(node, new Node.WhileStatement(test, body));
					};
					Parser.prototype.parseForStatement = function() {
						var init = null;
						var test = null;
						var update = null;
						var forIn = true;
						var left, right;
						var node = this.createNode();
						this.expectKeyword("for");
						this.expect("(");
						if (this.match(";")) this.nextToken();
						else if (this.matchKeyword("var")) {
							init = this.createNode();
							this.nextToken();
							var previousAllowIn = this.context.allowIn;
							this.context.allowIn = false;
							var declarations = this.parseVariableDeclarationList({ inFor: true });
							this.context.allowIn = previousAllowIn;
							if (declarations.length === 1 && this.matchKeyword("in")) {
								var decl = declarations[0];
								if (decl.init && (decl.id.type === syntax_1.Syntax.ArrayPattern || decl.id.type === syntax_1.Syntax.ObjectPattern || this.context.strict)) this.tolerateError(messages_1.Messages.ForInOfLoopInitializer, "for-in");
								init = this.finalize(init, new Node.VariableDeclaration(declarations, "var"));
								this.nextToken();
								left = init;
								right = this.parseExpression();
								init = null;
							} else if (declarations.length === 1 && declarations[0].init === null && this.matchContextualKeyword("of")) {
								init = this.finalize(init, new Node.VariableDeclaration(declarations, "var"));
								this.nextToken();
								left = init;
								right = this.parseAssignmentExpression();
								init = null;
								forIn = false;
							} else {
								init = this.finalize(init, new Node.VariableDeclaration(declarations, "var"));
								this.expect(";");
							}
						} else if (this.matchKeyword("const") || this.matchKeyword("let")) {
							init = this.createNode();
							var kind = this.nextToken().value;
							if (!this.context.strict && this.lookahead.value === "in") {
								init = this.finalize(init, new Node.Identifier(kind));
								this.nextToken();
								left = init;
								right = this.parseExpression();
								init = null;
							} else {
								var previousAllowIn = this.context.allowIn;
								this.context.allowIn = false;
								var declarations = this.parseBindingList(kind, { inFor: true });
								this.context.allowIn = previousAllowIn;
								if (declarations.length === 1 && declarations[0].init === null && this.matchKeyword("in")) {
									init = this.finalize(init, new Node.VariableDeclaration(declarations, kind));
									this.nextToken();
									left = init;
									right = this.parseExpression();
									init = null;
								} else if (declarations.length === 1 && declarations[0].init === null && this.matchContextualKeyword("of")) {
									init = this.finalize(init, new Node.VariableDeclaration(declarations, kind));
									this.nextToken();
									left = init;
									right = this.parseAssignmentExpression();
									init = null;
									forIn = false;
								} else {
									this.consumeSemicolon();
									init = this.finalize(init, new Node.VariableDeclaration(declarations, kind));
								}
							}
						} else {
							var initStartToken = this.lookahead;
							var previousAllowIn = this.context.allowIn;
							this.context.allowIn = false;
							init = this.inheritCoverGrammar(this.parseAssignmentExpression);
							this.context.allowIn = previousAllowIn;
							if (this.matchKeyword("in")) {
								if (!this.context.isAssignmentTarget || init.type === syntax_1.Syntax.AssignmentExpression) this.tolerateError(messages_1.Messages.InvalidLHSInForIn);
								this.nextToken();
								this.reinterpretExpressionAsPattern(init);
								left = init;
								right = this.parseExpression();
								init = null;
							} else if (this.matchContextualKeyword("of")) {
								if (!this.context.isAssignmentTarget || init.type === syntax_1.Syntax.AssignmentExpression) this.tolerateError(messages_1.Messages.InvalidLHSInForLoop);
								this.nextToken();
								this.reinterpretExpressionAsPattern(init);
								left = init;
								right = this.parseAssignmentExpression();
								init = null;
								forIn = false;
							} else {
								if (this.match(",")) {
									var initSeq = [init];
									while (this.match(",")) {
										this.nextToken();
										initSeq.push(this.isolateCoverGrammar(this.parseAssignmentExpression));
									}
									init = this.finalize(this.startNode(initStartToken), new Node.SequenceExpression(initSeq));
								}
								this.expect(";");
							}
						}
						if (typeof left === "undefined") {
							if (!this.match(";")) test = this.parseExpression();
							this.expect(";");
							if (!this.match(")")) update = this.parseExpression();
						}
						var body;
						if (!this.match(")") && this.config.tolerant) {
							this.tolerateUnexpectedToken(this.nextToken());
							body = this.finalize(this.createNode(), new Node.EmptyStatement());
						} else {
							this.expect(")");
							var previousInIteration = this.context.inIteration;
							this.context.inIteration = true;
							body = this.isolateCoverGrammar(this.parseStatement);
							this.context.inIteration = previousInIteration;
						}
						return typeof left === "undefined" ? this.finalize(node, new Node.ForStatement(init, test, update, body)) : forIn ? this.finalize(node, new Node.ForInStatement(left, right, body)) : this.finalize(node, new Node.ForOfStatement(left, right, body));
					};
					Parser.prototype.parseContinueStatement = function() {
						var node = this.createNode();
						this.expectKeyword("continue");
						var label = null;
						if (this.lookahead.type === 3 && !this.hasLineTerminator) {
							var id = this.parseVariableIdentifier();
							label = id;
							var key = "$" + id.name;
							if (!Object.prototype.hasOwnProperty.call(this.context.labelSet, key)) this.throwError(messages_1.Messages.UnknownLabel, id.name);
						}
						this.consumeSemicolon();
						if (label === null && !this.context.inIteration) this.throwError(messages_1.Messages.IllegalContinue);
						return this.finalize(node, new Node.ContinueStatement(label));
					};
					Parser.prototype.parseBreakStatement = function() {
						var node = this.createNode();
						this.expectKeyword("break");
						var label = null;
						if (this.lookahead.type === 3 && !this.hasLineTerminator) {
							var id = this.parseVariableIdentifier();
							var key = "$" + id.name;
							if (!Object.prototype.hasOwnProperty.call(this.context.labelSet, key)) this.throwError(messages_1.Messages.UnknownLabel, id.name);
							label = id;
						}
						this.consumeSemicolon();
						if (label === null && !this.context.inIteration && !this.context.inSwitch) this.throwError(messages_1.Messages.IllegalBreak);
						return this.finalize(node, new Node.BreakStatement(label));
					};
					Parser.prototype.parseReturnStatement = function() {
						if (!this.context.inFunctionBody) this.tolerateError(messages_1.Messages.IllegalReturn);
						var node = this.createNode();
						this.expectKeyword("return");
						var argument = !this.match(";") && !this.match("}") && !this.hasLineTerminator && this.lookahead.type !== 2 || this.lookahead.type === 8 || this.lookahead.type === 10 ? this.parseExpression() : null;
						this.consumeSemicolon();
						return this.finalize(node, new Node.ReturnStatement(argument));
					};
					Parser.prototype.parseWithStatement = function() {
						if (this.context.strict) this.tolerateError(messages_1.Messages.StrictModeWith);
						var node = this.createNode();
						var body;
						this.expectKeyword("with");
						this.expect("(");
						var object = this.parseExpression();
						if (!this.match(")") && this.config.tolerant) {
							this.tolerateUnexpectedToken(this.nextToken());
							body = this.finalize(this.createNode(), new Node.EmptyStatement());
						} else {
							this.expect(")");
							body = this.parseStatement();
						}
						return this.finalize(node, new Node.WithStatement(object, body));
					};
					Parser.prototype.parseSwitchCase = function() {
						var node = this.createNode();
						var test;
						if (this.matchKeyword("default")) {
							this.nextToken();
							test = null;
						} else {
							this.expectKeyword("case");
							test = this.parseExpression();
						}
						this.expect(":");
						var consequent = [];
						while (true) {
							if (this.match("}") || this.matchKeyword("default") || this.matchKeyword("case")) break;
							consequent.push(this.parseStatementListItem());
						}
						return this.finalize(node, new Node.SwitchCase(test, consequent));
					};
					Parser.prototype.parseSwitchStatement = function() {
						var node = this.createNode();
						this.expectKeyword("switch");
						this.expect("(");
						var discriminant = this.parseExpression();
						this.expect(")");
						var previousInSwitch = this.context.inSwitch;
						this.context.inSwitch = true;
						var cases = [];
						var defaultFound = false;
						this.expect("{");
						while (true) {
							if (this.match("}")) break;
							var clause = this.parseSwitchCase();
							if (clause.test === null) {
								if (defaultFound) this.throwError(messages_1.Messages.MultipleDefaultsInSwitch);
								defaultFound = true;
							}
							cases.push(clause);
						}
						this.expect("}");
						this.context.inSwitch = previousInSwitch;
						return this.finalize(node, new Node.SwitchStatement(discriminant, cases));
					};
					Parser.prototype.parseLabelledStatement = function() {
						var node = this.createNode();
						var expr = this.parseExpression();
						var statement;
						if (expr.type === syntax_1.Syntax.Identifier && this.match(":")) {
							this.nextToken();
							var id = expr;
							var key = "$" + id.name;
							if (Object.prototype.hasOwnProperty.call(this.context.labelSet, key)) this.throwError(messages_1.Messages.Redeclaration, "Label", id.name);
							this.context.labelSet[key] = true;
							var body = void 0;
							if (this.matchKeyword("class")) {
								this.tolerateUnexpectedToken(this.lookahead);
								body = this.parseClassDeclaration();
							} else if (this.matchKeyword("function")) {
								var token = this.lookahead;
								var declaration = this.parseFunctionDeclaration();
								if (this.context.strict) this.tolerateUnexpectedToken(token, messages_1.Messages.StrictFunction);
								else if (declaration.generator) this.tolerateUnexpectedToken(token, messages_1.Messages.GeneratorInLegacyContext);
								body = declaration;
							} else body = this.parseStatement();
							delete this.context.labelSet[key];
							statement = new Node.LabeledStatement(id, body);
						} else {
							this.consumeSemicolon();
							statement = new Node.ExpressionStatement(expr);
						}
						return this.finalize(node, statement);
					};
					Parser.prototype.parseThrowStatement = function() {
						var node = this.createNode();
						this.expectKeyword("throw");
						if (this.hasLineTerminator) this.throwError(messages_1.Messages.NewlineAfterThrow);
						var argument = this.parseExpression();
						this.consumeSemicolon();
						return this.finalize(node, new Node.ThrowStatement(argument));
					};
					Parser.prototype.parseCatchClause = function() {
						var node = this.createNode();
						this.expectKeyword("catch");
						this.expect("(");
						if (this.match(")")) this.throwUnexpectedToken(this.lookahead);
						var params = [];
						var param = this.parsePattern(params);
						var paramMap = {};
						for (var i = 0; i < params.length; i++) {
							var key = "$" + params[i].value;
							if (Object.prototype.hasOwnProperty.call(paramMap, key)) this.tolerateError(messages_1.Messages.DuplicateBinding, params[i].value);
							paramMap[key] = true;
						}
						if (this.context.strict && param.type === syntax_1.Syntax.Identifier) {
							if (this.scanner.isRestrictedWord(param.name)) this.tolerateError(messages_1.Messages.StrictCatchVariable);
						}
						this.expect(")");
						var body = this.parseBlock();
						return this.finalize(node, new Node.CatchClause(param, body));
					};
					Parser.prototype.parseFinallyClause = function() {
						this.expectKeyword("finally");
						return this.parseBlock();
					};
					Parser.prototype.parseTryStatement = function() {
						var node = this.createNode();
						this.expectKeyword("try");
						var block = this.parseBlock();
						var handler = this.matchKeyword("catch") ? this.parseCatchClause() : null;
						var finalizer = this.matchKeyword("finally") ? this.parseFinallyClause() : null;
						if (!handler && !finalizer) this.throwError(messages_1.Messages.NoCatchOrFinally);
						return this.finalize(node, new Node.TryStatement(block, handler, finalizer));
					};
					Parser.prototype.parseDebuggerStatement = function() {
						var node = this.createNode();
						this.expectKeyword("debugger");
						this.consumeSemicolon();
						return this.finalize(node, new Node.DebuggerStatement());
					};
					Parser.prototype.parseStatement = function() {
						var statement;
						switch (this.lookahead.type) {
							case 1:
							case 5:
							case 6:
							case 8:
							case 10:
							case 9:
								statement = this.parseExpressionStatement();
								break;
							case 7:
								var value = this.lookahead.value;
								if (value === "{") statement = this.parseBlock();
								else if (value === "(") statement = this.parseExpressionStatement();
								else if (value === ";") statement = this.parseEmptyStatement();
								else statement = this.parseExpressionStatement();
								break;
							case 3:
								statement = this.matchAsyncFunction() ? this.parseFunctionDeclaration() : this.parseLabelledStatement();
								break;
							case 4:
								switch (this.lookahead.value) {
									case "break":
										statement = this.parseBreakStatement();
										break;
									case "continue":
										statement = this.parseContinueStatement();
										break;
									case "debugger":
										statement = this.parseDebuggerStatement();
										break;
									case "do":
										statement = this.parseDoWhileStatement();
										break;
									case "for":
										statement = this.parseForStatement();
										break;
									case "function":
										statement = this.parseFunctionDeclaration();
										break;
									case "if":
										statement = this.parseIfStatement();
										break;
									case "return":
										statement = this.parseReturnStatement();
										break;
									case "switch":
										statement = this.parseSwitchStatement();
										break;
									case "throw":
										statement = this.parseThrowStatement();
										break;
									case "try":
										statement = this.parseTryStatement();
										break;
									case "var":
										statement = this.parseVariableStatement();
										break;
									case "while":
										statement = this.parseWhileStatement();
										break;
									case "with":
										statement = this.parseWithStatement();
										break;
									default:
										statement = this.parseExpressionStatement();
										break;
								}
								break;
							default: statement = this.throwUnexpectedToken(this.lookahead);
						}
						return statement;
					};
					Parser.prototype.parseFunctionSourceElements = function() {
						var node = this.createNode();
						this.expect("{");
						var body = this.parseDirectivePrologues();
						var previousLabelSet = this.context.labelSet;
						var previousInIteration = this.context.inIteration;
						var previousInSwitch = this.context.inSwitch;
						var previousInFunctionBody = this.context.inFunctionBody;
						this.context.labelSet = {};
						this.context.inIteration = false;
						this.context.inSwitch = false;
						this.context.inFunctionBody = true;
						while (this.lookahead.type !== 2) {
							if (this.match("}")) break;
							body.push(this.parseStatementListItem());
						}
						this.expect("}");
						this.context.labelSet = previousLabelSet;
						this.context.inIteration = previousInIteration;
						this.context.inSwitch = previousInSwitch;
						this.context.inFunctionBody = previousInFunctionBody;
						return this.finalize(node, new Node.BlockStatement(body));
					};
					Parser.prototype.validateParam = function(options, param, name) {
						var key = "$" + name;
						if (this.context.strict) {
							if (this.scanner.isRestrictedWord(name)) {
								options.stricted = param;
								options.message = messages_1.Messages.StrictParamName;
							}
							if (Object.prototype.hasOwnProperty.call(options.paramSet, key)) {
								options.stricted = param;
								options.message = messages_1.Messages.StrictParamDupe;
							}
						} else if (!options.firstRestricted) {
							if (this.scanner.isRestrictedWord(name)) {
								options.firstRestricted = param;
								options.message = messages_1.Messages.StrictParamName;
							} else if (this.scanner.isStrictModeReservedWord(name)) {
								options.firstRestricted = param;
								options.message = messages_1.Messages.StrictReservedWord;
							} else if (Object.prototype.hasOwnProperty.call(options.paramSet, key)) {
								options.stricted = param;
								options.message = messages_1.Messages.StrictParamDupe;
							}
						}
						/* istanbul ignore next */
						if (typeof Object.defineProperty === "function") Object.defineProperty(options.paramSet, key, {
							value: true,
							enumerable: true,
							writable: true,
							configurable: true
						});
						else options.paramSet[key] = true;
					};
					Parser.prototype.parseRestElement = function(params) {
						var node = this.createNode();
						this.expect("...");
						var arg = this.parsePattern(params);
						if (this.match("=")) this.throwError(messages_1.Messages.DefaultRestParameter);
						if (!this.match(")")) this.throwError(messages_1.Messages.ParameterAfterRestParameter);
						return this.finalize(node, new Node.RestElement(arg));
					};
					Parser.prototype.parseFormalParameter = function(options) {
						var params = [];
						var param = this.match("...") ? this.parseRestElement(params) : this.parsePatternWithDefault(params);
						for (var i = 0; i < params.length; i++) this.validateParam(options, params[i], params[i].value);
						options.simple = options.simple && param instanceof Node.Identifier;
						options.params.push(param);
					};
					Parser.prototype.parseFormalParameters = function(firstRestricted) {
						var options = {
							simple: true,
							params: [],
							firstRestricted
						};
						this.expect("(");
						if (!this.match(")")) {
							options.paramSet = {};
							while (this.lookahead.type !== 2) {
								this.parseFormalParameter(options);
								if (this.match(")")) break;
								this.expect(",");
								if (this.match(")")) break;
							}
						}
						this.expect(")");
						return {
							simple: options.simple,
							params: options.params,
							stricted: options.stricted,
							firstRestricted: options.firstRestricted,
							message: options.message
						};
					};
					Parser.prototype.matchAsyncFunction = function() {
						var match = this.matchContextualKeyword("async");
						if (match) {
							var state = this.scanner.saveState();
							this.scanner.scanComments();
							var next = this.scanner.lex();
							this.scanner.restoreState(state);
							match = state.lineNumber === next.lineNumber && next.type === 4 && next.value === "function";
						}
						return match;
					};
					Parser.prototype.parseFunctionDeclaration = function(identifierIsOptional) {
						var node = this.createNode();
						var isAsync = this.matchContextualKeyword("async");
						if (isAsync) this.nextToken();
						this.expectKeyword("function");
						var isGenerator = isAsync ? false : this.match("*");
						if (isGenerator) this.nextToken();
						var message;
						var id = null;
						var firstRestricted = null;
						if (!identifierIsOptional || !this.match("(")) {
							var token = this.lookahead;
							id = this.parseVariableIdentifier();
							if (this.context.strict) {
								if (this.scanner.isRestrictedWord(token.value)) this.tolerateUnexpectedToken(token, messages_1.Messages.StrictFunctionName);
							} else if (this.scanner.isRestrictedWord(token.value)) {
								firstRestricted = token;
								message = messages_1.Messages.StrictFunctionName;
							} else if (this.scanner.isStrictModeReservedWord(token.value)) {
								firstRestricted = token;
								message = messages_1.Messages.StrictReservedWord;
							}
						}
						var previousAllowAwait = this.context.await;
						var previousAllowYield = this.context.allowYield;
						this.context.await = isAsync;
						this.context.allowYield = !isGenerator;
						var formalParameters = this.parseFormalParameters(firstRestricted);
						var params = formalParameters.params;
						var stricted = formalParameters.stricted;
						firstRestricted = formalParameters.firstRestricted;
						if (formalParameters.message) message = formalParameters.message;
						var previousStrict = this.context.strict;
						var previousAllowStrictDirective = this.context.allowStrictDirective;
						this.context.allowStrictDirective = formalParameters.simple;
						var body = this.parseFunctionSourceElements();
						if (this.context.strict && firstRestricted) this.throwUnexpectedToken(firstRestricted, message);
						if (this.context.strict && stricted) this.tolerateUnexpectedToken(stricted, message);
						this.context.strict = previousStrict;
						this.context.allowStrictDirective = previousAllowStrictDirective;
						this.context.await = previousAllowAwait;
						this.context.allowYield = previousAllowYield;
						return isAsync ? this.finalize(node, new Node.AsyncFunctionDeclaration(id, params, body)) : this.finalize(node, new Node.FunctionDeclaration(id, params, body, isGenerator));
					};
					Parser.prototype.parseFunctionExpression = function() {
						var node = this.createNode();
						var isAsync = this.matchContextualKeyword("async");
						if (isAsync) this.nextToken();
						this.expectKeyword("function");
						var isGenerator = isAsync ? false : this.match("*");
						if (isGenerator) this.nextToken();
						var message;
						var id = null;
						var firstRestricted;
						var previousAllowAwait = this.context.await;
						var previousAllowYield = this.context.allowYield;
						this.context.await = isAsync;
						this.context.allowYield = !isGenerator;
						if (!this.match("(")) {
							var token = this.lookahead;
							id = !this.context.strict && !isGenerator && this.matchKeyword("yield") ? this.parseIdentifierName() : this.parseVariableIdentifier();
							if (this.context.strict) {
								if (this.scanner.isRestrictedWord(token.value)) this.tolerateUnexpectedToken(token, messages_1.Messages.StrictFunctionName);
							} else if (this.scanner.isRestrictedWord(token.value)) {
								firstRestricted = token;
								message = messages_1.Messages.StrictFunctionName;
							} else if (this.scanner.isStrictModeReservedWord(token.value)) {
								firstRestricted = token;
								message = messages_1.Messages.StrictReservedWord;
							}
						}
						var formalParameters = this.parseFormalParameters(firstRestricted);
						var params = formalParameters.params;
						var stricted = formalParameters.stricted;
						firstRestricted = formalParameters.firstRestricted;
						if (formalParameters.message) message = formalParameters.message;
						var previousStrict = this.context.strict;
						var previousAllowStrictDirective = this.context.allowStrictDirective;
						this.context.allowStrictDirective = formalParameters.simple;
						var body = this.parseFunctionSourceElements();
						if (this.context.strict && firstRestricted) this.throwUnexpectedToken(firstRestricted, message);
						if (this.context.strict && stricted) this.tolerateUnexpectedToken(stricted, message);
						this.context.strict = previousStrict;
						this.context.allowStrictDirective = previousAllowStrictDirective;
						this.context.await = previousAllowAwait;
						this.context.allowYield = previousAllowYield;
						return isAsync ? this.finalize(node, new Node.AsyncFunctionExpression(id, params, body)) : this.finalize(node, new Node.FunctionExpression(id, params, body, isGenerator));
					};
					Parser.prototype.parseDirective = function() {
						var token = this.lookahead;
						var node = this.createNode();
						var expr = this.parseExpression();
						var directive = expr.type === syntax_1.Syntax.Literal ? this.getTokenRaw(token).slice(1, -1) : null;
						this.consumeSemicolon();
						return this.finalize(node, directive ? new Node.Directive(expr, directive) : new Node.ExpressionStatement(expr));
					};
					Parser.prototype.parseDirectivePrologues = function() {
						var firstRestricted = null;
						var body = [];
						while (true) {
							var token = this.lookahead;
							if (token.type !== 8) break;
							var statement = this.parseDirective();
							body.push(statement);
							var directive = statement.directive;
							if (typeof directive !== "string") break;
							if (directive === "use strict") {
								this.context.strict = true;
								if (firstRestricted) this.tolerateUnexpectedToken(firstRestricted, messages_1.Messages.StrictOctalLiteral);
								if (!this.context.allowStrictDirective) this.tolerateUnexpectedToken(token, messages_1.Messages.IllegalLanguageModeDirective);
							} else if (!firstRestricted && token.octal) firstRestricted = token;
						}
						return body;
					};
					Parser.prototype.qualifiedPropertyName = function(token) {
						switch (token.type) {
							case 3:
							case 8:
							case 1:
							case 5:
							case 6:
							case 4: return true;
							case 7: return token.value === "[";
							default: break;
						}
						return false;
					};
					Parser.prototype.parseGetterMethod = function() {
						var node = this.createNode();
						var isGenerator = false;
						var previousAllowYield = this.context.allowYield;
						this.context.allowYield = !isGenerator;
						var formalParameters = this.parseFormalParameters();
						if (formalParameters.params.length > 0) this.tolerateError(messages_1.Messages.BadGetterArity);
						var method = this.parsePropertyMethod(formalParameters);
						this.context.allowYield = previousAllowYield;
						return this.finalize(node, new Node.FunctionExpression(null, formalParameters.params, method, isGenerator));
					};
					Parser.prototype.parseSetterMethod = function() {
						var node = this.createNode();
						var isGenerator = false;
						var previousAllowYield = this.context.allowYield;
						this.context.allowYield = !isGenerator;
						var formalParameters = this.parseFormalParameters();
						if (formalParameters.params.length !== 1) this.tolerateError(messages_1.Messages.BadSetterArity);
						else if (formalParameters.params[0] instanceof Node.RestElement) this.tolerateError(messages_1.Messages.BadSetterRestParameter);
						var method = this.parsePropertyMethod(formalParameters);
						this.context.allowYield = previousAllowYield;
						return this.finalize(node, new Node.FunctionExpression(null, formalParameters.params, method, isGenerator));
					};
					Parser.prototype.parseGeneratorMethod = function() {
						var node = this.createNode();
						var isGenerator = true;
						var previousAllowYield = this.context.allowYield;
						this.context.allowYield = true;
						var params = this.parseFormalParameters();
						this.context.allowYield = false;
						var method = this.parsePropertyMethod(params);
						this.context.allowYield = previousAllowYield;
						return this.finalize(node, new Node.FunctionExpression(null, params.params, method, isGenerator));
					};
					Parser.prototype.isStartOfExpression = function() {
						var start = true;
						var value = this.lookahead.value;
						switch (this.lookahead.type) {
							case 7:
								start = value === "[" || value === "(" || value === "{" || value === "+" || value === "-" || value === "!" || value === "~" || value === "++" || value === "--" || value === "/" || value === "/=";
								break;
							case 4:
								start = value === "class" || value === "delete" || value === "function" || value === "let" || value === "new" || value === "super" || value === "this" || value === "typeof" || value === "void" || value === "yield";
								break;
							default: break;
						}
						return start;
					};
					Parser.prototype.parseYieldExpression = function() {
						var node = this.createNode();
						this.expectKeyword("yield");
						var argument = null;
						var delegate = false;
						if (!this.hasLineTerminator) {
							var previousAllowYield = this.context.allowYield;
							this.context.allowYield = false;
							delegate = this.match("*");
							if (delegate) {
								this.nextToken();
								argument = this.parseAssignmentExpression();
							} else if (this.isStartOfExpression()) argument = this.parseAssignmentExpression();
							this.context.allowYield = previousAllowYield;
						}
						return this.finalize(node, new Node.YieldExpression(argument, delegate));
					};
					Parser.prototype.parseClassElement = function(hasConstructor) {
						var token = this.lookahead;
						var node = this.createNode();
						var kind = "";
						var key = null;
						var value = null;
						var computed = false;
						var method = false;
						var isStatic = false;
						var isAsync = false;
						if (this.match("*")) this.nextToken();
						else {
							computed = this.match("[");
							key = this.parseObjectPropertyKey();
							if (key.name === "static" && (this.qualifiedPropertyName(this.lookahead) || this.match("*"))) {
								token = this.lookahead;
								isStatic = true;
								computed = this.match("[");
								if (this.match("*")) this.nextToken();
								else key = this.parseObjectPropertyKey();
							}
							if (token.type === 3 && !this.hasLineTerminator && token.value === "async") {
								var punctuator = this.lookahead.value;
								if (punctuator !== ":" && punctuator !== "(" && punctuator !== "*") {
									isAsync = true;
									token = this.lookahead;
									key = this.parseObjectPropertyKey();
									if (token.type === 3 && token.value === "constructor") this.tolerateUnexpectedToken(token, messages_1.Messages.ConstructorIsAsync);
								}
							}
						}
						var lookaheadPropertyKey = this.qualifiedPropertyName(this.lookahead);
						if (token.type === 3) {
							if (token.value === "get" && lookaheadPropertyKey) {
								kind = "get";
								computed = this.match("[");
								key = this.parseObjectPropertyKey();
								this.context.allowYield = false;
								value = this.parseGetterMethod();
							} else if (token.value === "set" && lookaheadPropertyKey) {
								kind = "set";
								computed = this.match("[");
								key = this.parseObjectPropertyKey();
								value = this.parseSetterMethod();
							}
						} else if (token.type === 7 && token.value === "*" && lookaheadPropertyKey) {
							kind = "init";
							computed = this.match("[");
							key = this.parseObjectPropertyKey();
							value = this.parseGeneratorMethod();
							method = true;
						}
						if (!kind && key && this.match("(")) {
							kind = "init";
							value = isAsync ? this.parsePropertyMethodAsyncFunction() : this.parsePropertyMethodFunction();
							method = true;
						}
						if (!kind) this.throwUnexpectedToken(this.lookahead);
						if (kind === "init") kind = "method";
						if (!computed) {
							if (isStatic && this.isPropertyKey(key, "prototype")) this.throwUnexpectedToken(token, messages_1.Messages.StaticPrototype);
							if (!isStatic && this.isPropertyKey(key, "constructor")) {
								if (kind !== "method" || !method || value && value.generator) this.throwUnexpectedToken(token, messages_1.Messages.ConstructorSpecialMethod);
								if (hasConstructor.value) this.throwUnexpectedToken(token, messages_1.Messages.DuplicateConstructor);
								else hasConstructor.value = true;
								kind = "constructor";
							}
						}
						return this.finalize(node, new Node.MethodDefinition(key, computed, value, kind, isStatic));
					};
					Parser.prototype.parseClassElementList = function() {
						var body = [];
						var hasConstructor = { value: false };
						this.expect("{");
						while (!this.match("}")) if (this.match(";")) this.nextToken();
						else body.push(this.parseClassElement(hasConstructor));
						this.expect("}");
						return body;
					};
					Parser.prototype.parseClassBody = function() {
						var node = this.createNode();
						var elementList = this.parseClassElementList();
						return this.finalize(node, new Node.ClassBody(elementList));
					};
					Parser.prototype.parseClassDeclaration = function(identifierIsOptional) {
						var node = this.createNode();
						var previousStrict = this.context.strict;
						this.context.strict = true;
						this.expectKeyword("class");
						var id = identifierIsOptional && this.lookahead.type !== 3 ? null : this.parseVariableIdentifier();
						var superClass = null;
						if (this.matchKeyword("extends")) {
							this.nextToken();
							superClass = this.isolateCoverGrammar(this.parseLeftHandSideExpressionAllowCall);
						}
						var classBody = this.parseClassBody();
						this.context.strict = previousStrict;
						return this.finalize(node, new Node.ClassDeclaration(id, superClass, classBody));
					};
					Parser.prototype.parseClassExpression = function() {
						var node = this.createNode();
						var previousStrict = this.context.strict;
						this.context.strict = true;
						this.expectKeyword("class");
						var id = this.lookahead.type === 3 ? this.parseVariableIdentifier() : null;
						var superClass = null;
						if (this.matchKeyword("extends")) {
							this.nextToken();
							superClass = this.isolateCoverGrammar(this.parseLeftHandSideExpressionAllowCall);
						}
						var classBody = this.parseClassBody();
						this.context.strict = previousStrict;
						return this.finalize(node, new Node.ClassExpression(id, superClass, classBody));
					};
					Parser.prototype.parseModule = function() {
						this.context.strict = true;
						this.context.isModule = true;
						this.scanner.isModule = true;
						var node = this.createNode();
						var body = this.parseDirectivePrologues();
						while (this.lookahead.type !== 2) body.push(this.parseStatementListItem());
						return this.finalize(node, new Node.Module(body));
					};
					Parser.prototype.parseScript = function() {
						var node = this.createNode();
						var body = this.parseDirectivePrologues();
						while (this.lookahead.type !== 2) body.push(this.parseStatementListItem());
						return this.finalize(node, new Node.Script(body));
					};
					Parser.prototype.parseModuleSpecifier = function() {
						var node = this.createNode();
						if (this.lookahead.type !== 8) this.throwError(messages_1.Messages.InvalidModuleSpecifier);
						var token = this.nextToken();
						var raw = this.getTokenRaw(token);
						return this.finalize(node, new Node.Literal(token.value, raw));
					};
					Parser.prototype.parseImportSpecifier = function() {
						var node = this.createNode();
						var imported;
						var local;
						if (this.lookahead.type === 3) {
							imported = this.parseVariableIdentifier();
							local = imported;
							if (this.matchContextualKeyword("as")) {
								this.nextToken();
								local = this.parseVariableIdentifier();
							}
						} else {
							imported = this.parseIdentifierName();
							local = imported;
							if (this.matchContextualKeyword("as")) {
								this.nextToken();
								local = this.parseVariableIdentifier();
							} else this.throwUnexpectedToken(this.nextToken());
						}
						return this.finalize(node, new Node.ImportSpecifier(local, imported));
					};
					Parser.prototype.parseNamedImports = function() {
						this.expect("{");
						var specifiers = [];
						while (!this.match("}")) {
							specifiers.push(this.parseImportSpecifier());
							if (!this.match("}")) this.expect(",");
						}
						this.expect("}");
						return specifiers;
					};
					Parser.prototype.parseImportDefaultSpecifier = function() {
						var node = this.createNode();
						var local = this.parseIdentifierName();
						return this.finalize(node, new Node.ImportDefaultSpecifier(local));
					};
					Parser.prototype.parseImportNamespaceSpecifier = function() {
						var node = this.createNode();
						this.expect("*");
						if (!this.matchContextualKeyword("as")) this.throwError(messages_1.Messages.NoAsAfterImportNamespace);
						this.nextToken();
						var local = this.parseIdentifierName();
						return this.finalize(node, new Node.ImportNamespaceSpecifier(local));
					};
					Parser.prototype.parseImportDeclaration = function() {
						if (this.context.inFunctionBody) this.throwError(messages_1.Messages.IllegalImportDeclaration);
						var node = this.createNode();
						this.expectKeyword("import");
						var src;
						var specifiers = [];
						if (this.lookahead.type === 8) src = this.parseModuleSpecifier();
						else {
							if (this.match("{")) specifiers = specifiers.concat(this.parseNamedImports());
							else if (this.match("*")) specifiers.push(this.parseImportNamespaceSpecifier());
							else if (this.isIdentifierName(this.lookahead) && !this.matchKeyword("default")) {
								specifiers.push(this.parseImportDefaultSpecifier());
								if (this.match(",")) {
									this.nextToken();
									if (this.match("*")) specifiers.push(this.parseImportNamespaceSpecifier());
									else if (this.match("{")) specifiers = specifiers.concat(this.parseNamedImports());
									else this.throwUnexpectedToken(this.lookahead);
								}
							} else this.throwUnexpectedToken(this.nextToken());
							if (!this.matchContextualKeyword("from")) {
								var message = this.lookahead.value ? messages_1.Messages.UnexpectedToken : messages_1.Messages.MissingFromClause;
								this.throwError(message, this.lookahead.value);
							}
							this.nextToken();
							src = this.parseModuleSpecifier();
						}
						this.consumeSemicolon();
						return this.finalize(node, new Node.ImportDeclaration(specifiers, src));
					};
					Parser.prototype.parseExportSpecifier = function() {
						var node = this.createNode();
						var local = this.parseIdentifierName();
						var exported = local;
						if (this.matchContextualKeyword("as")) {
							this.nextToken();
							exported = this.parseIdentifierName();
						}
						return this.finalize(node, new Node.ExportSpecifier(local, exported));
					};
					Parser.prototype.parseExportDeclaration = function() {
						if (this.context.inFunctionBody) this.throwError(messages_1.Messages.IllegalExportDeclaration);
						var node = this.createNode();
						this.expectKeyword("export");
						var exportDeclaration;
						if (this.matchKeyword("default")) {
							this.nextToken();
							if (this.matchKeyword("function")) {
								var declaration = this.parseFunctionDeclaration(true);
								exportDeclaration = this.finalize(node, new Node.ExportDefaultDeclaration(declaration));
							} else if (this.matchKeyword("class")) {
								var declaration = this.parseClassDeclaration(true);
								exportDeclaration = this.finalize(node, new Node.ExportDefaultDeclaration(declaration));
							} else if (this.matchContextualKeyword("async")) {
								var declaration = this.matchAsyncFunction() ? this.parseFunctionDeclaration(true) : this.parseAssignmentExpression();
								exportDeclaration = this.finalize(node, new Node.ExportDefaultDeclaration(declaration));
							} else {
								if (this.matchContextualKeyword("from")) this.throwError(messages_1.Messages.UnexpectedToken, this.lookahead.value);
								var declaration = this.match("{") ? this.parseObjectInitializer() : this.match("[") ? this.parseArrayInitializer() : this.parseAssignmentExpression();
								this.consumeSemicolon();
								exportDeclaration = this.finalize(node, new Node.ExportDefaultDeclaration(declaration));
							}
						} else if (this.match("*")) {
							this.nextToken();
							if (!this.matchContextualKeyword("from")) {
								var message = this.lookahead.value ? messages_1.Messages.UnexpectedToken : messages_1.Messages.MissingFromClause;
								this.throwError(message, this.lookahead.value);
							}
							this.nextToken();
							var src = this.parseModuleSpecifier();
							this.consumeSemicolon();
							exportDeclaration = this.finalize(node, new Node.ExportAllDeclaration(src));
						} else if (this.lookahead.type === 4) {
							var declaration = void 0;
							switch (this.lookahead.value) {
								case "let":
								case "const":
									declaration = this.parseLexicalDeclaration({ inFor: false });
									break;
								case "var":
								case "class":
								case "function":
									declaration = this.parseStatementListItem();
									break;
								default: this.throwUnexpectedToken(this.lookahead);
							}
							exportDeclaration = this.finalize(node, new Node.ExportNamedDeclaration(declaration, [], null));
						} else if (this.matchAsyncFunction()) {
							var declaration = this.parseFunctionDeclaration();
							exportDeclaration = this.finalize(node, new Node.ExportNamedDeclaration(declaration, [], null));
						} else {
							var specifiers = [];
							var source = null;
							var isExportFromIdentifier = false;
							this.expect("{");
							while (!this.match("}")) {
								isExportFromIdentifier = isExportFromIdentifier || this.matchKeyword("default");
								specifiers.push(this.parseExportSpecifier());
								if (!this.match("}")) this.expect(",");
							}
							this.expect("}");
							if (this.matchContextualKeyword("from")) {
								this.nextToken();
								source = this.parseModuleSpecifier();
								this.consumeSemicolon();
							} else if (isExportFromIdentifier) {
								var message = this.lookahead.value ? messages_1.Messages.UnexpectedToken : messages_1.Messages.MissingFromClause;
								this.throwError(message, this.lookahead.value);
							} else this.consumeSemicolon();
							exportDeclaration = this.finalize(node, new Node.ExportNamedDeclaration(null, specifiers, source));
						}
						return exportDeclaration;
					};
					return Parser;
				}();
			},
			function(module$11, exports$10) {
				"use strict";
				Object.defineProperty(exports$10, "__esModule", { value: true });
				function assert(condition, message) {
					/* istanbul ignore if */
					if (!condition) throw new Error("ASSERT: " + message);
				}
				exports$10.assert = assert;
			},
			function(module$12, exports$11) {
				"use strict";
				Object.defineProperty(exports$11, "__esModule", { value: true });
				exports$11.ErrorHandler = function() {
					function ErrorHandler() {
						this.errors = [];
						this.tolerant = false;
					}
					ErrorHandler.prototype.recordError = function(error) {
						this.errors.push(error);
					};
					ErrorHandler.prototype.tolerate = function(error) {
						if (this.tolerant) this.recordError(error);
						else throw error;
					};
					ErrorHandler.prototype.constructError = function(msg, column) {
						var error = new Error(msg);
						try {
							throw error;
						} catch (base) {
							/* istanbul ignore else */
							if (Object.create && Object.defineProperty) {
								error = Object.create(base);
								Object.defineProperty(error, "column", { value: column });
							}
						}
						/* istanbul ignore next */
						return error;
					};
					ErrorHandler.prototype.createError = function(index, line, col, description) {
						var msg = "Line " + line + ": " + description;
						var error = this.constructError(msg, col);
						error.index = index;
						error.lineNumber = line;
						error.description = description;
						return error;
					};
					ErrorHandler.prototype.throwError = function(index, line, col, description) {
						throw this.createError(index, line, col, description);
					};
					ErrorHandler.prototype.tolerateError = function(index, line, col, description) {
						var error = this.createError(index, line, col, description);
						if (this.tolerant) this.recordError(error);
						else throw error;
					};
					return ErrorHandler;
				}();
			},
			function(module$13, exports$12) {
				"use strict";
				Object.defineProperty(exports$12, "__esModule", { value: true });
				exports$12.Messages = {
					BadGetterArity: "Getter must not have any formal parameters",
					BadSetterArity: "Setter must have exactly one formal parameter",
					BadSetterRestParameter: "Setter function argument must not be a rest parameter",
					ConstructorIsAsync: "Class constructor may not be an async method",
					ConstructorSpecialMethod: "Class constructor may not be an accessor",
					DeclarationMissingInitializer: "Missing initializer in %0 declaration",
					DefaultRestParameter: "Unexpected token =",
					DuplicateBinding: "Duplicate binding %0",
					DuplicateConstructor: "A class may only have one constructor",
					DuplicateProtoProperty: "Duplicate __proto__ fields are not allowed in object literals",
					ForInOfLoopInitializer: "%0 loop variable declaration may not have an initializer",
					GeneratorInLegacyContext: "Generator declarations are not allowed in legacy contexts",
					IllegalBreak: "Illegal break statement",
					IllegalContinue: "Illegal continue statement",
					IllegalExportDeclaration: "Unexpected token",
					IllegalImportDeclaration: "Unexpected token",
					IllegalLanguageModeDirective: "Illegal 'use strict' directive in function with non-simple parameter list",
					IllegalReturn: "Illegal return statement",
					InvalidEscapedReservedWord: "Keyword must not contain escaped characters",
					InvalidHexEscapeSequence: "Invalid hexadecimal escape sequence",
					InvalidLHSInAssignment: "Invalid left-hand side in assignment",
					InvalidLHSInForIn: "Invalid left-hand side in for-in",
					InvalidLHSInForLoop: "Invalid left-hand side in for-loop",
					InvalidModuleSpecifier: "Unexpected token",
					InvalidRegExp: "Invalid regular expression",
					LetInLexicalBinding: "let is disallowed as a lexically bound name",
					MissingFromClause: "Unexpected token",
					MultipleDefaultsInSwitch: "More than one default clause in switch statement",
					NewlineAfterThrow: "Illegal newline after throw",
					NoAsAfterImportNamespace: "Unexpected token",
					NoCatchOrFinally: "Missing catch or finally after try",
					ParameterAfterRestParameter: "Rest parameter must be last formal parameter",
					Redeclaration: "%0 '%1' has already been declared",
					StaticPrototype: "Classes may not have static property named prototype",
					StrictCatchVariable: "Catch variable may not be eval or arguments in strict mode",
					StrictDelete: "Delete of an unqualified identifier in strict mode.",
					StrictFunction: "In strict mode code, functions can only be declared at top level or inside a block",
					StrictFunctionName: "Function name may not be eval or arguments in strict mode",
					StrictLHSAssignment: "Assignment to eval or arguments is not allowed in strict mode",
					StrictLHSPostfix: "Postfix increment/decrement may not have eval or arguments operand in strict mode",
					StrictLHSPrefix: "Prefix increment/decrement may not have eval or arguments operand in strict mode",
					StrictModeWith: "Strict mode code may not include a with statement",
					StrictOctalLiteral: "Octal literals are not allowed in strict mode.",
					StrictParamDupe: "Strict mode function may not have duplicate parameter names",
					StrictParamName: "Parameter name eval or arguments is not allowed in strict mode",
					StrictReservedWord: "Use of future reserved word in strict mode",
					StrictVarName: "Variable name may not be eval or arguments in strict mode",
					TemplateOctalLiteral: "Octal literals are not allowed in template strings.",
					UnexpectedEOS: "Unexpected end of input",
					UnexpectedIdentifier: "Unexpected identifier",
					UnexpectedNumber: "Unexpected number",
					UnexpectedReserved: "Unexpected reserved word",
					UnexpectedString: "Unexpected string",
					UnexpectedTemplate: "Unexpected quasi %0",
					UnexpectedToken: "Unexpected token %0",
					UnexpectedTokenIllegal: "Unexpected token ILLEGAL",
					UnknownLabel: "Undefined label '%0'",
					UnterminatedRegExp: "Invalid regular expression: missing /"
				};
			},
			function(module$14, exports$13, __webpack_require__) {
				"use strict";
				Object.defineProperty(exports$13, "__esModule", { value: true });
				var assert_1 = __webpack_require__(9);
				var character_1 = __webpack_require__(4);
				var messages_1 = __webpack_require__(11);
				function hexValue(ch) {
					return "0123456789abcdef".indexOf(ch.toLowerCase());
				}
				function octalValue(ch) {
					return "01234567".indexOf(ch);
				}
				exports$13.Scanner = function() {
					function Scanner(code, handler) {
						this.source = code;
						this.errorHandler = handler;
						this.trackComment = false;
						this.isModule = false;
						this.length = code.length;
						this.index = 0;
						this.lineNumber = code.length > 0 ? 1 : 0;
						this.lineStart = 0;
						this.curlyStack = [];
					}
					Scanner.prototype.saveState = function() {
						return {
							index: this.index,
							lineNumber: this.lineNumber,
							lineStart: this.lineStart
						};
					};
					Scanner.prototype.restoreState = function(state) {
						this.index = state.index;
						this.lineNumber = state.lineNumber;
						this.lineStart = state.lineStart;
					};
					Scanner.prototype.eof = function() {
						return this.index >= this.length;
					};
					Scanner.prototype.throwUnexpectedToken = function(message) {
						if (message === void 0) message = messages_1.Messages.UnexpectedTokenIllegal;
						return this.errorHandler.throwError(this.index, this.lineNumber, this.index - this.lineStart + 1, message);
					};
					Scanner.prototype.tolerateUnexpectedToken = function(message) {
						if (message === void 0) message = messages_1.Messages.UnexpectedTokenIllegal;
						this.errorHandler.tolerateError(this.index, this.lineNumber, this.index - this.lineStart + 1, message);
					};
					Scanner.prototype.skipSingleLineComment = function(offset) {
						var comments = [];
						var start, loc;
						if (this.trackComment) {
							comments = [];
							start = this.index - offset;
							loc = {
								start: {
									line: this.lineNumber,
									column: this.index - this.lineStart - offset
								},
								end: {}
							};
						}
						while (!this.eof()) {
							var ch = this.source.charCodeAt(this.index);
							++this.index;
							if (character_1.Character.isLineTerminator(ch)) {
								if (this.trackComment) {
									loc.end = {
										line: this.lineNumber,
										column: this.index - this.lineStart - 1
									};
									var entry = {
										multiLine: false,
										slice: [start + offset, this.index - 1],
										range: [start, this.index - 1],
										loc
									};
									comments.push(entry);
								}
								if (ch === 13 && this.source.charCodeAt(this.index) === 10) ++this.index;
								++this.lineNumber;
								this.lineStart = this.index;
								return comments;
							}
						}
						if (this.trackComment) {
							loc.end = {
								line: this.lineNumber,
								column: this.index - this.lineStart
							};
							var entry = {
								multiLine: false,
								slice: [start + offset, this.index],
								range: [start, this.index],
								loc
							};
							comments.push(entry);
						}
						return comments;
					};
					Scanner.prototype.skipMultiLineComment = function() {
						var comments = [];
						var start, loc;
						if (this.trackComment) {
							comments = [];
							start = this.index - 2;
							loc = {
								start: {
									line: this.lineNumber,
									column: this.index - this.lineStart - 2
								},
								end: {}
							};
						}
						while (!this.eof()) {
							var ch = this.source.charCodeAt(this.index);
							if (character_1.Character.isLineTerminator(ch)) {
								if (ch === 13 && this.source.charCodeAt(this.index + 1) === 10) ++this.index;
								++this.lineNumber;
								++this.index;
								this.lineStart = this.index;
							} else if (ch === 42) {
								if (this.source.charCodeAt(this.index + 1) === 47) {
									this.index += 2;
									if (this.trackComment) {
										loc.end = {
											line: this.lineNumber,
											column: this.index - this.lineStart
										};
										var entry = {
											multiLine: true,
											slice: [start + 2, this.index - 2],
											range: [start, this.index],
											loc
										};
										comments.push(entry);
									}
									return comments;
								}
								++this.index;
							} else ++this.index;
						}
						if (this.trackComment) {
							loc.end = {
								line: this.lineNumber,
								column: this.index - this.lineStart
							};
							var entry = {
								multiLine: true,
								slice: [start + 2, this.index],
								range: [start, this.index],
								loc
							};
							comments.push(entry);
						}
						this.tolerateUnexpectedToken();
						return comments;
					};
					Scanner.prototype.scanComments = function() {
						var comments;
						if (this.trackComment) comments = [];
						var start = this.index === 0;
						while (!this.eof()) {
							var ch = this.source.charCodeAt(this.index);
							if (character_1.Character.isWhiteSpace(ch)) ++this.index;
							else if (character_1.Character.isLineTerminator(ch)) {
								++this.index;
								if (ch === 13 && this.source.charCodeAt(this.index) === 10) ++this.index;
								++this.lineNumber;
								this.lineStart = this.index;
								start = true;
							} else if (ch === 47) {
								ch = this.source.charCodeAt(this.index + 1);
								if (ch === 47) {
									this.index += 2;
									var comment = this.skipSingleLineComment(2);
									if (this.trackComment) comments = comments.concat(comment);
									start = true;
								} else if (ch === 42) {
									this.index += 2;
									var comment = this.skipMultiLineComment();
									if (this.trackComment) comments = comments.concat(comment);
								} else break;
							} else if (start && ch === 45) if (this.source.charCodeAt(this.index + 1) === 45 && this.source.charCodeAt(this.index + 2) === 62) {
								this.index += 3;
								var comment = this.skipSingleLineComment(3);
								if (this.trackComment) comments = comments.concat(comment);
							} else break;
							else if (ch === 60 && !this.isModule) if (this.source.slice(this.index + 1, this.index + 4) === "!--") {
								this.index += 4;
								var comment = this.skipSingleLineComment(4);
								if (this.trackComment) comments = comments.concat(comment);
							} else break;
							else break;
						}
						return comments;
					};
					Scanner.prototype.isFutureReservedWord = function(id) {
						switch (id) {
							case "enum":
							case "export":
							case "import":
							case "super": return true;
							default: return false;
						}
					};
					Scanner.prototype.isStrictModeReservedWord = function(id) {
						switch (id) {
							case "implements":
							case "interface":
							case "package":
							case "private":
							case "protected":
							case "public":
							case "static":
							case "yield":
							case "let": return true;
							default: return false;
						}
					};
					Scanner.prototype.isRestrictedWord = function(id) {
						return id === "eval" || id === "arguments";
					};
					Scanner.prototype.isKeyword = function(id) {
						switch (id.length) {
							case 2: return id === "if" || id === "in" || id === "do";
							case 3: return id === "var" || id === "for" || id === "new" || id === "try" || id === "let";
							case 4: return id === "this" || id === "else" || id === "case" || id === "void" || id === "with" || id === "enum";
							case 5: return id === "while" || id === "break" || id === "catch" || id === "throw" || id === "const" || id === "yield" || id === "class" || id === "super";
							case 6: return id === "return" || id === "typeof" || id === "delete" || id === "switch" || id === "export" || id === "import";
							case 7: return id === "default" || id === "finally" || id === "extends";
							case 8: return id === "function" || id === "continue" || id === "debugger";
							case 10: return id === "instanceof";
							default: return false;
						}
					};
					Scanner.prototype.codePointAt = function(i) {
						var cp = this.source.charCodeAt(i);
						if (cp >= 55296 && cp <= 56319) {
							var second = this.source.charCodeAt(i + 1);
							if (second >= 56320 && second <= 57343) cp = (cp - 55296) * 1024 + second - 56320 + 65536;
						}
						return cp;
					};
					Scanner.prototype.scanHexEscape = function(prefix) {
						var len = prefix === "u" ? 4 : 2;
						var code = 0;
						for (var i = 0; i < len; ++i) if (!this.eof() && character_1.Character.isHexDigit(this.source.charCodeAt(this.index))) code = code * 16 + hexValue(this.source[this.index++]);
						else return null;
						return String.fromCharCode(code);
					};
					Scanner.prototype.scanUnicodeCodePointEscape = function() {
						var ch = this.source[this.index];
						var code = 0;
						if (ch === "}") this.throwUnexpectedToken();
						while (!this.eof()) {
							ch = this.source[this.index++];
							if (!character_1.Character.isHexDigit(ch.charCodeAt(0))) break;
							code = code * 16 + hexValue(ch);
						}
						if (code > 1114111 || ch !== "}") this.throwUnexpectedToken();
						return character_1.Character.fromCodePoint(code);
					};
					Scanner.prototype.getIdentifier = function() {
						var start = this.index++;
						while (!this.eof()) {
							var ch = this.source.charCodeAt(this.index);
							if (ch === 92) {
								this.index = start;
								return this.getComplexIdentifier();
							} else if (ch >= 55296 && ch < 57343) {
								this.index = start;
								return this.getComplexIdentifier();
							}
							if (character_1.Character.isIdentifierPart(ch)) ++this.index;
							else break;
						}
						return this.source.slice(start, this.index);
					};
					Scanner.prototype.getComplexIdentifier = function() {
						var cp = this.codePointAt(this.index);
						var id = character_1.Character.fromCodePoint(cp);
						this.index += id.length;
						var ch;
						if (cp === 92) {
							if (this.source.charCodeAt(this.index) !== 117) this.throwUnexpectedToken();
							++this.index;
							if (this.source[this.index] === "{") {
								++this.index;
								ch = this.scanUnicodeCodePointEscape();
							} else {
								ch = this.scanHexEscape("u");
								if (ch === null || ch === "\\" || !character_1.Character.isIdentifierStart(ch.charCodeAt(0))) this.throwUnexpectedToken();
							}
							id = ch;
						}
						while (!this.eof()) {
							cp = this.codePointAt(this.index);
							if (!character_1.Character.isIdentifierPart(cp)) break;
							ch = character_1.Character.fromCodePoint(cp);
							id += ch;
							this.index += ch.length;
							if (cp === 92) {
								id = id.substr(0, id.length - 1);
								if (this.source.charCodeAt(this.index) !== 117) this.throwUnexpectedToken();
								++this.index;
								if (this.source[this.index] === "{") {
									++this.index;
									ch = this.scanUnicodeCodePointEscape();
								} else {
									ch = this.scanHexEscape("u");
									if (ch === null || ch === "\\" || !character_1.Character.isIdentifierPart(ch.charCodeAt(0))) this.throwUnexpectedToken();
								}
								id += ch;
							}
						}
						return id;
					};
					Scanner.prototype.octalToDecimal = function(ch) {
						var octal = ch !== "0";
						var code = octalValue(ch);
						if (!this.eof() && character_1.Character.isOctalDigit(this.source.charCodeAt(this.index))) {
							octal = true;
							code = code * 8 + octalValue(this.source[this.index++]);
							if ("0123".indexOf(ch) >= 0 && !this.eof() && character_1.Character.isOctalDigit(this.source.charCodeAt(this.index))) code = code * 8 + octalValue(this.source[this.index++]);
						}
						return {
							code,
							octal
						};
					};
					Scanner.prototype.scanIdentifier = function() {
						var type;
						var start = this.index;
						var id = this.source.charCodeAt(start) === 92 ? this.getComplexIdentifier() : this.getIdentifier();
						if (id.length === 1) type = 3;
						else if (this.isKeyword(id)) type = 4;
						else if (id === "null") type = 5;
						else if (id === "true" || id === "false") type = 1;
						else type = 3;
						if (type !== 3 && start + id.length !== this.index) {
							var restore = this.index;
							this.index = start;
							this.tolerateUnexpectedToken(messages_1.Messages.InvalidEscapedReservedWord);
							this.index = restore;
						}
						return {
							type,
							value: id,
							lineNumber: this.lineNumber,
							lineStart: this.lineStart,
							start,
							end: this.index
						};
					};
					Scanner.prototype.scanPunctuator = function() {
						var start = this.index;
						var str = this.source[this.index];
						switch (str) {
							case "(":
							case "{":
								if (str === "{") this.curlyStack.push("{");
								++this.index;
								break;
							case ".":
								++this.index;
								if (this.source[this.index] === "." && this.source[this.index + 1] === ".") {
									this.index += 2;
									str = "...";
								}
								break;
							case "}":
								++this.index;
								this.curlyStack.pop();
								break;
							case ")":
							case ";":
							case ",":
							case "[":
							case "]":
							case ":":
							case "?":
							case "~":
								++this.index;
								break;
							default:
								str = this.source.substr(this.index, 4);
								if (str === ">>>=") this.index += 4;
								else {
									str = str.substr(0, 3);
									if (str === "===" || str === "!==" || str === ">>>" || str === "<<=" || str === ">>=" || str === "**=") this.index += 3;
									else {
										str = str.substr(0, 2);
										if (str === "&&" || str === "||" || str === "==" || str === "!=" || str === "+=" || str === "-=" || str === "*=" || str === "/=" || str === "++" || str === "--" || str === "<<" || str === ">>" || str === "&=" || str === "|=" || str === "^=" || str === "%=" || str === "<=" || str === ">=" || str === "=>" || str === "**") this.index += 2;
										else {
											str = this.source[this.index];
											if ("<>=!+-*%&|^/".indexOf(str) >= 0) ++this.index;
										}
									}
								}
						}
						if (this.index === start) this.throwUnexpectedToken();
						return {
							type: 7,
							value: str,
							lineNumber: this.lineNumber,
							lineStart: this.lineStart,
							start,
							end: this.index
						};
					};
					Scanner.prototype.scanHexLiteral = function(start) {
						var num = "";
						while (!this.eof()) {
							if (!character_1.Character.isHexDigit(this.source.charCodeAt(this.index))) break;
							num += this.source[this.index++];
						}
						if (num.length === 0) this.throwUnexpectedToken();
						if (character_1.Character.isIdentifierStart(this.source.charCodeAt(this.index))) this.throwUnexpectedToken();
						return {
							type: 6,
							value: parseInt("0x" + num, 16),
							lineNumber: this.lineNumber,
							lineStart: this.lineStart,
							start,
							end: this.index
						};
					};
					Scanner.prototype.scanBinaryLiteral = function(start) {
						var num = "";
						var ch;
						while (!this.eof()) {
							ch = this.source[this.index];
							if (ch !== "0" && ch !== "1") break;
							num += this.source[this.index++];
						}
						if (num.length === 0) this.throwUnexpectedToken();
						if (!this.eof()) {
							ch = this.source.charCodeAt(this.index);
							/* istanbul ignore else */
							if (character_1.Character.isIdentifierStart(ch) || character_1.Character.isDecimalDigit(ch)) this.throwUnexpectedToken();
						}
						return {
							type: 6,
							value: parseInt(num, 2),
							lineNumber: this.lineNumber,
							lineStart: this.lineStart,
							start,
							end: this.index
						};
					};
					Scanner.prototype.scanOctalLiteral = function(prefix, start) {
						var num = "";
						var octal = false;
						if (character_1.Character.isOctalDigit(prefix.charCodeAt(0))) {
							octal = true;
							num = "0" + this.source[this.index++];
						} else ++this.index;
						while (!this.eof()) {
							if (!character_1.Character.isOctalDigit(this.source.charCodeAt(this.index))) break;
							num += this.source[this.index++];
						}
						if (!octal && num.length === 0) this.throwUnexpectedToken();
						if (character_1.Character.isIdentifierStart(this.source.charCodeAt(this.index)) || character_1.Character.isDecimalDigit(this.source.charCodeAt(this.index))) this.throwUnexpectedToken();
						return {
							type: 6,
							value: parseInt(num, 8),
							octal,
							lineNumber: this.lineNumber,
							lineStart: this.lineStart,
							start,
							end: this.index
						};
					};
					Scanner.prototype.isImplicitOctalLiteral = function() {
						for (var i = this.index + 1; i < this.length; ++i) {
							var ch = this.source[i];
							if (ch === "8" || ch === "9") return false;
							if (!character_1.Character.isOctalDigit(ch.charCodeAt(0))) return true;
						}
						return true;
					};
					Scanner.prototype.scanNumericLiteral = function() {
						var start = this.index;
						var ch = this.source[start];
						assert_1.assert(character_1.Character.isDecimalDigit(ch.charCodeAt(0)) || ch === ".", "Numeric literal must start with a decimal digit or a decimal point");
						var num = "";
						if (ch !== ".") {
							num = this.source[this.index++];
							ch = this.source[this.index];
							if (num === "0") {
								if (ch === "x" || ch === "X") {
									++this.index;
									return this.scanHexLiteral(start);
								}
								if (ch === "b" || ch === "B") {
									++this.index;
									return this.scanBinaryLiteral(start);
								}
								if (ch === "o" || ch === "O") return this.scanOctalLiteral(ch, start);
								if (ch && character_1.Character.isOctalDigit(ch.charCodeAt(0))) {
									if (this.isImplicitOctalLiteral()) return this.scanOctalLiteral(ch, start);
								}
							}
							while (character_1.Character.isDecimalDigit(this.source.charCodeAt(this.index))) num += this.source[this.index++];
							ch = this.source[this.index];
						}
						if (ch === ".") {
							num += this.source[this.index++];
							while (character_1.Character.isDecimalDigit(this.source.charCodeAt(this.index))) num += this.source[this.index++];
							ch = this.source[this.index];
						}
						if (ch === "e" || ch === "E") {
							num += this.source[this.index++];
							ch = this.source[this.index];
							if (ch === "+" || ch === "-") num += this.source[this.index++];
							if (character_1.Character.isDecimalDigit(this.source.charCodeAt(this.index))) while (character_1.Character.isDecimalDigit(this.source.charCodeAt(this.index))) num += this.source[this.index++];
							else this.throwUnexpectedToken();
						}
						if (character_1.Character.isIdentifierStart(this.source.charCodeAt(this.index))) this.throwUnexpectedToken();
						return {
							type: 6,
							value: parseFloat(num),
							lineNumber: this.lineNumber,
							lineStart: this.lineStart,
							start,
							end: this.index
						};
					};
					Scanner.prototype.scanStringLiteral = function() {
						var start = this.index;
						var quote = this.source[start];
						assert_1.assert(quote === "'" || quote === "\"", "String literal must starts with a quote");
						++this.index;
						var octal = false;
						var str = "";
						while (!this.eof()) {
							var ch = this.source[this.index++];
							if (ch === quote) {
								quote = "";
								break;
							} else if (ch === "\\") {
								ch = this.source[this.index++];
								if (!ch || !character_1.Character.isLineTerminator(ch.charCodeAt(0))) switch (ch) {
									case "u":
										if (this.source[this.index] === "{") {
											++this.index;
											str += this.scanUnicodeCodePointEscape();
										} else {
											var unescaped_1 = this.scanHexEscape(ch);
											if (unescaped_1 === null) this.throwUnexpectedToken();
											str += unescaped_1;
										}
										break;
									case "x":
										var unescaped = this.scanHexEscape(ch);
										if (unescaped === null) this.throwUnexpectedToken(messages_1.Messages.InvalidHexEscapeSequence);
										str += unescaped;
										break;
									case "n":
										str += "\n";
										break;
									case "r":
										str += "\r";
										break;
									case "t":
										str += "	";
										break;
									case "b":
										str += "\b";
										break;
									case "f":
										str += "\f";
										break;
									case "v":
										str += "\v";
										break;
									case "8":
									case "9":
										str += ch;
										this.tolerateUnexpectedToken();
										break;
									default:
										if (ch && character_1.Character.isOctalDigit(ch.charCodeAt(0))) {
											var octToDec = this.octalToDecimal(ch);
											octal = octToDec.octal || octal;
											str += String.fromCharCode(octToDec.code);
										} else str += ch;
										break;
								}
								else {
									++this.lineNumber;
									if (ch === "\r" && this.source[this.index] === "\n") ++this.index;
									this.lineStart = this.index;
								}
							} else if (character_1.Character.isLineTerminator(ch.charCodeAt(0))) break;
							else str += ch;
						}
						if (quote !== "") {
							this.index = start;
							this.throwUnexpectedToken();
						}
						return {
							type: 8,
							value: str,
							octal,
							lineNumber: this.lineNumber,
							lineStart: this.lineStart,
							start,
							end: this.index
						};
					};
					Scanner.prototype.scanTemplate = function() {
						var cooked = "";
						var terminated = false;
						var start = this.index;
						var head = this.source[start] === "`";
						var tail = false;
						var rawOffset = 2;
						++this.index;
						while (!this.eof()) {
							var ch = this.source[this.index++];
							if (ch === "`") {
								rawOffset = 1;
								tail = true;
								terminated = true;
								break;
							} else if (ch === "$") {
								if (this.source[this.index] === "{") {
									this.curlyStack.push("${");
									++this.index;
									terminated = true;
									break;
								}
								cooked += ch;
							} else if (ch === "\\") {
								ch = this.source[this.index++];
								if (!character_1.Character.isLineTerminator(ch.charCodeAt(0))) switch (ch) {
									case "n":
										cooked += "\n";
										break;
									case "r":
										cooked += "\r";
										break;
									case "t":
										cooked += "	";
										break;
									case "u":
										if (this.source[this.index] === "{") {
											++this.index;
											cooked += this.scanUnicodeCodePointEscape();
										} else {
											var restore = this.index;
											var unescaped_2 = this.scanHexEscape(ch);
											if (unescaped_2 !== null) cooked += unescaped_2;
											else {
												this.index = restore;
												cooked += ch;
											}
										}
										break;
									case "x":
										var unescaped = this.scanHexEscape(ch);
										if (unescaped === null) this.throwUnexpectedToken(messages_1.Messages.InvalidHexEscapeSequence);
										cooked += unescaped;
										break;
									case "b":
										cooked += "\b";
										break;
									case "f":
										cooked += "\f";
										break;
									case "v":
										cooked += "\v";
										break;
									default:
										if (ch === "0") {
											if (character_1.Character.isDecimalDigit(this.source.charCodeAt(this.index))) this.throwUnexpectedToken(messages_1.Messages.TemplateOctalLiteral);
											cooked += "\0";
										} else if (character_1.Character.isOctalDigit(ch.charCodeAt(0))) this.throwUnexpectedToken(messages_1.Messages.TemplateOctalLiteral);
										else cooked += ch;
										break;
								}
								else {
									++this.lineNumber;
									if (ch === "\r" && this.source[this.index] === "\n") ++this.index;
									this.lineStart = this.index;
								}
							} else if (character_1.Character.isLineTerminator(ch.charCodeAt(0))) {
								++this.lineNumber;
								if (ch === "\r" && this.source[this.index] === "\n") ++this.index;
								this.lineStart = this.index;
								cooked += "\n";
							} else cooked += ch;
						}
						if (!terminated) this.throwUnexpectedToken();
						if (!head) this.curlyStack.pop();
						return {
							type: 10,
							value: this.source.slice(start + 1, this.index - rawOffset),
							cooked,
							head,
							tail,
							lineNumber: this.lineNumber,
							lineStart: this.lineStart,
							start,
							end: this.index
						};
					};
					Scanner.prototype.testRegExp = function(pattern, flags) {
						var astralSubstitute = "￿";
						var tmp = pattern;
						var self = this;
						if (flags.indexOf("u") >= 0) tmp = tmp.replace(/\\u\{([0-9a-fA-F]+)\}|\\u([a-fA-F0-9]{4})/g, function($0, $1, $2) {
							var codePoint = parseInt($1 || $2, 16);
							if (codePoint > 1114111) self.throwUnexpectedToken(messages_1.Messages.InvalidRegExp);
							if (codePoint <= 65535) return String.fromCharCode(codePoint);
							return astralSubstitute;
						}).replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g, astralSubstitute);
						try {
							RegExp(tmp);
						} catch (e) {
							this.throwUnexpectedToken(messages_1.Messages.InvalidRegExp);
						}
						try {
							return new RegExp(pattern, flags);
						} catch (exception) {
							/* istanbul ignore next */
							return null;
						}
					};
					Scanner.prototype.scanRegExpBody = function() {
						var ch = this.source[this.index];
						assert_1.assert(ch === "/", "Regular expression literal must start with a slash");
						var str = this.source[this.index++];
						var classMarker = false;
						var terminated = false;
						while (!this.eof()) {
							ch = this.source[this.index++];
							str += ch;
							if (ch === "\\") {
								ch = this.source[this.index++];
								if (character_1.Character.isLineTerminator(ch.charCodeAt(0))) this.throwUnexpectedToken(messages_1.Messages.UnterminatedRegExp);
								str += ch;
							} else if (character_1.Character.isLineTerminator(ch.charCodeAt(0))) this.throwUnexpectedToken(messages_1.Messages.UnterminatedRegExp);
							else if (classMarker) {
								if (ch === "]") classMarker = false;
							} else if (ch === "/") {
								terminated = true;
								break;
							} else if (ch === "[") classMarker = true;
						}
						if (!terminated) this.throwUnexpectedToken(messages_1.Messages.UnterminatedRegExp);
						return str.substr(1, str.length - 2);
					};
					Scanner.prototype.scanRegExpFlags = function() {
						var str = "";
						var flags = "";
						while (!this.eof()) {
							var ch = this.source[this.index];
							if (!character_1.Character.isIdentifierPart(ch.charCodeAt(0))) break;
							++this.index;
							if (ch === "\\" && !this.eof()) {
								ch = this.source[this.index];
								if (ch === "u") {
									++this.index;
									var restore = this.index;
									var char = this.scanHexEscape("u");
									if (char !== null) {
										flags += char;
										for (str += "\\u"; restore < this.index; ++restore) str += this.source[restore];
									} else {
										this.index = restore;
										flags += "u";
										str += "\\u";
									}
									this.tolerateUnexpectedToken();
								} else {
									str += "\\";
									this.tolerateUnexpectedToken();
								}
							} else {
								flags += ch;
								str += ch;
							}
						}
						return flags;
					};
					Scanner.prototype.scanRegExp = function() {
						var start = this.index;
						var pattern = this.scanRegExpBody();
						var flags = this.scanRegExpFlags();
						return {
							type: 9,
							value: "",
							pattern,
							flags,
							regex: this.testRegExp(pattern, flags),
							lineNumber: this.lineNumber,
							lineStart: this.lineStart,
							start,
							end: this.index
						};
					};
					Scanner.prototype.lex = function() {
						if (this.eof()) return {
							type: 2,
							value: "",
							lineNumber: this.lineNumber,
							lineStart: this.lineStart,
							start: this.index,
							end: this.index
						};
						var cp = this.source.charCodeAt(this.index);
						if (character_1.Character.isIdentifierStart(cp)) return this.scanIdentifier();
						if (cp === 40 || cp === 41 || cp === 59) return this.scanPunctuator();
						if (cp === 39 || cp === 34) return this.scanStringLiteral();
						if (cp === 46) {
							if (character_1.Character.isDecimalDigit(this.source.charCodeAt(this.index + 1))) return this.scanNumericLiteral();
							return this.scanPunctuator();
						}
						if (character_1.Character.isDecimalDigit(cp)) return this.scanNumericLiteral();
						if (cp === 96 || cp === 125 && this.curlyStack[this.curlyStack.length - 1] === "${") return this.scanTemplate();
						if (cp >= 55296 && cp < 57343) {
							if (character_1.Character.isIdentifierStart(this.codePointAt(this.index))) return this.scanIdentifier();
						}
						return this.scanPunctuator();
					};
					return Scanner;
				}();
			},
			function(module$15, exports$14) {
				"use strict";
				Object.defineProperty(exports$14, "__esModule", { value: true });
				exports$14.TokenName = {};
				exports$14.TokenName[1] = "Boolean";
				exports$14.TokenName[2] = "<end>";
				exports$14.TokenName[3] = "Identifier";
				exports$14.TokenName[4] = "Keyword";
				exports$14.TokenName[5] = "Null";
				exports$14.TokenName[6] = "Numeric";
				exports$14.TokenName[7] = "Punctuator";
				exports$14.TokenName[8] = "String";
				exports$14.TokenName[9] = "RegularExpression";
				exports$14.TokenName[10] = "Template";
			},
			function(module$16, exports$15) {
				"use strict";
				Object.defineProperty(exports$15, "__esModule", { value: true });
				exports$15.XHTMLEntities = {
					quot: "\"",
					amp: "&",
					apos: "'",
					gt: ">",
					nbsp: "\xA0",
					iexcl: "¡",
					cent: "¢",
					pound: "£",
					curren: "¤",
					yen: "¥",
					brvbar: "¦",
					sect: "§",
					uml: "¨",
					copy: "©",
					ordf: "ª",
					laquo: "«",
					not: "¬",
					shy: "­",
					reg: "®",
					macr: "¯",
					deg: "°",
					plusmn: "±",
					sup2: "²",
					sup3: "³",
					acute: "´",
					micro: "µ",
					para: "¶",
					middot: "·",
					cedil: "¸",
					sup1: "¹",
					ordm: "º",
					raquo: "»",
					frac14: "¼",
					frac12: "½",
					frac34: "¾",
					iquest: "¿",
					Agrave: "À",
					Aacute: "Á",
					Acirc: "Â",
					Atilde: "Ã",
					Auml: "Ä",
					Aring: "Å",
					AElig: "Æ",
					Ccedil: "Ç",
					Egrave: "È",
					Eacute: "É",
					Ecirc: "Ê",
					Euml: "Ë",
					Igrave: "Ì",
					Iacute: "Í",
					Icirc: "Î",
					Iuml: "Ï",
					ETH: "Ð",
					Ntilde: "Ñ",
					Ograve: "Ò",
					Oacute: "Ó",
					Ocirc: "Ô",
					Otilde: "Õ",
					Ouml: "Ö",
					times: "×",
					Oslash: "Ø",
					Ugrave: "Ù",
					Uacute: "Ú",
					Ucirc: "Û",
					Uuml: "Ü",
					Yacute: "Ý",
					THORN: "Þ",
					szlig: "ß",
					agrave: "à",
					aacute: "á",
					acirc: "â",
					atilde: "ã",
					auml: "ä",
					aring: "å",
					aelig: "æ",
					ccedil: "ç",
					egrave: "è",
					eacute: "é",
					ecirc: "ê",
					euml: "ë",
					igrave: "ì",
					iacute: "í",
					icirc: "î",
					iuml: "ï",
					eth: "ð",
					ntilde: "ñ",
					ograve: "ò",
					oacute: "ó",
					ocirc: "ô",
					otilde: "õ",
					ouml: "ö",
					divide: "÷",
					oslash: "ø",
					ugrave: "ù",
					uacute: "ú",
					ucirc: "û",
					uuml: "ü",
					yacute: "ý",
					thorn: "þ",
					yuml: "ÿ",
					OElig: "Œ",
					oelig: "œ",
					Scaron: "Š",
					scaron: "š",
					Yuml: "Ÿ",
					fnof: "ƒ",
					circ: "ˆ",
					tilde: "˜",
					Alpha: "Α",
					Beta: "Β",
					Gamma: "Γ",
					Delta: "Δ",
					Epsilon: "Ε",
					Zeta: "Ζ",
					Eta: "Η",
					Theta: "Θ",
					Iota: "Ι",
					Kappa: "Κ",
					Lambda: "Λ",
					Mu: "Μ",
					Nu: "Ν",
					Xi: "Ξ",
					Omicron: "Ο",
					Pi: "Π",
					Rho: "Ρ",
					Sigma: "Σ",
					Tau: "Τ",
					Upsilon: "Υ",
					Phi: "Φ",
					Chi: "Χ",
					Psi: "Ψ",
					Omega: "Ω",
					alpha: "α",
					beta: "β",
					gamma: "γ",
					delta: "δ",
					epsilon: "ε",
					zeta: "ζ",
					eta: "η",
					theta: "θ",
					iota: "ι",
					kappa: "κ",
					lambda: "λ",
					mu: "μ",
					nu: "ν",
					xi: "ξ",
					omicron: "ο",
					pi: "π",
					rho: "ρ",
					sigmaf: "ς",
					sigma: "σ",
					tau: "τ",
					upsilon: "υ",
					phi: "φ",
					chi: "χ",
					psi: "ψ",
					omega: "ω",
					thetasym: "ϑ",
					upsih: "ϒ",
					piv: "ϖ",
					ensp: " ",
					emsp: " ",
					thinsp: " ",
					zwnj: "‌",
					zwj: "‍",
					lrm: "‎",
					rlm: "‏",
					ndash: "–",
					mdash: "—",
					lsquo: "‘",
					rsquo: "’",
					sbquo: "‚",
					ldquo: "“",
					rdquo: "”",
					bdquo: "„",
					dagger: "†",
					Dagger: "‡",
					bull: "•",
					hellip: "…",
					permil: "‰",
					prime: "′",
					Prime: "″",
					lsaquo: "‹",
					rsaquo: "›",
					oline: "‾",
					frasl: "⁄",
					euro: "€",
					image: "ℑ",
					weierp: "℘",
					real: "ℜ",
					trade: "™",
					alefsym: "ℵ",
					larr: "←",
					uarr: "↑",
					rarr: "→",
					darr: "↓",
					harr: "↔",
					crarr: "↵",
					lArr: "⇐",
					uArr: "⇑",
					rArr: "⇒",
					dArr: "⇓",
					hArr: "⇔",
					forall: "∀",
					part: "∂",
					exist: "∃",
					empty: "∅",
					nabla: "∇",
					isin: "∈",
					notin: "∉",
					ni: "∋",
					prod: "∏",
					sum: "∑",
					minus: "−",
					lowast: "∗",
					radic: "√",
					prop: "∝",
					infin: "∞",
					ang: "∠",
					and: "∧",
					or: "∨",
					cap: "∩",
					cup: "∪",
					int: "∫",
					there4: "∴",
					sim: "∼",
					cong: "≅",
					asymp: "≈",
					ne: "≠",
					equiv: "≡",
					le: "≤",
					ge: "≥",
					sub: "⊂",
					sup: "⊃",
					nsub: "⊄",
					sube: "⊆",
					supe: "⊇",
					oplus: "⊕",
					otimes: "⊗",
					perp: "⊥",
					sdot: "⋅",
					lceil: "⌈",
					rceil: "⌉",
					lfloor: "⌊",
					rfloor: "⌋",
					loz: "◊",
					spades: "♠",
					clubs: "♣",
					hearts: "♥",
					diams: "♦",
					lang: "⟨",
					rang: "⟩"
				};
			},
			function(module$17, exports$16, __webpack_require__) {
				"use strict";
				Object.defineProperty(exports$16, "__esModule", { value: true });
				var error_handler_1 = __webpack_require__(10);
				var scanner_1 = __webpack_require__(12);
				var token_1 = __webpack_require__(13);
				var Reader = function() {
					function Reader() {
						this.values = [];
						this.curly = this.paren = -1;
					}
					Reader.prototype.beforeFunctionExpression = function(t) {
						return [
							"(",
							"{",
							"[",
							"in",
							"typeof",
							"instanceof",
							"new",
							"return",
							"case",
							"delete",
							"throw",
							"void",
							"=",
							"+=",
							"-=",
							"*=",
							"**=",
							"/=",
							"%=",
							"<<=",
							">>=",
							">>>=",
							"&=",
							"|=",
							"^=",
							",",
							"+",
							"-",
							"*",
							"**",
							"/",
							"%",
							"++",
							"--",
							"<<",
							">>",
							">>>",
							"&",
							"|",
							"^",
							"!",
							"~",
							"&&",
							"||",
							"?",
							":",
							"===",
							"==",
							">=",
							"<=",
							"<",
							">",
							"!=",
							"!=="
						].indexOf(t) >= 0;
					};
					Reader.prototype.isRegexStart = function() {
						var previous = this.values[this.values.length - 1];
						var regex = previous !== null;
						switch (previous) {
							case "this":
							case "]":
								regex = false;
								break;
							case ")":
								var keyword = this.values[this.paren - 1];
								regex = keyword === "if" || keyword === "while" || keyword === "for" || keyword === "with";
								break;
							case "}":
								regex = false;
								if (this.values[this.curly - 3] === "function") {
									var check = this.values[this.curly - 4];
									regex = check ? !this.beforeFunctionExpression(check) : false;
								} else if (this.values[this.curly - 4] === "function") {
									var check = this.values[this.curly - 5];
									regex = check ? !this.beforeFunctionExpression(check) : true;
								}
								break;
							default: break;
						}
						return regex;
					};
					Reader.prototype.push = function(token) {
						if (token.type === 7 || token.type === 4) {
							if (token.value === "{") this.curly = this.values.length;
							else if (token.value === "(") this.paren = this.values.length;
							this.values.push(token.value);
						} else this.values.push(null);
					};
					return Reader;
				}();
				exports$16.Tokenizer = function() {
					function Tokenizer(code, config) {
						this.errorHandler = new error_handler_1.ErrorHandler();
						this.errorHandler.tolerant = config ? typeof config.tolerant === "boolean" && config.tolerant : false;
						this.scanner = new scanner_1.Scanner(code, this.errorHandler);
						this.scanner.trackComment = config ? typeof config.comment === "boolean" && config.comment : false;
						this.trackRange = config ? typeof config.range === "boolean" && config.range : false;
						this.trackLoc = config ? typeof config.loc === "boolean" && config.loc : false;
						this.buffer = [];
						this.reader = new Reader();
					}
					Tokenizer.prototype.errors = function() {
						return this.errorHandler.errors;
					};
					Tokenizer.prototype.getNextToken = function() {
						if (this.buffer.length === 0) {
							var comments = this.scanner.scanComments();
							if (this.scanner.trackComment) for (var i = 0; i < comments.length; ++i) {
								var e = comments[i];
								var value = this.scanner.source.slice(e.slice[0], e.slice[1]);
								var comment = {
									type: e.multiLine ? "BlockComment" : "LineComment",
									value
								};
								if (this.trackRange) comment.range = e.range;
								if (this.trackLoc) comment.loc = e.loc;
								this.buffer.push(comment);
							}
							if (!this.scanner.eof()) {
								var loc = void 0;
								if (this.trackLoc) loc = {
									start: {
										line: this.scanner.lineNumber,
										column: this.scanner.index - this.scanner.lineStart
									},
									end: {}
								};
								var token = this.scanner.source[this.scanner.index] === "/" && this.reader.isRegexStart() ? this.scanner.scanRegExp() : this.scanner.lex();
								this.reader.push(token);
								var entry = {
									type: token_1.TokenName[token.type],
									value: this.scanner.source.slice(token.start, token.end)
								};
								if (this.trackRange) entry.range = [token.start, token.end];
								if (this.trackLoc) {
									loc.end = {
										line: this.scanner.lineNumber,
										column: this.scanner.index - this.scanner.lineStart
									};
									entry.loc = loc;
								}
								if (token.type === 9) entry.regex = {
									pattern: token.pattern,
									flags: token.flags
								};
								this.buffer.push(entry);
							}
						}
						return this.buffer.shift();
					};
					return Tokenizer;
				}();
			}
		]);
	});
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/type/js/function.js
var require_function = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var esprima;
	try {
		esprima = require_esprima();
	} catch (_) {
		if (typeof window !== "undefined") esprima = window.esprima;
	}
	var Type = require_type();
	function resolveJavascriptFunction(data) {
		if (data === null) return false;
		try {
			var source = "(" + data + ")", ast = esprima.parse(source, { range: true });
			if (ast.type !== "Program" || ast.body.length !== 1 || ast.body[0].type !== "ExpressionStatement" || ast.body[0].expression.type !== "ArrowFunctionExpression" && ast.body[0].expression.type !== "FunctionExpression") return false;
			return true;
		} catch (err) {
			return false;
		}
	}
	function constructJavascriptFunction(data) {
		var source = "(" + data + ")", ast = esprima.parse(source, { range: true }), params = [], body;
		if (ast.type !== "Program" || ast.body.length !== 1 || ast.body[0].type !== "ExpressionStatement" || ast.body[0].expression.type !== "ArrowFunctionExpression" && ast.body[0].expression.type !== "FunctionExpression") throw new Error("Failed to resolve function");
		ast.body[0].expression.params.forEach(function(param) {
			params.push(param.name);
		});
		body = ast.body[0].expression.body.range;
		if (ast.body[0].expression.body.type === "BlockStatement") return new Function(params, source.slice(body[0] + 1, body[1] - 1));
		return new Function(params, "return " + source.slice(body[0], body[1]));
	}
	function representJavascriptFunction(object) {
		return object.toString();
	}
	function isFunction(object) {
		return Object.prototype.toString.call(object) === "[object Function]";
	}
	module.exports = new Type("tag:yaml.org,2002:js/function", {
		kind: "scalar",
		resolve: resolveJavascriptFunction,
		construct: constructJavascriptFunction,
		predicate: isFunction,
		represent: representJavascriptFunction
	});
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/schema/default_full.js
var require_default_full = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var Schema = require_schema();
	module.exports = Schema.DEFAULT = new Schema({
		include: [require_default_safe()],
		explicit: [
			require_undefined(),
			require_regexp(),
			require_function()
		]
	});
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/loader.js
var require_loader = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var common = require_common();
	var YAMLException = require_exception();
	var Mark = require_mark();
	var DEFAULT_SAFE_SCHEMA = require_default_safe();
	var DEFAULT_FULL_SCHEMA = require_default_full();
	var _hasOwnProperty = Object.prototype.hasOwnProperty;
	var CONTEXT_FLOW_IN = 1;
	var CONTEXT_FLOW_OUT = 2;
	var CONTEXT_BLOCK_IN = 3;
	var CONTEXT_BLOCK_OUT = 4;
	var CHOMPING_CLIP = 1;
	var CHOMPING_STRIP = 2;
	var CHOMPING_KEEP = 3;
	var PATTERN_NON_PRINTABLE = /[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x84\x86-\x9F\uFFFE\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/;
	var PATTERN_NON_ASCII_LINE_BREAKS = /[\x85\u2028\u2029]/;
	var PATTERN_FLOW_INDICATORS = /[,\[\]\{\}]/;
	var PATTERN_TAG_HANDLE = /^(?:!|!!|![a-z\-]+!)$/i;
	var PATTERN_TAG_URI = /^(?:!|[^,\[\]\{\}])(?:%[0-9a-f]{2}|[0-9a-z\-#;\/\?:@&=\+\$,_\.!~\*'\(\)\[\]])*$/i;
	function _class(obj) {
		return Object.prototype.toString.call(obj);
	}
	function is_EOL(c) {
		return c === 10 || c === 13;
	}
	function is_WHITE_SPACE(c) {
		return c === 9 || c === 32;
	}
	function is_WS_OR_EOL(c) {
		return c === 9 || c === 32 || c === 10 || c === 13;
	}
	function is_FLOW_INDICATOR(c) {
		return c === 44 || c === 91 || c === 93 || c === 123 || c === 125;
	}
	function fromHexCode(c) {
		var lc;
		if (48 <= c && c <= 57) return c - 48;
		lc = c | 32;
		if (97 <= lc && lc <= 102) return lc - 97 + 10;
		return -1;
	}
	function escapedHexLen(c) {
		if (c === 120) return 2;
		if (c === 117) return 4;
		if (c === 85) return 8;
		return 0;
	}
	function fromDecimalCode(c) {
		if (48 <= c && c <= 57) return c - 48;
		return -1;
	}
	function simpleEscapeSequence(c) {
		return c === 48 ? "\0" : c === 97 ? "\x07" : c === 98 ? "\b" : c === 116 ? "	" : c === 9 ? "	" : c === 110 ? "\n" : c === 118 ? "\v" : c === 102 ? "\f" : c === 114 ? "\r" : c === 101 ? "\x1B" : c === 32 ? " " : c === 34 ? "\"" : c === 47 ? "/" : c === 92 ? "\\" : c === 78 ? "" : c === 95 ? "\xA0" : c === 76 ? "\u2028" : c === 80 ? "\u2029" : "";
	}
	function charFromCodepoint(c) {
		if (c <= 65535) return String.fromCharCode(c);
		return String.fromCharCode((c - 65536 >> 10) + 55296, (c - 65536 & 1023) + 56320);
	}
	function setProperty(object, key, value) {
		if (key === "__proto__") Object.defineProperty(object, key, {
			configurable: true,
			enumerable: true,
			writable: true,
			value
		});
		else object[key] = value;
	}
	var simpleEscapeCheck = new Array(256);
	var simpleEscapeMap = new Array(256);
	for (var i = 0; i < 256; i++) {
		simpleEscapeCheck[i] = simpleEscapeSequence(i) ? 1 : 0;
		simpleEscapeMap[i] = simpleEscapeSequence(i);
	}
	function State(input, options) {
		this.input = input;
		this.filename = options["filename"] || null;
		this.schema = options["schema"] || DEFAULT_FULL_SCHEMA;
		this.onWarning = options["onWarning"] || null;
		this.legacy = options["legacy"] || false;
		this.json = options["json"] || false;
		this.listener = options["listener"] || null;
		this.implicitTypes = this.schema.compiledImplicit;
		this.typeMap = this.schema.compiledTypeMap;
		this.length = input.length;
		this.position = 0;
		this.line = 0;
		this.lineStart = 0;
		this.lineIndent = 0;
		this.documents = [];
	}
	function generateError(state, message) {
		return new YAMLException(message, new Mark(state.filename, state.input, state.position, state.line, state.position - state.lineStart));
	}
	function throwError(state, message) {
		throw generateError(state, message);
	}
	function throwWarning(state, message) {
		if (state.onWarning) state.onWarning.call(null, generateError(state, message));
	}
	var directiveHandlers = {
		YAML: function handleYamlDirective(state, name, args) {
			var match, major, minor;
			if (state.version !== null) throwError(state, "duplication of %YAML directive");
			if (args.length !== 1) throwError(state, "YAML directive accepts exactly one argument");
			match = /^([0-9]+)\.([0-9]+)$/.exec(args[0]);
			if (match === null) throwError(state, "ill-formed argument of the YAML directive");
			major = parseInt(match[1], 10);
			minor = parseInt(match[2], 10);
			if (major !== 1) throwError(state, "unacceptable YAML version of the document");
			state.version = args[0];
			state.checkLineBreaks = minor < 2;
			if (minor !== 1 && minor !== 2) throwWarning(state, "unsupported YAML version of the document");
		},
		TAG: function handleTagDirective(state, name, args) {
			var handle, prefix;
			if (args.length !== 2) throwError(state, "TAG directive accepts exactly two arguments");
			handle = args[0];
			prefix = args[1];
			if (!PATTERN_TAG_HANDLE.test(handle)) throwError(state, "ill-formed tag handle (first argument) of the TAG directive");
			if (_hasOwnProperty.call(state.tagMap, handle)) throwError(state, "there is a previously declared suffix for \"" + handle + "\" tag handle");
			if (!PATTERN_TAG_URI.test(prefix)) throwError(state, "ill-formed tag prefix (second argument) of the TAG directive");
			state.tagMap[handle] = prefix;
		}
	};
	function captureSegment(state, start, end, checkJson) {
		var _position, _length, _character, _result;
		if (start < end) {
			_result = state.input.slice(start, end);
			if (checkJson) for (_position = 0, _length = _result.length; _position < _length; _position += 1) {
				_character = _result.charCodeAt(_position);
				if (!(_character === 9 || 32 <= _character && _character <= 1114111)) throwError(state, "expected valid JSON character");
			}
			else if (PATTERN_NON_PRINTABLE.test(_result)) throwError(state, "the stream contains non-printable characters");
			state.result += _result;
		}
	}
	function mergeMappings(state, destination, source, overridableKeys) {
		var sourceKeys, key, index, quantity;
		if (!common.isObject(source)) throwError(state, "cannot merge mappings; the provided source object is unacceptable");
		sourceKeys = Object.keys(source);
		for (index = 0, quantity = sourceKeys.length; index < quantity; index += 1) {
			key = sourceKeys[index];
			if (!_hasOwnProperty.call(destination, key)) {
				setProperty(destination, key, source[key]);
				overridableKeys[key] = true;
			}
		}
	}
	function storeMappingPair(state, _result, overridableKeys, keyTag, keyNode, valueNode, startLine, startPos) {
		var index, quantity;
		if (Array.isArray(keyNode)) {
			keyNode = Array.prototype.slice.call(keyNode);
			for (index = 0, quantity = keyNode.length; index < quantity; index += 1) {
				if (Array.isArray(keyNode[index])) throwError(state, "nested arrays are not supported inside keys");
				if (typeof keyNode === "object" && _class(keyNode[index]) === "[object Object]") keyNode[index] = "[object Object]";
			}
		}
		if (typeof keyNode === "object" && _class(keyNode) === "[object Object]") keyNode = "[object Object]";
		keyNode = String(keyNode);
		if (_result === null) _result = {};
		if (keyTag === "tag:yaml.org,2002:merge") if (Array.isArray(valueNode)) for (index = 0, quantity = valueNode.length; index < quantity; index += 1) mergeMappings(state, _result, valueNode[index], overridableKeys);
		else mergeMappings(state, _result, valueNode, overridableKeys);
		else {
			if (!state.json && !_hasOwnProperty.call(overridableKeys, keyNode) && _hasOwnProperty.call(_result, keyNode)) {
				state.line = startLine || state.line;
				state.position = startPos || state.position;
				throwError(state, "duplicated mapping key");
			}
			setProperty(_result, keyNode, valueNode);
			delete overridableKeys[keyNode];
		}
		return _result;
	}
	function readLineBreak(state) {
		var ch = state.input.charCodeAt(state.position);
		if (ch === 10) state.position++;
		else if (ch === 13) {
			state.position++;
			if (state.input.charCodeAt(state.position) === 10) state.position++;
		} else throwError(state, "a line break is expected");
		state.line += 1;
		state.lineStart = state.position;
	}
	function skipSeparationSpace(state, allowComments, checkIndent) {
		var lineBreaks = 0, ch = state.input.charCodeAt(state.position);
		while (ch !== 0) {
			while (is_WHITE_SPACE(ch)) ch = state.input.charCodeAt(++state.position);
			if (allowComments && ch === 35) do
				ch = state.input.charCodeAt(++state.position);
			while (ch !== 10 && ch !== 13 && ch !== 0);
			if (is_EOL(ch)) {
				readLineBreak(state);
				ch = state.input.charCodeAt(state.position);
				lineBreaks++;
				state.lineIndent = 0;
				while (ch === 32) {
					state.lineIndent++;
					ch = state.input.charCodeAt(++state.position);
				}
			} else break;
		}
		if (checkIndent !== -1 && lineBreaks !== 0 && state.lineIndent < checkIndent) throwWarning(state, "deficient indentation");
		return lineBreaks;
	}
	function testDocumentSeparator(state) {
		var _position = state.position, ch = state.input.charCodeAt(_position);
		if ((ch === 45 || ch === 46) && ch === state.input.charCodeAt(_position + 1) && ch === state.input.charCodeAt(_position + 2)) {
			_position += 3;
			ch = state.input.charCodeAt(_position);
			if (ch === 0 || is_WS_OR_EOL(ch)) return true;
		}
		return false;
	}
	function writeFoldedLines(state, count) {
		if (count === 1) state.result += " ";
		else if (count > 1) state.result += common.repeat("\n", count - 1);
	}
	function readPlainScalar(state, nodeIndent, withinFlowCollection) {
		var preceding, following, captureStart, captureEnd, hasPendingContent, _line, _lineStart, _lineIndent, _kind = state.kind, _result = state.result, ch = state.input.charCodeAt(state.position);
		if (is_WS_OR_EOL(ch) || is_FLOW_INDICATOR(ch) || ch === 35 || ch === 38 || ch === 42 || ch === 33 || ch === 124 || ch === 62 || ch === 39 || ch === 34 || ch === 37 || ch === 64 || ch === 96) return false;
		if (ch === 63 || ch === 45) {
			following = state.input.charCodeAt(state.position + 1);
			if (is_WS_OR_EOL(following) || withinFlowCollection && is_FLOW_INDICATOR(following)) return false;
		}
		state.kind = "scalar";
		state.result = "";
		captureStart = captureEnd = state.position;
		hasPendingContent = false;
		while (ch !== 0) {
			if (ch === 58) {
				following = state.input.charCodeAt(state.position + 1);
				if (is_WS_OR_EOL(following) || withinFlowCollection && is_FLOW_INDICATOR(following)) break;
			} else if (ch === 35) {
				preceding = state.input.charCodeAt(state.position - 1);
				if (is_WS_OR_EOL(preceding)) break;
			} else if (state.position === state.lineStart && testDocumentSeparator(state) || withinFlowCollection && is_FLOW_INDICATOR(ch)) break;
			else if (is_EOL(ch)) {
				_line = state.line;
				_lineStart = state.lineStart;
				_lineIndent = state.lineIndent;
				skipSeparationSpace(state, false, -1);
				if (state.lineIndent >= nodeIndent) {
					hasPendingContent = true;
					ch = state.input.charCodeAt(state.position);
					continue;
				} else {
					state.position = captureEnd;
					state.line = _line;
					state.lineStart = _lineStart;
					state.lineIndent = _lineIndent;
					break;
				}
			}
			if (hasPendingContent) {
				captureSegment(state, captureStart, captureEnd, false);
				writeFoldedLines(state, state.line - _line);
				captureStart = captureEnd = state.position;
				hasPendingContent = false;
			}
			if (!is_WHITE_SPACE(ch)) captureEnd = state.position + 1;
			ch = state.input.charCodeAt(++state.position);
		}
		captureSegment(state, captureStart, captureEnd, false);
		if (state.result) return true;
		state.kind = _kind;
		state.result = _result;
		return false;
	}
	function readSingleQuotedScalar(state, nodeIndent) {
		var ch = state.input.charCodeAt(state.position), captureStart, captureEnd;
		if (ch !== 39) return false;
		state.kind = "scalar";
		state.result = "";
		state.position++;
		captureStart = captureEnd = state.position;
		while ((ch = state.input.charCodeAt(state.position)) !== 0) if (ch === 39) {
			captureSegment(state, captureStart, state.position, true);
			ch = state.input.charCodeAt(++state.position);
			if (ch === 39) {
				captureStart = state.position;
				state.position++;
				captureEnd = state.position;
			} else return true;
		} else if (is_EOL(ch)) {
			captureSegment(state, captureStart, captureEnd, true);
			writeFoldedLines(state, skipSeparationSpace(state, false, nodeIndent));
			captureStart = captureEnd = state.position;
		} else if (state.position === state.lineStart && testDocumentSeparator(state)) throwError(state, "unexpected end of the document within a single quoted scalar");
		else {
			state.position++;
			captureEnd = state.position;
		}
		throwError(state, "unexpected end of the stream within a single quoted scalar");
	}
	function readDoubleQuotedScalar(state, nodeIndent) {
		var captureStart, captureEnd, hexLength, hexResult, tmp, ch = state.input.charCodeAt(state.position);
		if (ch !== 34) return false;
		state.kind = "scalar";
		state.result = "";
		state.position++;
		captureStart = captureEnd = state.position;
		while ((ch = state.input.charCodeAt(state.position)) !== 0) if (ch === 34) {
			captureSegment(state, captureStart, state.position, true);
			state.position++;
			return true;
		} else if (ch === 92) {
			captureSegment(state, captureStart, state.position, true);
			ch = state.input.charCodeAt(++state.position);
			if (is_EOL(ch)) skipSeparationSpace(state, false, nodeIndent);
			else if (ch < 256 && simpleEscapeCheck[ch]) {
				state.result += simpleEscapeMap[ch];
				state.position++;
			} else if ((tmp = escapedHexLen(ch)) > 0) {
				hexLength = tmp;
				hexResult = 0;
				for (; hexLength > 0; hexLength--) {
					ch = state.input.charCodeAt(++state.position);
					if ((tmp = fromHexCode(ch)) >= 0) hexResult = (hexResult << 4) + tmp;
					else throwError(state, "expected hexadecimal character");
				}
				state.result += charFromCodepoint(hexResult);
				state.position++;
			} else throwError(state, "unknown escape sequence");
			captureStart = captureEnd = state.position;
		} else if (is_EOL(ch)) {
			captureSegment(state, captureStart, captureEnd, true);
			writeFoldedLines(state, skipSeparationSpace(state, false, nodeIndent));
			captureStart = captureEnd = state.position;
		} else if (state.position === state.lineStart && testDocumentSeparator(state)) throwError(state, "unexpected end of the document within a double quoted scalar");
		else {
			state.position++;
			captureEnd = state.position;
		}
		throwError(state, "unexpected end of the stream within a double quoted scalar");
	}
	function readFlowCollection(state, nodeIndent) {
		var readNext = true, _line, _tag = state.tag, _result, _anchor = state.anchor, following, terminator, isPair, isExplicitPair, isMapping, overridableKeys = {}, keyNode, keyTag, valueNode, ch = state.input.charCodeAt(state.position);
		if (ch === 91) {
			terminator = 93;
			isMapping = false;
			_result = [];
		} else if (ch === 123) {
			terminator = 125;
			isMapping = true;
			_result = {};
		} else return false;
		if (state.anchor !== null) state.anchorMap[state.anchor] = _result;
		ch = state.input.charCodeAt(++state.position);
		while (ch !== 0) {
			skipSeparationSpace(state, true, nodeIndent);
			ch = state.input.charCodeAt(state.position);
			if (ch === terminator) {
				state.position++;
				state.tag = _tag;
				state.anchor = _anchor;
				state.kind = isMapping ? "mapping" : "sequence";
				state.result = _result;
				return true;
			} else if (!readNext) throwError(state, "missed comma between flow collection entries");
			keyTag = keyNode = valueNode = null;
			isPair = isExplicitPair = false;
			if (ch === 63) {
				following = state.input.charCodeAt(state.position + 1);
				if (is_WS_OR_EOL(following)) {
					isPair = isExplicitPair = true;
					state.position++;
					skipSeparationSpace(state, true, nodeIndent);
				}
			}
			_line = state.line;
			composeNode(state, nodeIndent, CONTEXT_FLOW_IN, false, true);
			keyTag = state.tag;
			keyNode = state.result;
			skipSeparationSpace(state, true, nodeIndent);
			ch = state.input.charCodeAt(state.position);
			if ((isExplicitPair || state.line === _line) && ch === 58) {
				isPair = true;
				ch = state.input.charCodeAt(++state.position);
				skipSeparationSpace(state, true, nodeIndent);
				composeNode(state, nodeIndent, CONTEXT_FLOW_IN, false, true);
				valueNode = state.result;
			}
			if (isMapping) storeMappingPair(state, _result, overridableKeys, keyTag, keyNode, valueNode);
			else if (isPair) _result.push(storeMappingPair(state, null, overridableKeys, keyTag, keyNode, valueNode));
			else _result.push(keyNode);
			skipSeparationSpace(state, true, nodeIndent);
			ch = state.input.charCodeAt(state.position);
			if (ch === 44) {
				readNext = true;
				ch = state.input.charCodeAt(++state.position);
			} else readNext = false;
		}
		throwError(state, "unexpected end of the stream within a flow collection");
	}
	function readBlockScalar(state, nodeIndent) {
		var captureStart, folding, chomping = CHOMPING_CLIP, didReadContent = false, detectedIndent = false, textIndent = nodeIndent, emptyLines = 0, atMoreIndented = false, tmp, ch = state.input.charCodeAt(state.position);
		if (ch === 124) folding = false;
		else if (ch === 62) folding = true;
		else return false;
		state.kind = "scalar";
		state.result = "";
		while (ch !== 0) {
			ch = state.input.charCodeAt(++state.position);
			if (ch === 43 || ch === 45) if (CHOMPING_CLIP === chomping) chomping = ch === 43 ? CHOMPING_KEEP : CHOMPING_STRIP;
			else throwError(state, "repeat of a chomping mode identifier");
			else if ((tmp = fromDecimalCode(ch)) >= 0) if (tmp === 0) throwError(state, "bad explicit indentation width of a block scalar; it cannot be less than one");
			else if (!detectedIndent) {
				textIndent = nodeIndent + tmp - 1;
				detectedIndent = true;
			} else throwError(state, "repeat of an indentation width identifier");
			else break;
		}
		if (is_WHITE_SPACE(ch)) {
			do
				ch = state.input.charCodeAt(++state.position);
			while (is_WHITE_SPACE(ch));
			if (ch === 35) do
				ch = state.input.charCodeAt(++state.position);
			while (!is_EOL(ch) && ch !== 0);
		}
		while (ch !== 0) {
			readLineBreak(state);
			state.lineIndent = 0;
			ch = state.input.charCodeAt(state.position);
			while ((!detectedIndent || state.lineIndent < textIndent) && ch === 32) {
				state.lineIndent++;
				ch = state.input.charCodeAt(++state.position);
			}
			if (!detectedIndent && state.lineIndent > textIndent) textIndent = state.lineIndent;
			if (is_EOL(ch)) {
				emptyLines++;
				continue;
			}
			if (state.lineIndent < textIndent) {
				if (chomping === CHOMPING_KEEP) state.result += common.repeat("\n", didReadContent ? 1 + emptyLines : emptyLines);
				else if (chomping === CHOMPING_CLIP) {
					if (didReadContent) state.result += "\n";
				}
				break;
			}
			if (folding) if (is_WHITE_SPACE(ch)) {
				atMoreIndented = true;
				state.result += common.repeat("\n", didReadContent ? 1 + emptyLines : emptyLines);
			} else if (atMoreIndented) {
				atMoreIndented = false;
				state.result += common.repeat("\n", emptyLines + 1);
			} else if (emptyLines === 0) {
				if (didReadContent) state.result += " ";
			} else state.result += common.repeat("\n", emptyLines);
			else state.result += common.repeat("\n", didReadContent ? 1 + emptyLines : emptyLines);
			didReadContent = true;
			detectedIndent = true;
			emptyLines = 0;
			captureStart = state.position;
			while (!is_EOL(ch) && ch !== 0) ch = state.input.charCodeAt(++state.position);
			captureSegment(state, captureStart, state.position, false);
		}
		return true;
	}
	function readBlockSequence(state, nodeIndent) {
		var _line, _tag = state.tag, _anchor = state.anchor, _result = [], following, detected = false, ch;
		if (state.anchor !== null) state.anchorMap[state.anchor] = _result;
		ch = state.input.charCodeAt(state.position);
		while (ch !== 0) {
			if (ch !== 45) break;
			following = state.input.charCodeAt(state.position + 1);
			if (!is_WS_OR_EOL(following)) break;
			detected = true;
			state.position++;
			if (skipSeparationSpace(state, true, -1)) {
				if (state.lineIndent <= nodeIndent) {
					_result.push(null);
					ch = state.input.charCodeAt(state.position);
					continue;
				}
			}
			_line = state.line;
			composeNode(state, nodeIndent, CONTEXT_BLOCK_IN, false, true);
			_result.push(state.result);
			skipSeparationSpace(state, true, -1);
			ch = state.input.charCodeAt(state.position);
			if ((state.line === _line || state.lineIndent > nodeIndent) && ch !== 0) throwError(state, "bad indentation of a sequence entry");
			else if (state.lineIndent < nodeIndent) break;
		}
		if (detected) {
			state.tag = _tag;
			state.anchor = _anchor;
			state.kind = "sequence";
			state.result = _result;
			return true;
		}
		return false;
	}
	function readBlockMapping(state, nodeIndent, flowIndent) {
		var following, allowCompact, _line, _pos, _tag = state.tag, _anchor = state.anchor, _result = {}, overridableKeys = {}, keyTag = null, keyNode = null, valueNode = null, atExplicitKey = false, detected = false, ch;
		if (state.anchor !== null) state.anchorMap[state.anchor] = _result;
		ch = state.input.charCodeAt(state.position);
		while (ch !== 0) {
			following = state.input.charCodeAt(state.position + 1);
			_line = state.line;
			_pos = state.position;
			if ((ch === 63 || ch === 58) && is_WS_OR_EOL(following)) {
				if (ch === 63) {
					if (atExplicitKey) {
						storeMappingPair(state, _result, overridableKeys, keyTag, keyNode, null);
						keyTag = keyNode = valueNode = null;
					}
					detected = true;
					atExplicitKey = true;
					allowCompact = true;
				} else if (atExplicitKey) {
					atExplicitKey = false;
					allowCompact = true;
				} else throwError(state, "incomplete explicit mapping pair; a key node is missed; or followed by a non-tabulated empty line");
				state.position += 1;
				ch = following;
			} else if (composeNode(state, flowIndent, CONTEXT_FLOW_OUT, false, true)) if (state.line === _line) {
				ch = state.input.charCodeAt(state.position);
				while (is_WHITE_SPACE(ch)) ch = state.input.charCodeAt(++state.position);
				if (ch === 58) {
					ch = state.input.charCodeAt(++state.position);
					if (!is_WS_OR_EOL(ch)) throwError(state, "a whitespace character is expected after the key-value separator within a block mapping");
					if (atExplicitKey) {
						storeMappingPair(state, _result, overridableKeys, keyTag, keyNode, null);
						keyTag = keyNode = valueNode = null;
					}
					detected = true;
					atExplicitKey = false;
					allowCompact = false;
					keyTag = state.tag;
					keyNode = state.result;
				} else if (detected) throwError(state, "can not read an implicit mapping pair; a colon is missed");
				else {
					state.tag = _tag;
					state.anchor = _anchor;
					return true;
				}
			} else if (detected) throwError(state, "can not read a block mapping entry; a multiline key may not be an implicit key");
			else {
				state.tag = _tag;
				state.anchor = _anchor;
				return true;
			}
			else break;
			if (state.line === _line || state.lineIndent > nodeIndent) {
				if (composeNode(state, nodeIndent, CONTEXT_BLOCK_OUT, true, allowCompact)) if (atExplicitKey) keyNode = state.result;
				else valueNode = state.result;
				if (!atExplicitKey) {
					storeMappingPair(state, _result, overridableKeys, keyTag, keyNode, valueNode, _line, _pos);
					keyTag = keyNode = valueNode = null;
				}
				skipSeparationSpace(state, true, -1);
				ch = state.input.charCodeAt(state.position);
			}
			if (state.lineIndent > nodeIndent && ch !== 0) throwError(state, "bad indentation of a mapping entry");
			else if (state.lineIndent < nodeIndent) break;
		}
		if (atExplicitKey) storeMappingPair(state, _result, overridableKeys, keyTag, keyNode, null);
		if (detected) {
			state.tag = _tag;
			state.anchor = _anchor;
			state.kind = "mapping";
			state.result = _result;
		}
		return detected;
	}
	function readTagProperty(state) {
		var _position, isVerbatim = false, isNamed = false, tagHandle, tagName, ch = state.input.charCodeAt(state.position);
		if (ch !== 33) return false;
		if (state.tag !== null) throwError(state, "duplication of a tag property");
		ch = state.input.charCodeAt(++state.position);
		if (ch === 60) {
			isVerbatim = true;
			ch = state.input.charCodeAt(++state.position);
		} else if (ch === 33) {
			isNamed = true;
			tagHandle = "!!";
			ch = state.input.charCodeAt(++state.position);
		} else tagHandle = "!";
		_position = state.position;
		if (isVerbatim) {
			do
				ch = state.input.charCodeAt(++state.position);
			while (ch !== 0 && ch !== 62);
			if (state.position < state.length) {
				tagName = state.input.slice(_position, state.position);
				ch = state.input.charCodeAt(++state.position);
			} else throwError(state, "unexpected end of the stream within a verbatim tag");
		} else {
			while (ch !== 0 && !is_WS_OR_EOL(ch)) {
				if (ch === 33) if (!isNamed) {
					tagHandle = state.input.slice(_position - 1, state.position + 1);
					if (!PATTERN_TAG_HANDLE.test(tagHandle)) throwError(state, "named tag handle cannot contain such characters");
					isNamed = true;
					_position = state.position + 1;
				} else throwError(state, "tag suffix cannot contain exclamation marks");
				ch = state.input.charCodeAt(++state.position);
			}
			tagName = state.input.slice(_position, state.position);
			if (PATTERN_FLOW_INDICATORS.test(tagName)) throwError(state, "tag suffix cannot contain flow indicator characters");
		}
		if (tagName && !PATTERN_TAG_URI.test(tagName)) throwError(state, "tag name cannot contain such characters: " + tagName);
		if (isVerbatim) state.tag = tagName;
		else if (_hasOwnProperty.call(state.tagMap, tagHandle)) state.tag = state.tagMap[tagHandle] + tagName;
		else if (tagHandle === "!") state.tag = "!" + tagName;
		else if (tagHandle === "!!") state.tag = "tag:yaml.org,2002:" + tagName;
		else throwError(state, "undeclared tag handle \"" + tagHandle + "\"");
		return true;
	}
	function readAnchorProperty(state) {
		var _position, ch = state.input.charCodeAt(state.position);
		if (ch !== 38) return false;
		if (state.anchor !== null) throwError(state, "duplication of an anchor property");
		ch = state.input.charCodeAt(++state.position);
		_position = state.position;
		while (ch !== 0 && !is_WS_OR_EOL(ch) && !is_FLOW_INDICATOR(ch)) ch = state.input.charCodeAt(++state.position);
		if (state.position === _position) throwError(state, "name of an anchor node must contain at least one character");
		state.anchor = state.input.slice(_position, state.position);
		return true;
	}
	function readAlias(state) {
		var _position, alias, ch = state.input.charCodeAt(state.position);
		if (ch !== 42) return false;
		ch = state.input.charCodeAt(++state.position);
		_position = state.position;
		while (ch !== 0 && !is_WS_OR_EOL(ch) && !is_FLOW_INDICATOR(ch)) ch = state.input.charCodeAt(++state.position);
		if (state.position === _position) throwError(state, "name of an alias node must contain at least one character");
		alias = state.input.slice(_position, state.position);
		if (!_hasOwnProperty.call(state.anchorMap, alias)) throwError(state, "unidentified alias \"" + alias + "\"");
		state.result = state.anchorMap[alias];
		skipSeparationSpace(state, true, -1);
		return true;
	}
	function composeNode(state, parentIndent, nodeContext, allowToSeek, allowCompact) {
		var allowBlockStyles, allowBlockScalars, allowBlockCollections, indentStatus = 1, atNewLine = false, hasContent = false, typeIndex, typeQuantity, type, flowIndent, blockIndent;
		if (state.listener !== null) state.listener("open", state);
		state.tag = null;
		state.anchor = null;
		state.kind = null;
		state.result = null;
		allowBlockStyles = allowBlockScalars = allowBlockCollections = CONTEXT_BLOCK_OUT === nodeContext || CONTEXT_BLOCK_IN === nodeContext;
		if (allowToSeek) {
			if (skipSeparationSpace(state, true, -1)) {
				atNewLine = true;
				if (state.lineIndent > parentIndent) indentStatus = 1;
				else if (state.lineIndent === parentIndent) indentStatus = 0;
				else if (state.lineIndent < parentIndent) indentStatus = -1;
			}
		}
		if (indentStatus === 1) while (readTagProperty(state) || readAnchorProperty(state)) if (skipSeparationSpace(state, true, -1)) {
			atNewLine = true;
			allowBlockCollections = allowBlockStyles;
			if (state.lineIndent > parentIndent) indentStatus = 1;
			else if (state.lineIndent === parentIndent) indentStatus = 0;
			else if (state.lineIndent < parentIndent) indentStatus = -1;
		} else allowBlockCollections = false;
		if (allowBlockCollections) allowBlockCollections = atNewLine || allowCompact;
		if (indentStatus === 1 || CONTEXT_BLOCK_OUT === nodeContext) {
			if (CONTEXT_FLOW_IN === nodeContext || CONTEXT_FLOW_OUT === nodeContext) flowIndent = parentIndent;
			else flowIndent = parentIndent + 1;
			blockIndent = state.position - state.lineStart;
			if (indentStatus === 1) if (allowBlockCollections && (readBlockSequence(state, blockIndent) || readBlockMapping(state, blockIndent, flowIndent)) || readFlowCollection(state, flowIndent)) hasContent = true;
			else {
				if (allowBlockScalars && readBlockScalar(state, flowIndent) || readSingleQuotedScalar(state, flowIndent) || readDoubleQuotedScalar(state, flowIndent)) hasContent = true;
				else if (readAlias(state)) {
					hasContent = true;
					if (state.tag !== null || state.anchor !== null) throwError(state, "alias node should not have any properties");
				} else if (readPlainScalar(state, flowIndent, CONTEXT_FLOW_IN === nodeContext)) {
					hasContent = true;
					if (state.tag === null) state.tag = "?";
				}
				if (state.anchor !== null) state.anchorMap[state.anchor] = state.result;
			}
			else if (indentStatus === 0) hasContent = allowBlockCollections && readBlockSequence(state, blockIndent);
		}
		if (state.tag !== null && state.tag !== "!") if (state.tag === "?") {
			if (state.result !== null && state.kind !== "scalar") throwError(state, "unacceptable node kind for !<?> tag; it should be \"scalar\", not \"" + state.kind + "\"");
			for (typeIndex = 0, typeQuantity = state.implicitTypes.length; typeIndex < typeQuantity; typeIndex += 1) {
				type = state.implicitTypes[typeIndex];
				if (type.resolve(state.result)) {
					state.result = type.construct(state.result);
					state.tag = type.tag;
					if (state.anchor !== null) state.anchorMap[state.anchor] = state.result;
					break;
				}
			}
		} else if (_hasOwnProperty.call(state.typeMap[state.kind || "fallback"], state.tag)) {
			type = state.typeMap[state.kind || "fallback"][state.tag];
			if (state.result !== null && type.kind !== state.kind) throwError(state, "unacceptable node kind for !<" + state.tag + "> tag; it should be \"" + type.kind + "\", not \"" + state.kind + "\"");
			if (!type.resolve(state.result)) throwError(state, "cannot resolve a node with !<" + state.tag + "> explicit tag");
			else {
				state.result = type.construct(state.result);
				if (state.anchor !== null) state.anchorMap[state.anchor] = state.result;
			}
		} else throwError(state, "unknown tag !<" + state.tag + ">");
		if (state.listener !== null) state.listener("close", state);
		return state.tag !== null || state.anchor !== null || hasContent;
	}
	function readDocument(state) {
		var documentStart = state.position, _position, directiveName, directiveArgs, hasDirectives = false, ch;
		state.version = null;
		state.checkLineBreaks = state.legacy;
		state.tagMap = {};
		state.anchorMap = {};
		while ((ch = state.input.charCodeAt(state.position)) !== 0) {
			skipSeparationSpace(state, true, -1);
			ch = state.input.charCodeAt(state.position);
			if (state.lineIndent > 0 || ch !== 37) break;
			hasDirectives = true;
			ch = state.input.charCodeAt(++state.position);
			_position = state.position;
			while (ch !== 0 && !is_WS_OR_EOL(ch)) ch = state.input.charCodeAt(++state.position);
			directiveName = state.input.slice(_position, state.position);
			directiveArgs = [];
			if (directiveName.length < 1) throwError(state, "directive name must not be less than one character in length");
			while (ch !== 0) {
				while (is_WHITE_SPACE(ch)) ch = state.input.charCodeAt(++state.position);
				if (ch === 35) {
					do
						ch = state.input.charCodeAt(++state.position);
					while (ch !== 0 && !is_EOL(ch));
					break;
				}
				if (is_EOL(ch)) break;
				_position = state.position;
				while (ch !== 0 && !is_WS_OR_EOL(ch)) ch = state.input.charCodeAt(++state.position);
				directiveArgs.push(state.input.slice(_position, state.position));
			}
			if (ch !== 0) readLineBreak(state);
			if (_hasOwnProperty.call(directiveHandlers, directiveName)) directiveHandlers[directiveName](state, directiveName, directiveArgs);
			else throwWarning(state, "unknown document directive \"" + directiveName + "\"");
		}
		skipSeparationSpace(state, true, -1);
		if (state.lineIndent === 0 && state.input.charCodeAt(state.position) === 45 && state.input.charCodeAt(state.position + 1) === 45 && state.input.charCodeAt(state.position + 2) === 45) {
			state.position += 3;
			skipSeparationSpace(state, true, -1);
		} else if (hasDirectives) throwError(state, "directives end mark is expected");
		composeNode(state, state.lineIndent - 1, CONTEXT_BLOCK_OUT, false, true);
		skipSeparationSpace(state, true, -1);
		if (state.checkLineBreaks && PATTERN_NON_ASCII_LINE_BREAKS.test(state.input.slice(documentStart, state.position))) throwWarning(state, "non-ASCII line breaks are interpreted as content");
		state.documents.push(state.result);
		if (state.position === state.lineStart && testDocumentSeparator(state)) {
			if (state.input.charCodeAt(state.position) === 46) {
				state.position += 3;
				skipSeparationSpace(state, true, -1);
			}
			return;
		}
		if (state.position < state.length - 1) throwError(state, "end of the stream or a document separator is expected");
		else return;
	}
	function loadDocuments(input, options) {
		input = String(input);
		options = options || {};
		if (input.length !== 0) {
			if (input.charCodeAt(input.length - 1) !== 10 && input.charCodeAt(input.length - 1) !== 13) input += "\n";
			if (input.charCodeAt(0) === 65279) input = input.slice(1);
		}
		var state = new State(input, options);
		var nullpos = input.indexOf("\0");
		if (nullpos !== -1) {
			state.position = nullpos;
			throwError(state, "null byte is not allowed in input");
		}
		state.input += "\0";
		while (state.input.charCodeAt(state.position) === 32) {
			state.lineIndent += 1;
			state.position += 1;
		}
		while (state.position < state.length - 1) readDocument(state);
		return state.documents;
	}
	function loadAll(input, iterator, options) {
		if (iterator !== null && typeof iterator === "object" && typeof options === "undefined") {
			options = iterator;
			iterator = null;
		}
		var documents = loadDocuments(input, options);
		if (typeof iterator !== "function") return documents;
		for (var index = 0, length = documents.length; index < length; index += 1) iterator(documents[index]);
	}
	function load(input, options) {
		var documents = loadDocuments(input, options);
		if (documents.length === 0) return;
		else if (documents.length === 1) return documents[0];
		throw new YAMLException("expected a single document in the stream, but found more");
	}
	function safeLoadAll(input, iterator, options) {
		if (typeof iterator === "object" && iterator !== null && typeof options === "undefined") {
			options = iterator;
			iterator = null;
		}
		return loadAll(input, iterator, common.extend({ schema: DEFAULT_SAFE_SCHEMA }, options));
	}
	function safeLoad(input, options) {
		return load(input, common.extend({ schema: DEFAULT_SAFE_SCHEMA }, options));
	}
	module.exports.loadAll = loadAll;
	module.exports.load = load;
	module.exports.safeLoadAll = safeLoadAll;
	module.exports.safeLoad = safeLoad;
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml/dumper.js
var require_dumper = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var common = require_common();
	var YAMLException = require_exception();
	var DEFAULT_FULL_SCHEMA = require_default_full();
	var DEFAULT_SAFE_SCHEMA = require_default_safe();
	var _toString = Object.prototype.toString;
	var _hasOwnProperty = Object.prototype.hasOwnProperty;
	var CHAR_TAB = 9;
	var CHAR_LINE_FEED = 10;
	var CHAR_CARRIAGE_RETURN = 13;
	var CHAR_SPACE = 32;
	var CHAR_EXCLAMATION = 33;
	var CHAR_DOUBLE_QUOTE = 34;
	var CHAR_SHARP = 35;
	var CHAR_PERCENT = 37;
	var CHAR_AMPERSAND = 38;
	var CHAR_SINGLE_QUOTE = 39;
	var CHAR_ASTERISK = 42;
	var CHAR_COMMA = 44;
	var CHAR_MINUS = 45;
	var CHAR_COLON = 58;
	var CHAR_EQUALS = 61;
	var CHAR_GREATER_THAN = 62;
	var CHAR_QUESTION = 63;
	var CHAR_COMMERCIAL_AT = 64;
	var CHAR_LEFT_SQUARE_BRACKET = 91;
	var CHAR_RIGHT_SQUARE_BRACKET = 93;
	var CHAR_GRAVE_ACCENT = 96;
	var CHAR_LEFT_CURLY_BRACKET = 123;
	var CHAR_VERTICAL_LINE = 124;
	var CHAR_RIGHT_CURLY_BRACKET = 125;
	var ESCAPE_SEQUENCES = {};
	ESCAPE_SEQUENCES[0] = "\\0";
	ESCAPE_SEQUENCES[7] = "\\a";
	ESCAPE_SEQUENCES[8] = "\\b";
	ESCAPE_SEQUENCES[9] = "\\t";
	ESCAPE_SEQUENCES[10] = "\\n";
	ESCAPE_SEQUENCES[11] = "\\v";
	ESCAPE_SEQUENCES[12] = "\\f";
	ESCAPE_SEQUENCES[13] = "\\r";
	ESCAPE_SEQUENCES[27] = "\\e";
	ESCAPE_SEQUENCES[34] = "\\\"";
	ESCAPE_SEQUENCES[92] = "\\\\";
	ESCAPE_SEQUENCES[133] = "\\N";
	ESCAPE_SEQUENCES[160] = "\\_";
	ESCAPE_SEQUENCES[8232] = "\\L";
	ESCAPE_SEQUENCES[8233] = "\\P";
	var DEPRECATED_BOOLEANS_SYNTAX = [
		"y",
		"Y",
		"yes",
		"Yes",
		"YES",
		"on",
		"On",
		"ON",
		"n",
		"N",
		"no",
		"No",
		"NO",
		"off",
		"Off",
		"OFF"
	];
	function compileStyleMap(schema, map) {
		var result, keys, index, length, tag, style, type;
		if (map === null) return {};
		result = {};
		keys = Object.keys(map);
		for (index = 0, length = keys.length; index < length; index += 1) {
			tag = keys[index];
			style = String(map[tag]);
			if (tag.slice(0, 2) === "!!") tag = "tag:yaml.org,2002:" + tag.slice(2);
			type = schema.compiledTypeMap["fallback"][tag];
			if (type && _hasOwnProperty.call(type.styleAliases, style)) style = type.styleAliases[style];
			result[tag] = style;
		}
		return result;
	}
	function encodeHex(character) {
		var string = character.toString(16).toUpperCase(), handle, length;
		if (character <= 255) {
			handle = "x";
			length = 2;
		} else if (character <= 65535) {
			handle = "u";
			length = 4;
		} else if (character <= 4294967295) {
			handle = "U";
			length = 8;
		} else throw new YAMLException("code point within a string may not be greater than 0xFFFFFFFF");
		return "\\" + handle + common.repeat("0", length - string.length) + string;
	}
	function State(options) {
		this.schema = options["schema"] || DEFAULT_FULL_SCHEMA;
		this.indent = Math.max(1, options["indent"] || 2);
		this.noArrayIndent = options["noArrayIndent"] || false;
		this.skipInvalid = options["skipInvalid"] || false;
		this.flowLevel = common.isNothing(options["flowLevel"]) ? -1 : options["flowLevel"];
		this.styleMap = compileStyleMap(this.schema, options["styles"] || null);
		this.sortKeys = options["sortKeys"] || false;
		this.lineWidth = options["lineWidth"] || 80;
		this.noRefs = options["noRefs"] || false;
		this.noCompatMode = options["noCompatMode"] || false;
		this.condenseFlow = options["condenseFlow"] || false;
		this.implicitTypes = this.schema.compiledImplicit;
		this.explicitTypes = this.schema.compiledExplicit;
		this.tag = null;
		this.result = "";
		this.duplicates = [];
		this.usedDuplicates = null;
	}
	function indentString(string, spaces) {
		var ind = common.repeat(" ", spaces), position = 0, next = -1, result = "", line, length = string.length;
		while (position < length) {
			next = string.indexOf("\n", position);
			if (next === -1) {
				line = string.slice(position);
				position = length;
			} else {
				line = string.slice(position, next + 1);
				position = next + 1;
			}
			if (line.length && line !== "\n") result += ind;
			result += line;
		}
		return result;
	}
	function generateNextLine(state, level) {
		return "\n" + common.repeat(" ", state.indent * level);
	}
	function testImplicitResolving(state, str) {
		var index, length, type;
		for (index = 0, length = state.implicitTypes.length; index < length; index += 1) {
			type = state.implicitTypes[index];
			if (type.resolve(str)) return true;
		}
		return false;
	}
	function isWhitespace(c) {
		return c === CHAR_SPACE || c === CHAR_TAB;
	}
	function isPrintable(c) {
		return 32 <= c && c <= 126 || 161 <= c && c <= 55295 && c !== 8232 && c !== 8233 || 57344 <= c && c <= 65533 && c !== 65279 || 65536 <= c && c <= 1114111;
	}
	function isNsChar(c) {
		return isPrintable(c) && !isWhitespace(c) && c !== 65279 && c !== CHAR_CARRIAGE_RETURN && c !== CHAR_LINE_FEED;
	}
	function isPlainSafe(c, prev) {
		return isPrintable(c) && c !== 65279 && c !== CHAR_COMMA && c !== CHAR_LEFT_SQUARE_BRACKET && c !== CHAR_RIGHT_SQUARE_BRACKET && c !== CHAR_LEFT_CURLY_BRACKET && c !== CHAR_RIGHT_CURLY_BRACKET && c !== CHAR_COLON && (c !== CHAR_SHARP || prev && isNsChar(prev));
	}
	function isPlainSafeFirst(c) {
		return isPrintable(c) && c !== 65279 && !isWhitespace(c) && c !== CHAR_MINUS && c !== CHAR_QUESTION && c !== CHAR_COLON && c !== CHAR_COMMA && c !== CHAR_LEFT_SQUARE_BRACKET && c !== CHAR_RIGHT_SQUARE_BRACKET && c !== CHAR_LEFT_CURLY_BRACKET && c !== CHAR_RIGHT_CURLY_BRACKET && c !== CHAR_SHARP && c !== CHAR_AMPERSAND && c !== CHAR_ASTERISK && c !== CHAR_EXCLAMATION && c !== CHAR_VERTICAL_LINE && c !== CHAR_EQUALS && c !== CHAR_GREATER_THAN && c !== CHAR_SINGLE_QUOTE && c !== CHAR_DOUBLE_QUOTE && c !== CHAR_PERCENT && c !== CHAR_COMMERCIAL_AT && c !== CHAR_GRAVE_ACCENT;
	}
	function needIndentIndicator(string) {
		return /^\n* /.test(string);
	}
	var STYLE_PLAIN = 1, STYLE_SINGLE = 2, STYLE_LITERAL = 3, STYLE_FOLDED = 4, STYLE_DOUBLE = 5;
	function chooseScalarStyle(string, singleLineOnly, indentPerLevel, lineWidth, testAmbiguousType) {
		var i;
		var char, prev_char;
		var hasLineBreak = false;
		var hasFoldableLine = false;
		var shouldTrackWidth = lineWidth !== -1;
		var previousLineBreak = -1;
		var plain = isPlainSafeFirst(string.charCodeAt(0)) && !isWhitespace(string.charCodeAt(string.length - 1));
		if (singleLineOnly) for (i = 0; i < string.length; i++) {
			char = string.charCodeAt(i);
			if (!isPrintable(char)) return STYLE_DOUBLE;
			prev_char = i > 0 ? string.charCodeAt(i - 1) : null;
			plain = plain && isPlainSafe(char, prev_char);
		}
		else {
			for (i = 0; i < string.length; i++) {
				char = string.charCodeAt(i);
				if (char === CHAR_LINE_FEED) {
					hasLineBreak = true;
					if (shouldTrackWidth) {
						hasFoldableLine = hasFoldableLine || i - previousLineBreak - 1 > lineWidth && string[previousLineBreak + 1] !== " ";
						previousLineBreak = i;
					}
				} else if (!isPrintable(char)) return STYLE_DOUBLE;
				prev_char = i > 0 ? string.charCodeAt(i - 1) : null;
				plain = plain && isPlainSafe(char, prev_char);
			}
			hasFoldableLine = hasFoldableLine || shouldTrackWidth && i - previousLineBreak - 1 > lineWidth && string[previousLineBreak + 1] !== " ";
		}
		if (!hasLineBreak && !hasFoldableLine) return plain && !testAmbiguousType(string) ? STYLE_PLAIN : STYLE_SINGLE;
		if (indentPerLevel > 9 && needIndentIndicator(string)) return STYLE_DOUBLE;
		return hasFoldableLine ? STYLE_FOLDED : STYLE_LITERAL;
	}
	function writeScalar(state, string, level, iskey) {
		state.dump = function() {
			if (string.length === 0) return "''";
			if (!state.noCompatMode && DEPRECATED_BOOLEANS_SYNTAX.indexOf(string) !== -1) return "'" + string + "'";
			var indent = state.indent * Math.max(1, level);
			var lineWidth = state.lineWidth === -1 ? -1 : Math.max(Math.min(state.lineWidth, 40), state.lineWidth - indent);
			var singleLineOnly = iskey || state.flowLevel > -1 && level >= state.flowLevel;
			function testAmbiguity(string) {
				return testImplicitResolving(state, string);
			}
			switch (chooseScalarStyle(string, singleLineOnly, state.indent, lineWidth, testAmbiguity)) {
				case STYLE_PLAIN: return string;
				case STYLE_SINGLE: return "'" + string.replace(/'/g, "''") + "'";
				case STYLE_LITERAL: return "|" + blockHeader(string, state.indent) + dropEndingNewline(indentString(string, indent));
				case STYLE_FOLDED: return ">" + blockHeader(string, state.indent) + dropEndingNewline(indentString(foldString(string, lineWidth), indent));
				case STYLE_DOUBLE: return "\"" + escapeString(string, lineWidth) + "\"";
				default: throw new YAMLException("impossible error: invalid scalar style");
			}
		}();
	}
	function blockHeader(string, indentPerLevel) {
		var indentIndicator = needIndentIndicator(string) ? String(indentPerLevel) : "";
		var clip = string[string.length - 1] === "\n";
		return indentIndicator + (clip && (string[string.length - 2] === "\n" || string === "\n") ? "+" : clip ? "" : "-") + "\n";
	}
	function dropEndingNewline(string) {
		return string[string.length - 1] === "\n" ? string.slice(0, -1) : string;
	}
	function foldString(string, width) {
		var lineRe = /(\n+)([^\n]*)/g;
		var result = function() {
			var nextLF = string.indexOf("\n");
			nextLF = nextLF !== -1 ? nextLF : string.length;
			lineRe.lastIndex = nextLF;
			return foldLine(string.slice(0, nextLF), width);
		}();
		var prevMoreIndented = string[0] === "\n" || string[0] === " ";
		var moreIndented;
		var match;
		while (match = lineRe.exec(string)) {
			var prefix = match[1], line = match[2];
			moreIndented = line[0] === " ";
			result += prefix + (!prevMoreIndented && !moreIndented && line !== "" ? "\n" : "") + foldLine(line, width);
			prevMoreIndented = moreIndented;
		}
		return result;
	}
	function foldLine(line, width) {
		if (line === "" || line[0] === " ") return line;
		var breakRe = / [^ ]/g;
		var match;
		var start = 0, end, curr = 0, next = 0;
		var result = "";
		while (match = breakRe.exec(line)) {
			next = match.index;
			if (next - start > width) {
				end = curr > start ? curr : next;
				result += "\n" + line.slice(start, end);
				start = end + 1;
			}
			curr = next;
		}
		result += "\n";
		if (line.length - start > width && curr > start) result += line.slice(start, curr) + "\n" + line.slice(curr + 1);
		else result += line.slice(start);
		return result.slice(1);
	}
	function escapeString(string) {
		var result = "";
		var char, nextChar;
		var escapeSeq;
		for (var i = 0; i < string.length; i++) {
			char = string.charCodeAt(i);
			if (char >= 55296 && char <= 56319) {
				nextChar = string.charCodeAt(i + 1);
				if (nextChar >= 56320 && nextChar <= 57343) {
					result += encodeHex((char - 55296) * 1024 + nextChar - 56320 + 65536);
					i++;
					continue;
				}
			}
			escapeSeq = ESCAPE_SEQUENCES[char];
			result += !escapeSeq && isPrintable(char) ? string[i] : escapeSeq || encodeHex(char);
		}
		return result;
	}
	function writeFlowSequence(state, level, object) {
		var _result = "", _tag = state.tag, index, length;
		for (index = 0, length = object.length; index < length; index += 1) if (writeNode(state, level, object[index], false, false)) {
			if (index !== 0) _result += "," + (!state.condenseFlow ? " " : "");
			_result += state.dump;
		}
		state.tag = _tag;
		state.dump = "[" + _result + "]";
	}
	function writeBlockSequence(state, level, object, compact) {
		var _result = "", _tag = state.tag, index, length;
		for (index = 0, length = object.length; index < length; index += 1) if (writeNode(state, level + 1, object[index], true, true)) {
			if (!compact || index !== 0) _result += generateNextLine(state, level);
			if (state.dump && CHAR_LINE_FEED === state.dump.charCodeAt(0)) _result += "-";
			else _result += "- ";
			_result += state.dump;
		}
		state.tag = _tag;
		state.dump = _result || "[]";
	}
	function writeFlowMapping(state, level, object) {
		var _result = "", _tag = state.tag, objectKeyList = Object.keys(object), index, length, objectKey, objectValue, pairBuffer;
		for (index = 0, length = objectKeyList.length; index < length; index += 1) {
			pairBuffer = "";
			if (index !== 0) pairBuffer += ", ";
			if (state.condenseFlow) pairBuffer += "\"";
			objectKey = objectKeyList[index];
			objectValue = object[objectKey];
			if (!writeNode(state, level, objectKey, false, false)) continue;
			if (state.dump.length > 1024) pairBuffer += "? ";
			pairBuffer += state.dump + (state.condenseFlow ? "\"" : "") + ":" + (state.condenseFlow ? "" : " ");
			if (!writeNode(state, level, objectValue, false, false)) continue;
			pairBuffer += state.dump;
			_result += pairBuffer;
		}
		state.tag = _tag;
		state.dump = "{" + _result + "}";
	}
	function writeBlockMapping(state, level, object, compact) {
		var _result = "", _tag = state.tag, objectKeyList = Object.keys(object), index, length, objectKey, objectValue, explicitPair, pairBuffer;
		if (state.sortKeys === true) objectKeyList.sort();
		else if (typeof state.sortKeys === "function") objectKeyList.sort(state.sortKeys);
		else if (state.sortKeys) throw new YAMLException("sortKeys must be a boolean or a function");
		for (index = 0, length = objectKeyList.length; index < length; index += 1) {
			pairBuffer = "";
			if (!compact || index !== 0) pairBuffer += generateNextLine(state, level);
			objectKey = objectKeyList[index];
			objectValue = object[objectKey];
			if (!writeNode(state, level + 1, objectKey, true, true, true)) continue;
			explicitPair = state.tag !== null && state.tag !== "?" || state.dump && state.dump.length > 1024;
			if (explicitPair) if (state.dump && CHAR_LINE_FEED === state.dump.charCodeAt(0)) pairBuffer += "?";
			else pairBuffer += "? ";
			pairBuffer += state.dump;
			if (explicitPair) pairBuffer += generateNextLine(state, level);
			if (!writeNode(state, level + 1, objectValue, true, explicitPair)) continue;
			if (state.dump && CHAR_LINE_FEED === state.dump.charCodeAt(0)) pairBuffer += ":";
			else pairBuffer += ": ";
			pairBuffer += state.dump;
			_result += pairBuffer;
		}
		state.tag = _tag;
		state.dump = _result || "{}";
	}
	function detectType(state, object, explicit) {
		var _result, typeList = explicit ? state.explicitTypes : state.implicitTypes, index, length, type, style;
		for (index = 0, length = typeList.length; index < length; index += 1) {
			type = typeList[index];
			if ((type.instanceOf || type.predicate) && (!type.instanceOf || typeof object === "object" && object instanceof type.instanceOf) && (!type.predicate || type.predicate(object))) {
				state.tag = explicit ? type.tag : "?";
				if (type.represent) {
					style = state.styleMap[type.tag] || type.defaultStyle;
					if (_toString.call(type.represent) === "[object Function]") _result = type.represent(object, style);
					else if (_hasOwnProperty.call(type.represent, style)) _result = type.represent[style](object, style);
					else throw new YAMLException("!<" + type.tag + "> tag resolver accepts not \"" + style + "\" style");
					state.dump = _result;
				}
				return true;
			}
		}
		return false;
	}
	function writeNode(state, level, object, block, compact, iskey) {
		state.tag = null;
		state.dump = object;
		if (!detectType(state, object, false)) detectType(state, object, true);
		var type = _toString.call(state.dump);
		if (block) block = state.flowLevel < 0 || state.flowLevel > level;
		var objectOrArray = type === "[object Object]" || type === "[object Array]", duplicateIndex, duplicate;
		if (objectOrArray) {
			duplicateIndex = state.duplicates.indexOf(object);
			duplicate = duplicateIndex !== -1;
		}
		if (state.tag !== null && state.tag !== "?" || duplicate || state.indent !== 2 && level > 0) compact = false;
		if (duplicate && state.usedDuplicates[duplicateIndex]) state.dump = "*ref_" + duplicateIndex;
		else {
			if (objectOrArray && duplicate && !state.usedDuplicates[duplicateIndex]) state.usedDuplicates[duplicateIndex] = true;
			if (type === "[object Object]") if (block && Object.keys(state.dump).length !== 0) {
				writeBlockMapping(state, level, state.dump, compact);
				if (duplicate) state.dump = "&ref_" + duplicateIndex + state.dump;
			} else {
				writeFlowMapping(state, level, state.dump);
				if (duplicate) state.dump = "&ref_" + duplicateIndex + " " + state.dump;
			}
			else if (type === "[object Array]") {
				var arrayLevel = state.noArrayIndent && level > 0 ? level - 1 : level;
				if (block && state.dump.length !== 0) {
					writeBlockSequence(state, arrayLevel, state.dump, compact);
					if (duplicate) state.dump = "&ref_" + duplicateIndex + state.dump;
				} else {
					writeFlowSequence(state, arrayLevel, state.dump);
					if (duplicate) state.dump = "&ref_" + duplicateIndex + " " + state.dump;
				}
			} else if (type === "[object String]") {
				if (state.tag !== "?") writeScalar(state, state.dump, level, iskey);
			} else {
				if (state.skipInvalid) return false;
				throw new YAMLException("unacceptable kind of an object to dump " + type);
			}
			if (state.tag !== null && state.tag !== "?") state.dump = "!<" + state.tag + "> " + state.dump;
		}
		return true;
	}
	function getDuplicateReferences(object, state) {
		var objects = [], duplicatesIndexes = [], index, length;
		inspectNode(object, objects, duplicatesIndexes);
		for (index = 0, length = duplicatesIndexes.length; index < length; index += 1) state.duplicates.push(objects[duplicatesIndexes[index]]);
		state.usedDuplicates = new Array(length);
	}
	function inspectNode(object, objects, duplicatesIndexes) {
		var objectKeyList, index, length;
		if (object !== null && typeof object === "object") {
			index = objects.indexOf(object);
			if (index !== -1) {
				if (duplicatesIndexes.indexOf(index) === -1) duplicatesIndexes.push(index);
			} else {
				objects.push(object);
				if (Array.isArray(object)) for (index = 0, length = object.length; index < length; index += 1) inspectNode(object[index], objects, duplicatesIndexes);
				else {
					objectKeyList = Object.keys(object);
					for (index = 0, length = objectKeyList.length; index < length; index += 1) inspectNode(object[objectKeyList[index]], objects, duplicatesIndexes);
				}
			}
		}
	}
	function dump(input, options) {
		options = options || {};
		var state = new State(options);
		if (!state.noRefs) getDuplicateReferences(input, state);
		if (writeNode(state, 0, input, true, true)) return state.dump + "\n";
		return "";
	}
	function safeDump(input, options) {
		return dump(input, common.extend({ schema: DEFAULT_SAFE_SCHEMA }, options));
	}
	module.exports.dump = dump;
	module.exports.safeDump = safeDump;
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/lib/js-yaml.js
var require_js_yaml$1 = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var loader = require_loader();
	var dumper = require_dumper();
	function deprecated(name) {
		return function() {
			throw new Error("Function " + name + " is deprecated and cannot be used.");
		};
	}
	module.exports.Type = require_type();
	module.exports.Schema = require_schema();
	module.exports.FAILSAFE_SCHEMA = require_failsafe();
	module.exports.JSON_SCHEMA = require_json();
	module.exports.CORE_SCHEMA = require_core();
	module.exports.DEFAULT_SAFE_SCHEMA = require_default_safe();
	module.exports.DEFAULT_FULL_SCHEMA = require_default_full();
	module.exports.load = loader.load;
	module.exports.loadAll = loader.loadAll;
	module.exports.safeLoad = loader.safeLoad;
	module.exports.safeLoadAll = loader.safeLoadAll;
	module.exports.dump = dumper.dump;
	module.exports.safeDump = dumper.safeDump;
	module.exports.YAMLException = require_exception();
	module.exports.MINIMAL_SCHEMA = require_failsafe();
	module.exports.SAFE_SCHEMA = require_default_safe();
	module.exports.DEFAULT_SCHEMA = require_default_full();
	module.exports.scan = deprecated("scan");
	module.exports.parse = deprecated("parse");
	module.exports.compose = deprecated("compose");
	module.exports.addConstructor = deprecated("addConstructor");
}));
//#endregion
//#region node_modules/gray-matter/node_modules/js-yaml/index.js
var require_js_yaml = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	module.exports = require_js_yaml$1();
}));
//#endregion
//#region node_modules/gray-matter/lib/engines.js
var require_engines = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var yaml = require_js_yaml();
	/**
	* Default engines
	*/
	var engines = exports = module.exports;
	/**
	* YAML
	*/
	engines.yaml = {
		parse: yaml.safeLoad.bind(yaml),
		stringify: yaml.safeDump.bind(yaml)
	};
	/**
	* JSON
	*/
	engines.json = {
		parse: JSON.parse.bind(JSON),
		stringify: function(obj, options) {
			const opts = Object.assign({
				replacer: null,
				space: 2
			}, options);
			return JSON.stringify(obj, opts.replacer, opts.space);
		}
	};
	/**
	* JavaScript
	*/
	engines.javascript = {
		parse: function parse(str, options, wrap) {
			try {
				if (wrap !== false) str = "(function() {\nreturn " + str.trim() + ";\n}());";
				return eval(str) || {};
			} catch (err) {
				if (wrap !== false && /(unexpected|identifier)/i.test(err.message)) return parse(str, options, false);
				throw new SyntaxError(err);
			}
		},
		stringify: function() {
			throw new Error("stringifying JavaScript is not supported");
		}
	};
}));
//#endregion
//#region node_modules/strip-bom-string/index.js
/*!
* strip-bom-string <https://github.com/jonschlinkert/strip-bom-string>
*
* Copyright (c) 2015, 2017, Jon Schlinkert.
* Released under the MIT License.
*/
var require_strip_bom_string = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	module.exports = function(str) {
		if (typeof str === "string" && str.charAt(0) === "﻿") return str.slice(1);
		return str;
	};
}));
//#endregion
//#region node_modules/gray-matter/lib/utils.js
var require_utils = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports) => {
	var stripBom = require_strip_bom_string();
	var typeOf = require_kind_of();
	exports.define = function(obj, key, val) {
		Reflect.defineProperty(obj, key, {
			enumerable: false,
			configurable: true,
			writable: true,
			value: val
		});
	};
	/**
	* Returns true if `val` is a buffer
	*/
	exports.isBuffer = function(val) {
		return typeOf(val) === "buffer";
	};
	/**
	* Returns true if `val` is an object
	*/
	exports.isObject = function(val) {
		return typeOf(val) === "object";
	};
	/**
	* Cast `input` to a buffer
	*/
	exports.toBuffer = function(input) {
		return typeof input === "string" ? Buffer.from(input) : input;
	};
	/**
	* Cast `val` to a string.
	*/
	exports.toString = function(input) {
		if (exports.isBuffer(input)) return stripBom(String(input));
		if (typeof input !== "string") throw new TypeError("expected input to be a string or buffer");
		return stripBom(input);
	};
	/**
	* Cast `val` to an array.
	*/
	exports.arrayify = function(val) {
		return val ? Array.isArray(val) ? val : [val] : [];
	};
	/**
	* Returns true if `str` starts with `substr`.
	*/
	exports.startsWith = function(str, substr, len) {
		if (typeof len !== "number") len = substr.length;
		return str.slice(0, len) === substr;
	};
}));
//#endregion
//#region node_modules/gray-matter/lib/defaults.js
var require_defaults = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var engines = require_engines();
	var utils = require_utils();
	module.exports = function(options) {
		const opts = Object.assign({}, options);
		opts.delimiters = utils.arrayify(opts.delims || opts.delimiters || "---");
		if (opts.delimiters.length === 1) opts.delimiters.push(opts.delimiters[0]);
		opts.language = (opts.language || opts.lang || "yaml").toLowerCase();
		opts.engines = Object.assign({}, engines, opts.parsers, opts.engines);
		return opts;
	};
}));
//#endregion
//#region node_modules/gray-matter/lib/engine.js
var require_engine = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	module.exports = function(name, options) {
		let engine = options.engines[name] || options.engines[aliase(name)];
		if (typeof engine === "undefined") throw new Error("gray-matter engine \"" + name + "\" is not registered");
		if (typeof engine === "function") engine = { parse: engine };
		return engine;
	};
	function aliase(name) {
		switch (name.toLowerCase()) {
			case "js":
			case "javascript": return "javascript";
			case "coffee":
			case "coffeescript":
			case "cson": return "coffee";
			case "yaml":
			case "yml": return "yaml";
			default: return name;
		}
	}
}));
//#endregion
//#region node_modules/gray-matter/lib/stringify.js
var require_stringify = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var typeOf = require_kind_of();
	var getEngine = require_engine();
	var defaults = require_defaults();
	module.exports = function(file, data, options) {
		if (data == null && options == null) switch (typeOf(file)) {
			case "object":
				data = file.data;
				options = {};
				break;
			case "string": return file;
			default: throw new TypeError("expected file to be a string or object");
		}
		const str = file.content;
		const opts = defaults(options);
		if (data == null) {
			if (!opts.data) return file;
			data = opts.data;
		}
		const language = file.language || opts.language;
		const engine = getEngine(language, opts);
		if (typeof engine.stringify !== "function") throw new TypeError("expected \"" + language + ".stringify\" to be a function");
		data = Object.assign({}, file.data, data);
		const open = opts.delimiters[0];
		const close = opts.delimiters[1];
		const matter = engine.stringify(data, options).trim();
		let buf = "";
		if (matter !== "{}") buf = newline(open) + newline(matter) + newline(close);
		if (typeof file.excerpt === "string" && file.excerpt !== "") {
			if (str.indexOf(file.excerpt.trim()) === -1) buf += newline(file.excerpt) + newline(close);
		}
		return buf + newline(str);
	};
	function newline(str) {
		return str.slice(-1) !== "\n" ? str + "\n" : str;
	}
}));
//#endregion
//#region node_modules/gray-matter/lib/excerpt.js
var require_excerpt = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var defaults = require_defaults();
	module.exports = function(file, options) {
		const opts = defaults(options);
		if (file.data == null) file.data = {};
		if (typeof opts.excerpt === "function") return opts.excerpt(file, opts);
		const sep = file.data.excerpt_separator || opts.excerpt_separator;
		if (sep == null && (opts.excerpt === false || opts.excerpt == null)) return file;
		const delimiter = typeof opts.excerpt === "string" ? opts.excerpt : sep || opts.delimiters[0];
		const idx = file.content.indexOf(delimiter);
		if (idx !== -1) file.excerpt = file.content.slice(0, idx);
		return file;
	};
}));
//#endregion
//#region node_modules/gray-matter/lib/to-file.js
var require_to_file = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var typeOf = require_kind_of();
	var stringify = require_stringify();
	var utils = require_utils();
	/**
	* Normalize the given value to ensure an object is returned
	* with the expected properties.
	*/
	module.exports = function(file) {
		if (typeOf(file) !== "object") file = { content: file };
		if (typeOf(file.data) !== "object") file.data = {};
		if (file.contents && file.content == null) file.content = file.contents;
		utils.define(file, "orig", utils.toBuffer(file.content));
		utils.define(file, "language", file.language || "");
		utils.define(file, "matter", file.matter || "");
		utils.define(file, "stringify", function(data, options) {
			if (options && options.language) file.language = options.language;
			return stringify(file, data, options);
		});
		file.content = utils.toString(file.content);
		file.isEmpty = false;
		file.excerpt = "";
		return file;
	};
}));
//#endregion
//#region node_modules/gray-matter/lib/parse.js
var require_parse = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var getEngine = require_engine();
	var defaults = require_defaults();
	module.exports = function(language, str, options) {
		const opts = defaults(options);
		const engine = getEngine(language, opts);
		if (typeof engine.parse !== "function") throw new TypeError("expected \"" + language + ".parse\" to be a function");
		return engine.parse(str, opts);
	};
}));
//#endregion
//#region node_modules/gray-matter/index.js
var require_gray_matter = /* @__PURE__ */ require_schema$1.__commonJSMin(((exports, module) => {
	var fs$1 = require("fs");
	var sections = require_section_matter();
	var defaults = require_defaults();
	var stringify = require_stringify();
	var excerpt = require_excerpt();
	var engines = require_engines();
	var toFile = require_to_file();
	var parse = require_parse();
	var utils = require_utils();
	/**
	* Takes a string or object with `content` property, extracts
	* and parses front-matter from the string, then returns an object
	* with `data`, `content` and other [useful properties](#returned-object).
	*
	* ```js
	* const matter = require('gray-matter');
	* console.log(matter('---\ntitle: Home\n---\nOther stuff'));
	* //=> { data: { title: 'Home'}, content: 'Other stuff' }
	* ```
	* @param {Object|String} `input` String, or object with `content` string
	* @param {Object} `options`
	* @return {Object}
	* @api public
	*/
	function matter(input, options) {
		if (input === "") return {
			data: {},
			content: input,
			excerpt: "",
			orig: input
		};
		let file = toFile(input);
		const cached = matter.cache[file.content];
		if (!options) {
			if (cached) {
				file = Object.assign({}, cached);
				file.orig = cached.orig;
				return file;
			}
			matter.cache[file.content] = file;
		}
		return parseMatter(file, options);
	}
	/**
	* Parse front matter
	*/
	function parseMatter(file, options) {
		const opts = defaults(options);
		const open = opts.delimiters[0];
		const close = "\n" + opts.delimiters[1];
		let str = file.content;
		if (opts.language) file.language = opts.language;
		const openLen = open.length;
		if (!utils.startsWith(str, open, openLen)) {
			excerpt(file, opts);
			return file;
		}
		if (str.charAt(openLen) === open.slice(-1)) return file;
		str = str.slice(openLen);
		const len = str.length;
		const language = matter.language(str, opts);
		if (language.name) {
			file.language = language.name;
			str = str.slice(language.raw.length);
		}
		let closeIndex = str.indexOf(close);
		if (closeIndex === -1) closeIndex = len;
		file.matter = str.slice(0, closeIndex);
		if (file.matter.replace(/^\s*#[^\n]+/gm, "").trim() === "") {
			file.isEmpty = true;
			file.empty = file.content;
			file.data = {};
		} else file.data = parse(file.language, file.matter, opts);
		if (closeIndex === len) file.content = "";
		else {
			file.content = str.slice(closeIndex + close.length);
			if (file.content[0] === "\r") file.content = file.content.slice(1);
			if (file.content[0] === "\n") file.content = file.content.slice(1);
		}
		excerpt(file, opts);
		if (opts.sections === true || typeof opts.section === "function") sections(file, opts.section);
		return file;
	}
	/**
	* Expose engines
	*/
	matter.engines = engines;
	/**
	* Stringify an object to YAML or the specified language, and
	* append it to the given string. By default, only YAML and JSON
	* can be stringified. See the [engines](#engines) section to learn
	* how to stringify other languages.
	*
	* ```js
	* console.log(matter.stringify('foo bar baz', {title: 'Home'}));
	* // results in:
	* // ---
	* // title: Home
	* // ---
	* // foo bar baz
	* ```
	* @param {String|Object} `file` The content string to append to stringified front-matter, or a file object with `file.content` string.
	* @param {Object} `data` Front matter to stringify.
	* @param {Object} `options` [Options](#options) to pass to gray-matter and [js-yaml].
	* @return {String} Returns a string created by wrapping stringified yaml with delimiters, and appending that to the given string.
	* @api public
	*/
	matter.stringify = function(file, data, options) {
		if (typeof file === "string") file = matter(file, options);
		return stringify(file, data, options);
	};
	/**
	* Synchronously read a file from the file system and parse
	* front matter. Returns the same object as the [main function](#matter).
	*
	* ```js
	* const file = matter.read('./content/blog-post.md');
	* ```
	* @param {String} `filepath` file path of the file to read.
	* @param {Object} `options` [Options](#options) to pass to gray-matter.
	* @return {Object} Returns [an object](#returned-object) with `data` and `content`
	* @api public
	*/
	matter.read = function(filepath, options) {
		const file = matter(fs$1.readFileSync(filepath, "utf8"), options);
		file.path = filepath;
		return file;
	};
	/**
	* Returns true if the given `string` has front matter.
	* @param  {String} `string`
	* @param  {Object} `options`
	* @return {Boolean} True if front matter exists.
	* @api public
	*/
	matter.test = function(str, options) {
		return utils.startsWith(str, defaults(options).delimiters[0]);
	};
	/**
	* Detect the language to use, if one is defined after the
	* first front-matter delimiter.
	* @param  {String} `string`
	* @param  {Object} `options`
	* @return {Object} Object with `raw` (actual language string), and `name`, the language with whitespace trimmed
	*/
	matter.language = function(str, options) {
		const open = defaults(options).delimiters[0];
		if (matter.test(str)) str = str.slice(open.length);
		const language = str.slice(0, str.search(/\r?\n/));
		return {
			raw: language,
			name: language ? language.trim() : ""
		};
	};
	/**
	* Expose `matter`
	*/
	matter.cache = {};
	matter.clearCache = function() {
		matter.cache = {};
	};
	module.exports = matter;
}));
//#endregion
//#region electron/services/file-storage.service.ts
var import_gray_matter = /* @__PURE__ */ require_schema$1.__toESM(require_gray_matter());
var notesDir = null;
/**
* Initialize file storage
*/
function initFileStorage(baseDir) {
	notesDir = path.join(baseDir, "notes");
	if (!fs.existsSync(notesDir)) fs.mkdirSync(notesDir, { recursive: true });
	console.log("[FileStorage] Initialized at:", notesDir);
}
/**
* Get notes directory path
*/
function getNotesDir() {
	if (!notesDir) throw new Error("File storage not initialized");
	return notesDir;
}
/**
* Get file path for note
*/
function getNoteFilePath(id) {
	return path.join(getNotesDir(), `${id}.md`);
}
/**
* Parse note from markdown file
*/
function parseNoteFile(id, filePath) {
	const { data, content: body } = (0, import_gray_matter.default)(fs.readFileSync(filePath, "utf-8"));
	const now = /* @__PURE__ */ new Date();
	const parseDate = (value) => {
		if (!value) return now;
		const date = new Date(value);
		return isNaN(date.getTime()) ? now : date;
	};
	return {
		id,
		title: data.title || "Untitled",
		body: body.trim(),
		metadata: data.metadata || null,
		tags: Array.isArray(data.tags) ? data.tags : [],
		created_at: parseDate(data.created_at),
		updated_at: parseDate(data.updated_at),
		deleted_at: data.deleted_at ? parseDate(data.deleted_at) : null
	};
}
/**
* Write note to markdown file
*/
function writeNoteFile(note) {
	const filePath = getNoteFilePath(note.id);
	const toISOStringOrNull = (date) => {
		if (!date) return null;
		try {
			return date.toISOString();
		} catch {
			return (/* @__PURE__ */ new Date()).toISOString();
		}
	};
	const frontmatter = {
		title: note.title,
		metadata: note.metadata,
		tags: note.tags,
		created_at: toISOStringOrNull(note.created_at),
		updated_at: toISOStringOrNull(note.updated_at),
		deleted_at: toISOStringOrNull(note.deleted_at)
	};
	const content = import_gray_matter.default.stringify(note.body, frontmatter);
	fs.writeFileSync(filePath, content, "utf-8");
}
/**
* Create new note
*/
function createNote(data) {
	const now = /* @__PURE__ */ new Date();
	const id = crypto.randomUUID();
	const note = {
		id,
		title: data.title,
		body: data.body,
		metadata: data.metadata || null,
		tags: data.tags || [],
		created_at: now,
		updated_at: now,
		deleted_at: null
	};
	writeNoteFile(note);
	console.log("[FileStorage] Created note:", id);
	return note;
}
/**
* Update existing note
*/
function updateNote(id, data) {
	const filePath = getNoteFilePath(id);
	if (!fs.existsSync(filePath)) throw new Error(`Note ${id} not found`);
	const existing = parseNoteFile(id, filePath);
	if (existing.deleted_at) throw new Error(`Note ${id} is deleted`);
	const updated = {
		...existing,
		title: data.title ?? existing.title,
		body: data.body ?? existing.body,
		metadata: data.metadata ?? existing.metadata,
		tags: data.tags ?? existing.tags,
		updated_at: /* @__PURE__ */ new Date()
	};
	writeNoteFile(updated);
	console.log("[FileStorage] Updated note:", id);
	return updated;
}
/**
* Get note by ID
*/
function getNoteById(id, includeDeleted = false) {
	const filePath = getNoteFilePath(id);
	if (!fs.existsSync(filePath)) return null;
	const note = parseNoteFile(id, filePath);
	if (!includeDeleted && note.deleted_at) return null;
	return note;
}
/**
* Get all notes
*/
function getAllNotes() {
	const dir = getNotesDir();
	return fs.readdirSync(dir).filter((f) => f.endsWith(".md")).map((file) => {
		return parseNoteFile(path.basename(file, ".md"), path.join(dir, file));
	}).filter((note) => !note.deleted_at).sort((a, b) => b.updated_at.getTime() - a.updated_at.getTime());
}
/**
* Delete note (soft delete)
*/
function deleteNote(id) {
	const filePath = getNoteFilePath(id);
	if (!fs.existsSync(filePath)) return false;
	const note = parseNoteFile(id, filePath);
	note.deleted_at = /* @__PURE__ */ new Date();
	writeNoteFile(note);
	console.log("[FileStorage] Deleted note:", id);
	return true;
}
/**
* Restore deleted note
*/
function restoreNote(id) {
	const filePath = getNoteFilePath(id);
	if (!fs.existsSync(filePath)) throw new Error(`Note ${id} not found`);
	const note = parseNoteFile(id, filePath);
	note.deleted_at = null;
	writeNoteFile(note);
	console.log("[FileStorage] Restored note:", id);
	return note;
}
/**
* Sync filesystem to database
* - Add notes from filesystem that are missing in DB
* - Remove notes from DB that don't exist in filesystem
*/
async function syncFilesystemToDb() {
	const Database = require("better-sqlite3");
	const os$1 = require("os");
	const db = new Database(path.join(os$1.homedir(), "AppData", "Roaming", "LibraNia", "librania.db"));
	const dir = getNotesDir();
	const files = fs.readdirSync(dir).filter((f) => f.endsWith(".md"));
	const fileIds = new Set(files.map((f) => path.basename(f, ".md")));
	const dbNoteIds = new Set(db.prepare("SELECT id FROM notes").all().map((row) => row.id));
	let synced = 0;
	let deleted = 0;
	let skipped = 0;
	for (const file of files) {
		const noteId = path.basename(file, ".md");
		if (dbNoteIds.has(noteId)) {
			skipped++;
			continue;
		}
		try {
			const note = parseNoteFile(noteId, path.join(dir, file));
			db.prepare(`
        INSERT INTO notes (id, title, body, created_at, updated_at, deleted_at)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(noteId, note.title, note.body, note.created_at.toISOString(), note.updated_at.toISOString(), note.deleted_at ? note.deleted_at.toISOString() : null);
			console.log("[Sync] Added to DB:", note.title);
			synced++;
		} catch (error) {
			console.error("[Sync] Error syncing", noteId, error);
		}
	}
	for (const noteId of dbNoteIds) if (!fileIds.has(noteId)) {
		db.prepare("DELETE FROM notes WHERE id = ?").run(noteId);
		console.log("[Sync] Removed from DB:", noteId);
		deleted++;
	}
	db.close();
	console.log("[Sync] Complete:", {
		synced,
		deleted,
		skipped
	});
	return {
		synced,
		deleted,
		skipped
	};
}
//#endregion
//#region electron/logger.ts
/**
* Main process logger - TEMPORARY STUB for phase 6 testing
* Winston disabled to avoid ESM/CJS bundling issues
*/
var logger$1 = {
	error(message, error) {
		if (error) console.error("[ERROR]", message, error.stack || error);
		else console.error("[ERROR]", message);
	},
	warn(message) {
		console.warn("[WARN]", message);
	},
	info(message) {
		console.log("[INFO]", message);
	},
	debug(message) {
		console.log("[DEBUG]", message);
	}
};
//#endregion
//#region electron/services/tags.service.ts
/**
* Create a new tag or return existing tag if name already exists
* @param name Tag name (case-sensitive)
* @returns Created or existing tag
*/
async function createTag(name) {
	const orm = getORM();
	const existing = await orm.select().from(require_schema$1.tags).where(require_drizzle_orm.eq(require_schema$1.tags.name, name)).limit(1);
	if (existing.length > 0) return existing[0];
	return (await orm.insert(require_schema$1.tags).values({
		id: (0, crypto$1.randomUUID)(),
		name,
		created_at: /* @__PURE__ */ new Date()
	}).returning())[0];
}
/**
* Get all tags ordered by name ASC
* @returns Array of all tags
*/
async function getAllTags() {
	return await getORM().select().from(require_schema$1.tags).orderBy(require_drizzle_orm.asc(require_schema$1.tags.name));
}
/**
* Add tags to a note (creates tags if they don't exist)
* @param noteId Note ID
* @param tagNames Array of tag names
* @returns Array of tag IDs that were associated
*/
async function addTagsToNote(noteId, tagNames) {
	const orm = getORM();
	const tagIds = [];
	for (const name of tagNames) {
		const tag = await createTag(name);
		tagIds.push(tag.id);
	}
	for (const tagId of tagIds) try {
		await orm.insert(require_schema$1.noteTags).values({
			note_id: noteId,
			tag_id: tagId
		});
	} catch (error) {
		if (!error.message.includes("UNIQUE constraint")) throw error;
	}
	return tagIds;
}
/**
* Remove tag from note
* @param noteId Note ID
* @param tagId Tag ID
*/
async function removeTagFromNote(noteId, tagId) {
	await getORM().delete(require_schema$1.noteTags).where(require_drizzle_orm.and(require_drizzle_orm.eq(require_schema$1.noteTags.note_id, noteId), require_drizzle_orm.eq(require_schema$1.noteTags.tag_id, tagId)));
}
/**
* Get all tags associated with a note
* @param noteId Note ID
* @returns Array of tags
*/
async function getNoteTags(noteId) {
	return (await getORM().select({ tag: require_schema$1.tags }).from(require_schema$1.noteTags).innerJoin(require_schema$1.tags, require_drizzle_orm.eq(require_schema$1.noteTags.tag_id, require_schema$1.tags.id)).where(require_drizzle_orm.eq(require_schema$1.noteTags.note_id, noteId)).orderBy(require_drizzle_orm.asc(require_schema$1.tags.name))).map((r) => r.tag);
}
/**
* Replace all tags on a note
* @param noteId Note ID
* @param tagNames Array of tag names
*/
async function setNoteTags(noteId, tagNames) {
	const orm = getORM();
	console.log("[TagsService] setNoteTags called:", {
		noteId,
		tagNames,
		count: tagNames.length
	});
	await orm.delete(require_schema$1.noteTags).where(require_drizzle_orm.eq(require_schema$1.noteTags.note_id, noteId));
	console.log("[TagsService] Deleted existing tags for note:", noteId);
	if (tagNames.length > 0) {
		await addTagsToNote(noteId, tagNames);
		console.log("[TagsService] Added new tags:", tagNames);
	} else console.log("[TagsService] No tags to add (empty array)");
}
//#endregion
//#region electron/ipc/tags.handlers.ts
function registerTagsHandlers() {
	electron.ipcMain.handle("tags:getAll", async () => {
		try {
			logger$1.info("IPC: tags:getAll");
			return await getAllTags();
		} catch (error) {
			logger$1.error("tags:getAll failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("tags:create", async (event, data) => {
		try {
			logger$1.info("IPC: tags:create", { name: data.name });
			return {
				success: true,
				name: data.name
			};
		} catch (error) {
			logger$1.error("tags:create failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("tags:delete", async (event, data) => {
		try {
			logger$1.info("IPC: tags:delete", { id: data.id });
			return { success: true };
		} catch (error) {
			logger$1.error("tags:delete failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("tags:rename", async (event, data) => {
		try {
			logger$1.info("IPC: tags:rename", {
				id: data.id,
				name: data.name
			});
			return { success: true };
		} catch (error) {
			logger$1.error("tags:rename failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("tags:getForNote", async (event, data) => {
		try {
			logger$1.info("IPC: tags:getForNote", { noteId: data.noteId });
			return await getNoteTags(data.noteId);
		} catch (error) {
			logger$1.error("tags:getForNote failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("tags:addToNote", async (event, data) => {
		try {
			logger$1.info("IPC: tags:addToNote", {
				noteId: data.noteId,
				tagNames: data.tagNames
			});
			const tags = Array.isArray(data.tagNames) ? data.tagNames : [data.tagNames];
			await addTagsToNote(data.noteId, tags);
			return { success: true };
		} catch (error) {
			logger$1.error("tags:addToNote failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("tags:removeFromNote", async (event, data) => {
		try {
			logger$1.info("IPC: tags:removeFromNote", {
				noteId: data.noteId,
				tagId: data.tagId
			});
			await removeTagFromNote(data.noteId, data.tagId);
			return { success: true };
		} catch (error) {
			logger$1.error("tags:removeFromNote failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("tags:getNotesByTag", async (event, data) => {
		try {
			logger$1.info("IPC: tags:getNotesByTag", { tagId: data.tagId });
			return [];
		} catch (error) {
			logger$1.error("tags:getNotesByTag failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("tags:setForNote", async (event, data) => {
		try {
			logger$1.info("IPC: tags:setForNote", {
				noteId: data.noteId,
				tagNames: data.tagNames
			});
			const tags = Array.isArray(data.tagNames) ? data.tagNames : [];
			return {
				success: true,
				note: addTagsToNote(data.noteId, tags)
			};
		} catch (error) {
			logger$1.error("tags:setForNote failed", error);
			throw error;
		}
	});
	logger$1.info("Tags IPC handlers registered");
}
//#endregion
//#region electron/ipc/search.handlers.ts
function registerSearchHandlers() {
	electron.ipcMain.handle("search:fullText", async (event, data) => {
		try {
			logger$1.info("IPC: search:fullText", { query: data.query });
			const notes = getAllNotes();
			const query = data.query.toLowerCase();
			return notes.filter((note) => !note.deleted_at).filter((note) => note.title.toLowerCase().includes(query) || note.body.toLowerCase().includes(query)).map((note) => ({
				id: note.id,
				title: note.title,
				body: note.body.substring(0, 200),
				created_at: note.created_at,
				updated_at: note.updated_at
			}));
		} catch (error) {
			logger$1.error("search:fullText failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("search:quickNav", async (event, data) => {
		try {
			logger$1.info("IPC: search:quickNav", { query: data.query });
			const notes = getAllNotes();
			const query = data.query.toLowerCase();
			return notes.filter((note) => !note.deleted_at).filter((note) => note.title.toLowerCase().includes(query)).map((note) => ({
				id: note.id,
				title: note.title
			}));
		} catch (error) {
			logger$1.error("search:quickNav failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("search:fuzzy", async (event, data) => {
		try {
			logger$1.info("IPC: search:fuzzy", { query: data.query });
			const notes = getAllNotes();
			const query = data.query.toLowerCase();
			return notes.filter((note) => !note.deleted_at).filter((note) => {
				const title = note.title.toLowerCase();
				const body = note.body.toLowerCase();
				let queryIdx = 0;
				for (const char of title + " " + body) if (char === query[queryIdx]) {
					queryIdx++;
					if (queryIdx === query.length) return true;
				}
				return false;
			}).map((note) => ({
				id: note.id,
				title: note.title,
				body: note.body.substring(0, 200)
			}));
		} catch (error) {
			logger$1.error("search:fuzzy failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("search:semantic", async (event, data) => {
		try {
			logger$1.info("IPC: search:semantic", { query: data.query });
			return [];
		} catch (error) {
			logger$1.error("search:semantic failed", error);
			throw error;
		}
	});
	logger$1.info("Search IPC handlers registered");
}
//#endregion
//#region electron/ipc/notes.handlers.ts
/**
* Register IPC handlers for note operations
* Called from main.ts after file storage initialization
*/
function registerNotesHandlers(mainWindow) {
	electron.ipcMain.handle("notes:create", async (event, data) => {
		try {
			logger$1.info("IPC: notes:create", { title: data.title });
			const note = createNote(data);
			if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send("notes:created", note);
			return note;
		} catch (error) {
			logger$1.error("notes:create failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("notes:update", async (event, data) => {
		try {
			logger$1.info("IPC: notes:update", { id: data.id });
			const { id, ...updates } = data;
			const note = updateNote(id, updates);
			if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send("notes:updated", note);
			return note;
		} catch (error) {
			logger$1.error("notes:update failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("notes:delete", async (event, data) => {
		try {
			logger$1.info("IPC: notes:delete", { id: data.id });
			return { success: deleteNote(data.id) };
		} catch (error) {
			logger$1.error("notes:delete failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("notes:restore", async (event, data) => {
		try {
			logger$1.info("IPC: notes:restore", { id: data.id });
			return restoreNote(data.id);
		} catch (error) {
			logger$1.error("notes:restore failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("notes:getById", async (event, data) => {
		try {
			logger$1.info("IPC: notes:getById", { id: data.id });
			return getNoteById(data.id, data.includeDeleted || false);
		} catch (error) {
			logger$1.error("notes:getById failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("notes:getAll", async (event) => {
		try {
			logger$1.info("IPC: notes:getAll");
			return getAllNotes();
		} catch (error) {
			logger$1.error("notes:getAll failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("notes:getDeleted", async (event) => {
		try {
			logger$1.info("IPC: notes:getDeleted");
			return getAllNotes().filter((n) => n.deleted_at !== null);
		} catch (error) {
			logger$1.error("notes:getDeleted failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("links:getBacklinks", async (event, data) => {
		try {
			logger$1.info("IPC: links:getBacklinks", { noteId: data.noteId });
			return [];
		} catch (error) {
			logger$1.error("links:getBacklinks failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("links:getSemanticLinks", async (event, data) => {
		try {
			logger$1.info("IPC: links:getSemanticLinks", { noteId: data.noteId });
			return [];
		} catch (error) {
			logger$1.error("links:getSemanticLinks failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("notes:syncFilesystemToDb", async () => {
		try {
			logger$1.info("IPC: notes:syncFilesystemToDb");
			return await syncFilesystemToDb();
		} catch (error) {
			logger$1.error("notes:syncFilesystemToDb failed", error);
			throw error;
		}
	});
	logger$1.info("Notes IPC handlers registered");
}
//#endregion
//#region electron/ipc/export.handlers.ts
function registerExportHandlers() {
	electron.ipcMain.handle("export:notes", async () => {
		logger$1.info("IPC: export:notes (stubbed)");
		return { success: false };
	});
	logger$1.info("Export IPC handlers registered (stubbed)");
}
//#endregion
//#region electron/prompts/research.system.ts
/**
* System prompt for /research command
* Instructs LLM to search existing notes, check links, research if needed, and create notes
*/
var RESEARCH_SYSTEM_PROMPT = `You are a research assistant for LibraNia, a personal knowledge management system.

When the user asks you to research a topic, follow this workflow:

## 1. Search Existing Knowledge
First, search the user's existing notes to see if they already have information on this topic.

Available search tools:
- search_notes(query: string) - Full-text search in note titles and bodies
- get_note(noteId: string) - Get full content of a specific note
- get_backlinks(noteId: string) - Get notes that link to this note
- get_note_tags(noteId: string) - Get tags associated with a note

## 2. Check Linked Notes
If you find relevant notes, check their backlinks and tags to discover related information.
Read linked notes to build a complete picture of what the user already knows.

## 3. Research if Insufficient
If existing notes don't have enough information, use web search to research the topic.

Available research tool:
- web_search(query: string) - Search the web for information

## 4. Create Note with Findings
After gathering information (from existing notes and/or web research), create a comprehensive note.

Available note tools:
- create_note(title: string, body: string) - Create a new note (body supports Markdown)
- add_tags(noteId: string, tags: string[]) - Add tags to a note

## Note Format Guidelines
- Use Markdown for formatting (headers, lists, code blocks, etc.)
- Include images using ![alt](url) syntax when relevant
- Structure information clearly with headers
- Add citations for web sources at the bottom
- Be comprehensive but concise

## Tags Guidelines
- Add relevant tags for categorization (e.g., "programming", "javascript", "tutorial")
- Use existing tags when possible (check related notes)
- Keep tags lowercase and hyphenated (e.g., "machine-learning")

## Response Format
As you work, provide status updates:
1. "Searching existing notes for [topic]..."
2. "Found X related notes. Checking [note titles]..."
3. "Existing notes cover [aspects]. Researching [gaps]..."
4. "Creating note with findings..."
5. "Note created: [title] with tags [tags]"

Then provide a summary of what you found and created.

## API Reference

### search_notes(query: string)
Returns: Array<{ id: string, title: string, body: string (preview) }>

### get_note(noteId: string)
Returns: { id: string, title: string, body: string, created_at: Date, updated_at: Date }

### get_backlinks(noteId: string)
Returns: Array<{ id: string, title: string }>

### get_note_tags(noteId: string)
Returns: Array<{ id: string, name: string }>

### web_search(query: string)
Returns: Array<{ title: string, url: string, snippet: string }>

### create_note(title: string, body: string)
Returns: { id: string, title: string, body: string }

### add_tags(noteId: string, tags: string[])
Returns: { success: boolean }

Remember: Always search existing notes first before researching externally. The user may already have the information they need.`;
//#endregion
//#region electron/tools/research.tools.ts
/**
* Tool definitions for AI research workflow
*/
var RESEARCH_TOOLS = [
	{
		name: "search_notes",
		description: "Search existing notes by keyword. Searches both titles and body content.",
		input_schema: {
			type: "object",
			properties: { query: {
				type: "string",
				description: "Search query to find relevant notes"
			} },
			required: ["query"]
		}
	},
	{
		name: "get_note",
		description: "Get full content of a specific note by ID",
		input_schema: {
			type: "object",
			properties: { noteId: {
				type: "string",
				description: "ID of the note to retrieve"
			} },
			required: ["noteId"]
		}
	},
	{
		name: "get_backlinks",
		description: "Get all notes that link to a specific note",
		input_schema: {
			type: "object",
			properties: { noteId: {
				type: "string",
				description: "ID of the note to get backlinks for"
			} },
			required: ["noteId"]
		}
	},
	{
		name: "get_note_tags",
		description: "Get tags associated with a note",
		input_schema: {
			type: "object",
			properties: { noteId: {
				type: "string",
				description: "ID of the note to get tags for"
			} },
			required: ["noteId"]
		}
	},
	{
		name: "web_search",
		description: "Search the web for information. Use when existing notes lack sufficient information.",
		input_schema: {
			type: "object",
			properties: { query: {
				type: "string",
				description: "Search query for web search"
			} },
			required: ["query"]
		}
	},
	{
		name: "create_note",
		description: "Create a new note with title and body content. Body supports Markdown formatting.",
		input_schema: {
			type: "object",
			properties: {
				title: {
					type: "string",
					description: "Title of the note"
				},
				body: {
					type: "string",
					description: "Body content in Markdown format"
				}
			},
			required: ["title", "body"]
		}
	},
	{
		name: "add_tags",
		description: "Add tags to a note for categorization",
		input_schema: {
			type: "object",
			properties: {
				noteId: {
					type: "string",
					description: "ID of the note to add tags to"
				},
				tags: {
					type: "array",
					items: { type: "string" },
					description: "Array of tag names to add"
				}
			},
			required: ["noteId", "tags"]
		}
	}
];
/**
* Execute a tool call and return the result
*/
async function executeToolCall(toolName, toolInput, webSearchFn) {
	switch (toolName) {
		case "search_notes": {
			const notes = getAllNotes();
			const query = toolInput.query.toLowerCase();
			return notes.filter((note) => !note.deleted_at).filter((note) => note.title.toLowerCase().includes(query) || note.body.toLowerCase().includes(query)).map((note) => ({
				id: note.id,
				title: note.title,
				body: note.body.substring(0, 200) + "..."
			}));
		}
		case "get_note": {
			const note = getNoteById(toolInput.noteId, false);
			if (!note) throw new Error(`Note not found: ${toolInput.noteId}`);
			return {
				id: note.id,
				title: note.title,
				body: note.body,
				created_at: note.created_at,
				updated_at: note.updated_at
			};
		}
		case "get_backlinks": return [];
		case "get_note_tags": return (await getNoteTags(toolInput.noteId)).map((tag) => ({
			id: tag.id,
			name: tag.name
		}));
		case "web_search":
			if (!webSearchFn) throw new Error("Web search not configured");
			return await webSearchFn(toolInput.query);
		case "create_note": {
			const note = createNote({
				title: toolInput.title,
				body: toolInput.body,
				tags: []
			});
			return {
				id: note.id,
				title: note.title,
				body: note.body
			};
		}
		case "add_tags":
			logger$1.info(`Adding tags to note ${toolInput.noteId}:`, toolInput.tags);
			await setNoteTags(toolInput.noteId, toolInput.tags);
			logger$1.info(`Tags added successfully to note ${toolInput.noteId}`);
			return { success: true };
		default: throw new Error(`Unknown tool: ${toolName}`);
	}
}
//#endregion
//#region electron/services/web-search.service.ts
/**
* Web search service using Tavily API
* Free tier: 1000 searches/month
*/
/**
* Search the web using Tavily API
* @param query Search query
* @param apiKey Tavily API key
* @param maxResults Maximum number of results (default: 5)
*/
async function searchWeb(query, apiKey, maxResults = 5) {
	if (!apiKey) throw new Error("Tavily API key not configured");
	logger$1.info("Web search:", {
		query,
		maxResults
	});
	try {
		const response = await fetch("https://api.tavily.com/search", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				api_key: apiKey,
				query,
				max_results: maxResults,
				search_depth: "basic",
				include_answer: false,
				include_raw_content: false
			})
		});
		if (!response.ok) {
			const error = await response.text();
			throw new Error(`Tavily API error: ${response.status} ${error}`);
		}
		const data = await response.json();
		logger$1.info("Web search results:", { count: data.results.length });
		return data.results.map((result) => ({
			title: result.title,
			url: result.url,
			content: result.content,
			score: result.score
		}));
	} catch (error) {
		logger$1.error("Web search failed:", error);
		throw error;
	}
}
//#endregion
//#region electron/services/provider-search.service.ts
/**
* Web search using AI provider's native capabilities
* Fallback when Tavily not configured
*/
/**
* Search web using Claude's web search capability
*/
async function searchWithClaude(query, apiKey, baseURL) {
	logger$1.info("Web search via Claude:", { query });
	return [{
		title: "Web search not available",
		url: "",
		content: "Claude API does not support web search. Please configure TAVILY_API_KEY in .env for web search capability.",
		score: 0
	}];
}
//#endregion
//#region electron/ipc/ai.handlers.ts
var ai_handlers_exports = /* @__PURE__ */ require_schema$1.__exportAll({
	callClaude: () => callClaude,
	callDeepSeek: () => callDeepSeek,
	callOpenAI: () => callOpenAI,
	registerAIHandlers: () => registerAIHandlers
});
async function callDeepSeek(messages, apiKey, model, tools, onProgress) {
	readEnv().TAVILY_API_KEY;
	const requestBody = {
		model,
		messages,
		stream: false
	};
	if (tools && tools.length > 0) requestBody.tools = tools.map((tool) => ({
		type: "function",
		function: {
			name: tool.name,
			description: tool.description,
			parameters: tool.input_schema
		}
	}));
	let response = await fetch("https://api.deepseek.com/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			"Authorization": `Bearer ${apiKey}`
		},
		body: JSON.stringify(requestBody)
	});
	if (!response.ok) {
		const error = await response.text();
		throw new Error(`DeepSeek API error: ${response.status} ${error}`);
	}
	let data = await response.json();
	const maxIterations = 10;
	let iteration = 0;
	const conversationMessages = [...messages];
	while (data.choices[0].message.tool_calls && iteration < maxIterations) {
		iteration++;
		logger$1.info(`Tool call iteration ${iteration}`);
		const assistantMessage = data.choices[0].message;
		conversationMessages.push(assistantMessage);
		for (const toolCall of assistantMessage.tool_calls) {
			logger$1.info(`Executing tool: ${toolCall.function.name}`, toolCall.function.arguments);
			if (onProgress) onProgress(`Executing: ${toolCall.function.name}...`);
			try {
				const args = JSON.parse(toolCall.function.arguments);
				const tavilyApiKey = readEnv().TAVILY_API_KEY;
				const webSearchFn = tavilyApiKey ? async (query) => await searchWeb(query, tavilyApiKey) : void 0;
				const result = await executeToolCall(toolCall.function.name, args, webSearchFn);
				conversationMessages.push({
					role: "tool",
					tool_call_id: toolCall.id,
					content: JSON.stringify(result)
				});
			} catch (error) {
				logger$1.error(`Tool execution failed: ${toolCall.function.name}`, error);
				conversationMessages.push({
					role: "tool",
					tool_call_id: toolCall.id,
					content: `Error: ${error.message}`
				});
			}
		}
		response = await fetch("https://api.deepseek.com/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"Authorization": `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model,
				messages: conversationMessages,
				tools: requestBody.tools,
				stream: false
			})
		});
		if (!response.ok) {
			const error = await response.text();
			throw new Error(`DeepSeek API error: ${response.status} ${error}`);
		}
		data = await response.json();
	}
	return data.choices[0].message.content;
}
async function callClaude(messages, apiKey, model, baseURL, tools, onProgress) {
	readEnv().TAVILY_API_KEY;
	const systemMessage = messages.find((m) => m.role === "system");
	const conversationMessages = messages.filter((m) => m.role !== "system");
	const url = baseURL ? `${baseURL}/v1/messages` : "https://api.anthropic.com/v1/messages";
	const requestBody = {
		model,
		max_tokens: 4096,
		system: systemMessage?.content,
		messages: conversationMessages
	};
	if (tools && tools.length > 0) requestBody.tools = tools;
	let response = await fetch(url, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			"x-api-key": apiKey,
			"anthropic-version": "2023-06-01"
		},
		body: JSON.stringify(requestBody)
	});
	if (!response.ok) {
		const error = await response.text();
		throw new Error(`Claude API error: ${response.status} ${error}`);
	}
	let data = await response.json();
	const maxIterations = 10;
	let iteration = 0;
	while (data.stop_reason === "tool_use" && iteration < maxIterations) {
		iteration++;
		logger$1.info(`Tool use iteration ${iteration}`, { stopReason: data.stop_reason });
		const toolUseBlocks = data.content.filter((block) => block.type === "tool_use");
		data.content.filter((block) => block.type === "text");
		logger$1.info(`Found ${toolUseBlocks.length} tool calls`, { tools: toolUseBlocks.map((t) => t.name) });
		const toolResults = [];
		for (const toolUse of toolUseBlocks) {
			logger$1.info(`Executing tool: ${toolUse.name}`, { input: toolUse.input });
			if (onProgress) onProgress(`Executing: ${toolUse.name}...`);
			try {
				const tavilyApiKey = readEnv().TAVILY_API_KEY;
				const webSearchFn = tavilyApiKey ? async (query) => await searchWeb(query, tavilyApiKey) : async (query) => await searchWithClaude(query, apiKey, baseURL);
				const result = await executeToolCall(toolUse.name, toolUse.input, webSearchFn);
				logger$1.info(`Tool ${toolUse.name} succeeded`, { resultLength: JSON.stringify(result).length });
				toolResults.push({
					type: "tool_result",
					tool_use_id: toolUse.id,
					content: JSON.stringify(result)
				});
			} catch (error) {
				logger$1.error(`Tool execution failed: ${toolUse.name}`, error);
				toolResults.push({
					type: "tool_result",
					tool_use_id: toolUse.id,
					content: `Error: ${error.message}`,
					is_error: true
				});
			}
		}
		conversationMessages.push({
			role: "assistant",
			content: data.content
		});
		conversationMessages.push({
			role: "user",
			content: toolResults
		});
		response = await fetch(url, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"x-api-key": apiKey,
				"anthropic-version": "2023-06-01"
			},
			body: JSON.stringify({
				model,
				max_tokens: 4096,
				system: systemMessage?.content,
				messages: conversationMessages,
				tools
			})
		});
		if (!response.ok) {
			const error = await response.text();
			throw new Error(`Claude API error: ${response.status} ${error}`);
		}
		data = await response.json();
	}
	return data.content.find((block) => block.type === "text")?.text || "";
}
async function callOpenAI(messages, apiKey, model, baseURL, tools, onProgress) {
	readEnv().TAVILY_API_KEY;
	const url = baseURL ? `${baseURL}/chat/completions` : "https://api.openai.com/v1/chat/completions";
	const requestBody = {
		model,
		messages,
		stream: false
	};
	if (tools && tools.length > 0) requestBody.tools = tools.map((tool) => ({
		type: "function",
		function: {
			name: tool.name,
			description: tool.description,
			parameters: tool.input_schema
		}
	}));
	let response = await fetch(url, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			"Authorization": `Bearer ${apiKey}`
		},
		body: JSON.stringify(requestBody)
	});
	if (!response.ok) {
		const error = await response.text();
		throw new Error(`OpenAI API error: ${response.status} ${error}`);
	}
	let data = await response.json();
	const maxIterations = 10;
	let iteration = 0;
	const conversationMessages = [...messages];
	while (data.choices[0].message.tool_calls && iteration < maxIterations) {
		iteration++;
		logger$1.info(`Tool call iteration ${iteration}`);
		const assistantMessage = data.choices[0].message;
		conversationMessages.push(assistantMessage);
		for (const toolCall of assistantMessage.tool_calls) {
			logger$1.info(`Executing tool: ${toolCall.function.name}`, toolCall.function.arguments);
			if (onProgress) onProgress(`Executing: ${toolCall.function.name}...`);
			try {
				const args = JSON.parse(toolCall.function.arguments);
				const tavilyApiKey = readEnv().TAVILY_API_KEY;
				const webSearchFn = tavilyApiKey ? async (query) => await searchWeb(query, tavilyApiKey) : void 0;
				const result = await executeToolCall(toolCall.function.name, args, webSearchFn);
				conversationMessages.push({
					role: "tool",
					tool_call_id: toolCall.id,
					content: JSON.stringify(result)
				});
			} catch (error) {
				logger$1.error(`Tool execution failed: ${toolCall.function.name}`, error);
				conversationMessages.push({
					role: "tool",
					tool_call_id: toolCall.id,
					content: `Error: ${error.message}`
				});
			}
		}
		response = await fetch(url, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"Authorization": `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model,
				messages: conversationMessages,
				tools: requestBody.tools,
				stream: false
			})
		});
		if (!response.ok) {
			const error = await response.text();
			throw new Error(`OpenAI API error: ${response.status} ${error}`);
		}
		data = await response.json();
	}
	return data.choices[0].message.content;
}
function registerAIHandlers(mainWindow) {
	electron.ipcMain.handle("ai:chat", async (event, request) => {
		try {
			logger$1.info("IPC: ai:chat", {
				conversationId: request.conversationId,
				messageCount: request.messages.length,
				providerId: request.providerId,
				model: request.model,
				researchMode: request.researchMode
			});
			const providerId = request.providerId || "deepseek";
			const config = loadProviderFromEnv(providerId);
			if (!config) throw new Error(`Provider ${providerId} not configured. Please add API key in Settings.`);
			const model = request.model || config.model;
			logger$1.info("Using provider:", {
				id: config.id,
				model,
				hasApiKey: !!config.apiKey
			});
			const userMessage = request.messages[request.messages.length - 1];
			if (userMessage.role === "user") await createMessage({
				conversation_id: request.conversationId,
				role: userMessage.role,
				content: userMessage.content
			});
			let messagesToSend = [...request.messages];
			let tools = void 0;
			if (request.researchMode) {
				logger$1.info("Research mode enabled - adding system prompt and tools");
				messagesToSend = [{
					role: "system",
					content: RESEARCH_SYSTEM_PROMPT
				}, ...request.messages.filter((m) => m.role !== "system")];
				tools = RESEARCH_TOOLS;
				logger$1.info("Tools configured:", {
					toolCount: tools.length,
					toolNames: tools.map((t) => t.name)
				});
			}
			const onProgress = (status) => {
				if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send("ai:progress", {
					conversationId: request.conversationId,
					status
				});
			};
			let response;
			switch (config.id) {
				case "deepseek":
					response = await callDeepSeek(messagesToSend, config.apiKey, model, tools, onProgress);
					break;
				case "claude":
					response = await callClaude(messagesToSend, config.apiKey, model, config.baseURL, tools, onProgress);
					break;
				case "openai":
					response = await callOpenAI(messagesToSend, config.apiKey, model, config.baseURL, tools, onProgress);
					break;
				default: throw new Error(`Unsupported provider: ${config.id}`);
			}
			logger$1.info("AI response received", { length: response.length });
			await createMessage({
				conversation_id: request.conversationId,
				role: "assistant",
				content: response,
				provider_id: config.id,
				model
			});
			return {
				success: true,
				content: response
			};
		} catch (error) {
			logger$1.error("ai:chat failed", error);
			return {
				success: false,
				error: error.message
			};
		}
	});
	electron.ipcMain.handle("ai:getMessages", async (event, data) => {
		try {
			logger$1.info("IPC: ai:getMessages", { conversationId: data.conversationId });
			return {
				success: true,
				messages: await getMessagesByConversation(data.conversationId)
			};
		} catch (error) {
			logger$1.error("ai:getMessages failed", error);
			return {
				success: false,
				error: error.message
			};
		}
	});
	logger$1.info("AI IPC handlers registered");
}
//#endregion
//#region electron/ipc/content.handlers.ts
/**
* Register IPC handlers for content operations
* DISABLED: File storage doesn't support content table yet
*/
function registerContentHandlers() {
	electron.ipcMain.handle("content:upload", async () => {
		try {
			const result = await electron.dialog.showOpenDialog({
				properties: ["openFile"],
				filters: [{
					name: "Documents",
					extensions: [
						"pdf",
						"docx",
						"txt",
						"md"
					]
				}, {
					name: "Images",
					extensions: [
						"png",
						"jpg",
						"jpeg",
						"webp"
					]
				}]
			});
			logger$1.info("IPC: content:upload", { canceled: result.canceled });
			return {
				canceled: result.canceled,
				filePath: result.canceled ? null : result.filePaths[0]
			};
		} catch (error) {
			logger$1.error("content:upload failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("content:saveImage", async (event, data) => {
		try {
			logger$1.info("IPC: content:saveImage", {
				filename: data.filename,
				noteId: data.noteId
			});
			const attachmentsDir = path.join(os.homedir(), "AppData", "Roaming", "LibraNia", "attachments", data.noteId);
			if (!fs.existsSync(attachmentsDir)) fs.mkdirSync(attachmentsDir, { recursive: true });
			const timestamp = Date.now();
			const ext = path.extname(data.filename) || ".png";
			const filename = `${path.basename(data.filename, ext)}-${timestamp}${ext}`;
			const filePath = path.join(attachmentsDir, filename);
			const buffer = Buffer.from(data.buffer);
			fs.writeFileSync(filePath, buffer);
			logger$1.info("Image saved", { filePath });
			return { filePath };
		} catch (error) {
			logger$1.error("content:saveImage failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("content:create", async () => {
		logger$1.info("IPC: content:create (stubbed)");
		return null;
	});
	electron.ipcMain.handle("content:getById", async () => {
		logger$1.info("IPC: content:getById (stubbed)");
		return null;
	});
	electron.ipcMain.handle("content:getAll", async () => {
		logger$1.info("IPC: content:getAll (stubbed)");
		return [];
	});
	electron.ipcMain.handle("content:update", async () => {
		logger$1.info("IPC: content:update (stubbed)");
		return null;
	});
	electron.ipcMain.handle("content:delete", async () => {
		logger$1.info("IPC: content:delete (stubbed)");
		return { success: false };
	});
	logger$1.info("Content IPC handlers registered (stubbed)");
}
//#endregion
//#region electron/services/graph.service.ts
/**
* Extract wiki-links from note body
* Matches [[note-title]] pattern
*/
function extractWikiLinks(body) {
	const regex = /\[\[([^\]]+)\]\]/g;
	const links = [];
	let match;
	while ((match = regex.exec(body)) !== null) links.push(match[1].trim());
	return links;
}
/**
* Get graph data for 3D visualization from file storage
* Builds graph by parsing wiki-links in note bodies
* @returns GraphData with nodes (id, title, tags) and links (source, target, type)
*/
function getGraphData() {
	const notes = getAllNotes();
	const titleToId = /* @__PURE__ */ new Map();
	notes.forEach((note) => {
		titleToId.set(note.title.toLowerCase(), note.id);
	});
	const graphNodes = notes.map((note) => ({
		id: note.id,
		title: note.title,
		tags: note.tags
	}));
	const graphLinks = [];
	notes.forEach((note) => {
		extractWikiLinks(note.body).forEach((linkTitle) => {
			const targetId = titleToId.get(linkTitle.toLowerCase());
			if (targetId) graphLinks.push({
				source: note.id,
				target: targetId,
				type: "manual"
			});
		});
	});
	return {
		nodes: graphNodes,
		links: graphLinks
	};
}
//#endregion
//#region electron/ipc/graph.handlers.ts
function registerGraphHandlers() {
	electron.ipcMain.handle("graph:getData", async () => {
		try {
			logger$1.info("IPC: graph:getData");
			return getGraphData();
		} catch (error) {
			logger$1.error("graph:getData failed", error);
			throw error;
		}
	});
	logger$1.info("Graph IPC handlers registered");
}
//#endregion
//#region electron/ipc/app.handlers.ts
function registerAppHandlers() {
	electron.ipcMain.handle("app:restart", async () => {
		try {
			logger$1.info("IPC: app:restart");
			electron.app.relaunch();
			electron.app.exit(0);
		} catch (error) {
			logger$1.error("app:restart failed", error);
			throw error;
		}
	});
	logger$1.info("App IPC handlers registered");
}
//#endregion
//#region electron/ipc/config.handlers.ts
function getEnvPath() {
	const userDataPath = electron.app?.getPath("userData") || process.cwd();
	return path.join(userDataPath, ".env");
}
function writeEnvVar(key, value) {
	const envPath = getEnvPath();
	const env = readEnv();
	env[key] = value;
	const content = Object.entries(env).map(([k, v]) => `${k}="${v}"`).join("\n") + "\n";
	fs.writeFileSync(envPath, content, "utf-8");
	logger$1.info(`[ENV] Set ${key} in .env`);
}
function registerConfigHandlers() {
	electron.ipcMain.handle("config:get", async () => {
		try {
			logger$1.info("IPC: config:get");
			return await loadConfig();
		} catch (error) {
			logger$1.error("config:get failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("config:set", async (event, data) => {
		try {
			logger$1.info("IPC: config:set");
			await saveConfig(data);
			return { success: true };
		} catch (error) {
			logger$1.error("config:set failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("config:update", async (event, data) => {
		try {
			logger$1.info("IPC: config:update");
			await updateConfig(data);
			return { success: true };
		} catch (error) {
			logger$1.error("config:update failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("config:setEnvVar", async (event, data) => {
		try {
			logger$1.info("IPC: config:setEnvVar", { key: data.key });
			writeEnvVar(data.key, data.value);
			return { success: true };
		} catch (error) {
			logger$1.error("config:setEnvVar failed", error);
			throw error;
		}
	});
	logger$1.info("Config IPC handlers registered");
}
//#endregion
//#region electron/ipc/window.handlers.ts
function registerWindowHandlers() {
	electron.ipcMain.handle("window:minimize", async (event) => {
		try {
			logger$1.info("IPC: window:minimize");
			electron.BrowserWindow.fromWebContents(event.sender)?.minimize();
			return { success: true };
		} catch (error) {
			logger$1.error("window:minimize failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("window:maximize", async (event) => {
		try {
			logger$1.info("IPC: window:maximize");
			const win = electron.BrowserWindow.fromWebContents(event.sender);
			if (win?.isMaximized()) win.unmaximize();
			else win?.maximize();
			return { success: true };
		} catch (error) {
			logger$1.error("window:maximize failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("window:close", async (event) => {
		try {
			logger$1.info("IPC: window:close");
			electron.BrowserWindow.fromWebContents(event.sender)?.close();
			return { success: true };
		} catch (error) {
			logger$1.error("window:close failed", error);
			throw error;
		}
	});
	logger$1.info("Window IPC handlers registered");
}
//#endregion
//#region electron/ipc/misc.handlers.ts
function registerMiscHandlers() {
	electron.ipcMain.handle("log:error", async (event, data) => {
		logger$1.error("Renderer error:", data);
		return { success: true };
	});
	electron.ipcMain.handle("logs:open", async () => {
		try {
			const logsDir = path.default.join(electron.app.getPath("userData"), "logs");
			await electron.shell.openPath(logsDir);
			return { success: true };
		} catch (error) {
			logger$1.error("logs:open failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("mode:switch", async (event, data) => {
		logger$1.info("IPC: mode:switch", { mode: data.mode });
		return {
			success: true,
			requiresRestart: true
		};
	});
	electron.ipcMain.handle("provider:getConfig", async (event, data) => {
		try {
			logger$1.info("IPC: provider:getConfig", { providerId: data.providerId });
			return loadProviderFromEnv(data.providerId) || null;
		} catch (error) {
			logger$1.error("provider:getConfig failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("provider:getAllConfigs", async () => {
		try {
			logger$1.info("IPC: provider:getAllConfigs");
			const configs = loadAllProvidersFromEnv();
			logger$1.info("Retrieved configs from .env:", configs.map((c) => ({
				id: c.id,
				hasApiKey: !!c.apiKey,
				model: c.model
			})));
			return configs;
		} catch (error) {
			logger$1.error("provider:getAllConfigs failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("provider:setConfig", async (event, data) => {
		try {
			logger$1.info("IPC: provider:setConfig", {
				providerId: data.id,
				hasApiKey: !!data.apiKey,
				model: data.model
			});
			saveProviderToEnv(data);
			logger$1.info("Config saved to .env");
			const saved = loadProviderFromEnv(data.id);
			logger$1.info("Verification:", {
				id: saved?.id,
				hasApiKey: !!saved?.apiKey,
				model: saved?.model
			});
			return { success: true };
		} catch (error) {
			logger$1.error("provider:setConfig failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("provider:deleteConfig", async (event, data) => {
		try {
			logger$1.info("IPC: provider:deleteConfig", { providerId: data.providerId });
			deleteProviderFromEnv(data.providerId);
			return { success: true };
		} catch (error) {
			logger$1.error("provider:deleteConfig failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("provider:validate", async (event, data) => {
		try {
			logger$1.info("IPC: provider:validate - raw data:", data);
			logger$1.info("IPC: provider:validate", {
				providerId: data?.providerId,
				hasApiKey: !!data?.apiKey,
				hasModel: !!data?.model,
				apiKeyLength: data?.apiKey?.length || 0
			});
			const isValid = !!(data?.providerId && data?.apiKey);
			logger$1.info("Validation result:", { isValid });
			return { valid: isValid };
		} catch (error) {
			logger$1.error("provider:validate failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("chat:send", async (event, data) => {
		logger$1.info("IPC: chat:send (stubbed)");
		return { success: false };
	});
	electron.ipcMain.handle("chat:summarizeNote", async (event, data) => {
		logger$1.info("IPC: chat:summarizeNote (stubbed)");
		return { success: false };
	});
	electron.ipcMain.handle("conversation:create", async (event, data) => {
		try {
			logger$1.info("IPC: conversation:create", { title: data.title });
			const orm = getORM();
			return await createConversation({ title: data.title }, orm);
		} catch (error) {
			logger$1.error("conversation:create failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("conversation:get", async (event, data) => {
		try {
			logger$1.info("IPC: conversation:get", { conversationId: data.conversationId });
			const orm = getORM();
			return await getConversation(data.conversationId, orm);
		} catch (error) {
			logger$1.error("conversation:get failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("conversation:getAll", async () => {
		try {
			logger$1.info("IPC: conversation:getAll");
			return await getAllConversations(getORM());
		} catch (error) {
			logger$1.error("conversation:getAll failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("conversation:delete", async (event, data) => {
		try {
			logger$1.info("IPC: conversation:delete", { conversationId: data.conversationId });
			const orm = getORM();
			await deleteConversation(data.conversationId, orm);
			return { success: true };
		} catch (error) {
			logger$1.error("conversation:delete failed", error);
			throw error;
		}
	});
	electron.ipcMain.handle("conversation:rename", async (event, data) => {
		try {
			logger$1.info("IPC: conversation:rename", {
				conversationId: data.conversationId,
				title: data.title
			});
			const orm = getORM();
			const { conversations } = await Promise.resolve().then(() => require("./schema-Cofpqhhy.js")).then((n) => n.schema_exports);
			const { eq } = await Promise.resolve().then(() => require("./drizzle-orm-D27XQ0Pd.js")).then((n) => n.drizzle_orm_exports);
			await orm.update(conversations).set({
				title: data.title,
				updated_at: /* @__PURE__ */ new Date()
			}).where(eq(conversations.id, data.conversationId));
			return { success: true };
		} catch (error) {
			logger$1.error("conversation:rename failed", error);
			throw error;
		}
	});
	logger$1.info("Misc IPC handlers registered");
}
//#endregion
//#region electron/main.ts
var logger = {
	error: (msg, err) => console.error("[ERROR]", msg, err),
	warn: (msg) => console.warn("[WARN]", msg),
	info: (msg) => console.log("[INFO]", msg),
	debug: (msg) => console.log("[DEBUG]", msg)
};
setupCrashHandlers();
var __dirname$1 = __dirname$1 || path.default.dirname(__filename);
electron.protocol.registerSchemesAsPrivileged([{
	scheme: "librania",
	privileges: {
		standard: true,
		secure: true,
		supportFetchAPI: true,
		corsEnabled: false
	}
}]);
var mainWindow = null;
var currentConfig;
var serverInstance = null;
var tray = null;
async function createWindow() {
	try {
		const windowState = await getWindowState();
		mainWindow = new electron.BrowserWindow({
			x: windowState.x,
			y: windowState.y,
			width: windowState.width,
			height: windowState.height,
			minWidth: 800,
			minHeight: 600,
			webPreferences: {
				contextIsolation: true,
				nodeIntegration: false,
				sandbox: true,
				preload: path.default.join(__dirname$1, "preload.js")
			}
		});
		mainWindow.on("close", async () => {
			if (mainWindow) await saveWindowState(mainWindow);
		});
		mainWindow.webContents.on("did-fail-load", (event, errorCode, errorDescription) => {
			logger.error("Window failed to load", /* @__PURE__ */ new Error(`Code: ${errorCode}, Description: ${errorDescription}`));
		});
		const isDev = !!process.env.VITE_DEV_SERVER_URL;
		const isWebMode = currentConfig.mode === "web";
		if (isDev) {
			logger.info("Loading from Vite dev server: " + process.env.VITE_DEV_SERVER_URL);
			await mainWindow.loadURL(process.env.VITE_DEV_SERVER_URL);
			mainWindow.webContents.openDevTools();
		} else if (isWebMode) {
			logger.info("Starting Express server for web mode");
			try {
				const distPath = path.default.join(__dirname$1, "../dist");
				serverInstance = await startServer(currentConfig.serverPort, distPath);
				await mainWindow.loadURL(`http://localhost:${serverInstance.port}`);
			} catch (error) {
				logger.error("Failed to start server, falling back to desktop mode", error);
				await mainWindow.loadFile(path.default.join(__dirname$1, "../dist/index.html"));
			}
		} else {
			logger.info("Loading from file system (desktop mode)");
			await mainWindow.loadFile(path.default.join(__dirname$1, "../dist/index.html"));
		}
		mainWindow.on("closed", () => {
			mainWindow = null;
		});
	} catch (error) {
		logger.error("Failed to create window", error);
		throw error;
	}
}
function registerIpcHandlers() {
	electron.ipcMain.on("log:write", (_event, entry) => {
		try {
			const level = entry.level;
			const msg = entry.message;
			if (level === "error") console.error("[RENDERER ERROR]", msg, entry.stack);
			else if (level === "warn") console.warn("[RENDERER WARN]", msg);
			else console.log(`[RENDERER ${level.toUpperCase()}]`, msg);
		} catch (error) {
			logger.error("IPC log:write failed", error);
		}
	});
	electron.ipcMain.on("app:reload", () => {
		try {
			mainWindow?.reload();
		} catch (error) {
			logger.error("IPC app:reload failed", error);
		}
	});
}
function handleModeSwitch(mode) {
	updateConfig({ mode }).then(() => {
		logger.info("Mode switched via tray to: " + mode);
		electron.app.relaunch();
		electron.app.exit(0);
	});
}
electron.app.whenReady().then(async () => {
	electron.protocol.registerFileProtocol("librania", (request, callback) => {
		const url = request.url.replace("librania://", "");
		callback({ path: path.default.normalize(decodeURIComponent(url)) });
	});
	logger.info("Custom protocol registered: librania://");
	await initDatabase(path.default.join(electron.app.getPath("userData"), "librania.db"));
	logger.info("Database initialized");
	const storageDir = electron.app.getPath("userData");
	initFileStorage(storageDir);
	logger.info("File storage initialized at: " + path.default.join(storageDir, "notes"));
	currentConfig = await loadConfig();
	logger.info("Config loaded");
	logger.info("App ready, mode: " + currentConfig.mode);
	registerIpcHandlers();
	registerAppHandlers();
	registerConfigHandlers();
	registerWindowHandlers();
	registerMiscHandlers();
	registerTagsHandlers();
	registerSearchHandlers();
	registerExportHandlers();
	registerContentHandlers();
	registerGraphHandlers();
	await createWindow();
	if (mainWindow) {
		registerNotesHandlers(mainWindow);
		registerAIHandlers(mainWindow);
		logger.info("AI IPC handlers registered");
	}
	if (mainWindow) {
		tray = createTray(mainWindow, currentConfig.mode, handleModeSwitch);
		logger.info("System tray created");
	}
	if (currentConfig.mode === "web") {
		serverInstance = await startServer(3e3, path.default.join(__dirname$1, "../dist"));
		logger.info("HTTP server started on port 3000");
	}
});
electron.app.on("window-all-closed", () => {
	if (process.platform !== "darwin") electron.app.quit();
});
electron.app.on("before-quit", async () => {
	if (tray) {
		tray.destroy();
		tray = null;
	}
	if (serverInstance) {
		await stopServer(serverInstance);
		serverInstance = null;
	}
});
electron.app.on("activate", () => {
	if (electron.BrowserWindow.getAllWindows().length === 0) createWindow();
});
setInterval(() => {
	const memoryUsage = process.memoryUsage();
	const cpuUsage = process.cpuUsage();
	const memoryMB = Math.round(memoryUsage.heapUsed / 1024 / 1024);
	logger.debug(`Memory usage: ${memoryMB}MB (heap used)`);
	if (memoryUsage.heapUsed > 500 * 1024 * 1024) logger.warn(`High memory usage detected: ${memoryMB}MB - potential memory leak`);
	const cpuSeconds = (cpuUsage.user + cpuUsage.system) / 1e6;
	logger.debug(`CPU usage: ${cpuSeconds.toFixed(2)}s (cumulative)`);
}, 300 * 1e3);
//#endregion
